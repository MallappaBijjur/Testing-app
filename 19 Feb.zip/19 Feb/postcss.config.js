/* Set your postcss-loader configuration here */

module.exports = { plugins: [require('autoprefixer')] };
