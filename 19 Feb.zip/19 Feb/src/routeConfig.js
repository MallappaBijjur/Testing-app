/* @flow */

import React from 'react';
import { Route } from 'react-router-dom';
import _ from 'lodash/fp';

const routeWithSubRoutes = (route: any): any => (
  <Route
    key={_.uniqueId()}
    exact={route.exact || false}
    path={route.path}
    render={props => (
      // Pass the sub-routes down to keep nesting
      <route.component {...props} routes={route.routes || null} />
    )}
  />
);

export default routeWithSubRoutes;
