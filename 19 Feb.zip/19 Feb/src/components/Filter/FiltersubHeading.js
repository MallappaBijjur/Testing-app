/* @flow */

import React from 'react';
import type { Element } from 'react';
import styles from './styles.scss';

type Props = { title: string };

const FilterSubHeading = ({ title }: Props): Element<'h3'> => (
  <h3 className={styles.subheading}> {title}</h3>
);

export default FilterSubHeading;
