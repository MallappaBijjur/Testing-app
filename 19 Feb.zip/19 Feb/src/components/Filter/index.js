/* @flow */
import React from 'react';
import Checkbox from 'material-ui/Checkbox';
import UnCheckedIcon from 'material-ui/svg-icons/toggle/check-box-outline-blank';
import CheckedIcon from 'material-ui/svg-icons/toggle/check-box';
import { withRouter } from 'react-router-dom';
import FilterSubHeading from './FiltersubHeading';
import styles from './styles.scss';
import ShelfVehicle from '../YMME/ShelfVehicle';

type Props = {
  filterData: Object,
  location: Object,
  history: Object,
  handleFilter: string => void
};

type State = {
  seeMore: boolean,
  filterLength: number
};

const checkboxStyles = {
  block: {
    maxWidth: 250
  },
  checkbox: {
    marginBottom: 16
  }
};

class FilterSideBar extends React.Component<Props, State> {
  constructor(props) {
    super(props);
    this.state = {
      seeMore: false,
      filterLength: 5
    };
  }

  showMore = () => {
    const setRes =
      this.state.filterLength === 5
        ? this.setState({
            filterLength: this.props.filterData.refinementMenuList[0]
              .refinements.length,
            seeMore: true
          })
        : this.setState({ filterLength: 5, seeMore: false });
    return setRes;
  };

  handleFilter = (seoUrl: string) => {
    const { pathname } = this.props.location;
    const { history: { push } } = this.props;
    const p = seoUrl.indexOf('?');
    const num = seoUrl.substring(p + '?filters='.length);
    push({ pathname: `${pathname}`, search: `filters=${num}` });
  };

  render() {
    const { filterData } = this.props;
    return (
      <div className={styles.filterSidebar}>
        <h2 className={styles.productShelfHeading}>
          <span className={styles.bolder}>FILTER </span>
          <span className={styles.lighter}>RESULT</span>
        </h2>
        <FilterSubHeading title="WORKING ON" />
        <ShelfVehicle />

        {filterData &&
          filterData.refinementMenuList &&
          filterData.refinementMenuList.map(item => (
            <div key={item.displayName}>
              <FilterSubHeading
                key={item.displayName}
                title={item.displayName.toUpperCase()}
              />
              {item.refinements
                .slice(0, this.state.filterLength)
                .map(itemRefinement => (
                  <Checkbox
                    key={itemRefinement.label}
                    onCheck={() =>
                      this.props.handleFilter(itemRefinement.properties.seoUrl)
                    }
                    uncheckedIcon={
                      <UnCheckedIcon style={{ fill: '#484848' }} />
                    }
                    checkedIcon={<CheckedIcon style={{ fill: '#f26100' }} />}
                    label={`${itemRefinement.label} (${itemRefinement.count})`}
                    labelStyle={{ color: '#484848' }}
                    style={checkboxStyles.checkbox}
                  />
                ))}
              <p>
                <span
                  role="presentation"
                  onKeyUp={() => false}
                  className={
                    item.refinements.length <= 5
                      ? `${styles.dNone}`
                      : `${styles.dBlock}`
                  }
                  onClick={this.showMore}
                >
                  {this.state.seeMore ? (
                    <span>Show less</span>
                  ) : (
                    <span>Show All</span>
                  )}
                </span>
              </p>
            </div>
          ))}
      </div>
    );
  }
}

export default withRouter(FilterSideBar);
