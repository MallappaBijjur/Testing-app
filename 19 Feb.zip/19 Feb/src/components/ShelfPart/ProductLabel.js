/* @flow */
import React from 'react';
import type { Element } from 'react';
import { Link, Router } from 'react-router-dom';
import Badge from './Badge';
import styles from './styles.scss';

type Props = {
  styles: Object,
  mobile?: boolean,
  title?: string,
  name?: string,
  quickNote?: string,
  partNumber?: string,
  warraty?: string,
  shelfData: Object,
  price: Object
};

const ProductLabel = (props: Props): Element<'div'> => {
  const isMobile = props.mobile ? 'hide' : '';
  return (
    <div>
      {props &&
        props.shelfData && (
          <div>
            <div className={`${props.styles.mobile} ${styles.mobileBadge}`}>
              <Badge badgesData={props.price} />
            </div>
            <Router>
              <Link
                to={{
                  pathname: '/product-detail',
                  search: `?seourl=${props.shelfData.seoUrl}`
                }}
              >
                <header className={props.styles.name}>
                  <span className={props.styles.title}>
                    {' '}
                    {props.shelfData.brand}
                  </span>
                  <span> {props.shelfData.name}</span>
                </header>
              </Link>
            </Router>
            <div className={props.styles.type}>{props.shelfData.quickNote}</div>
            <div className={`${props.styles.part} ${isMobile}`}>
              {'Part #'}
              {props.shelfData.partNumber}
            </div>
            {props.price &&
              props.price.warranty && (
                <a className={`${props.styles.warraty} ${isMobile}`} href="/">
                  {props.price.warranty} Warranty
                </a>
              )}
          </div>
        )}
    </div>
  );
};

ProductLabel.defaultProps = {
  title: '',
  name: '',
  quickNote: '',
  partNumber: '',
  warraty: '',
  mobile: false
};

export default ProductLabel;
