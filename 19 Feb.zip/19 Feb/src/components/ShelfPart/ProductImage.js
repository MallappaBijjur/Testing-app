/* @flow */
import React from 'react';
import type { Element } from 'react';
import { Link, Router } from 'react-router-dom';
import styles from './styles.scss';
import Badge from './Badge';
import { imageServer } from '../../config/serviceAPI';

type Props = {
  list: boolean,
  currentPrice: Object,
  data: Object
};

const ProductImage = (props: Props): Element<'div'> => {
  const display = props.list ? styles.list : styles.gpart;
  return (
    <div>
      <div className={styles.desk}>
        <Badge badgesData={props.currentPrice} />
      </div>
      <Router>
        <Link
          to={{
            pathname: '/product-detail',
            search: `?seourl=${props.data.seoUrl}`
          }}
        >
          <img
            className={`${styles.partimage} ${display} ${styles.image}`}
            src={imageServer + props.data.productImageUrl}
            alt="product "
          />
        </Link>
      </Router>
    </div>
  );
};

export default ProductImage;
