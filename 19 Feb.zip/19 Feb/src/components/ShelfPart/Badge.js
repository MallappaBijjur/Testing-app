/* @flow */
import React from 'react';
import styles from './styles.scss';

type Props = {
  badgesData: Object
};
const Badge = (props: Props): any => {
  const { badgesData } = props;
  const badgeDetails = badgesData ? badgesData.aZBadgesFlagVO : null;
  const lastBadge =
    badgeDetails &&
    badgeDetails.dealAvailable === 'true' &&
    !(
      badgeDetails &&
      badgeDetails.vehicleFit === 'true' &&
      badgeDetails &&
      badgeDetails.eligibleForNextDay === 'true'
    );
  return (
    <div>
      {badgeDetails &&
        badgeDetails.eligibleForNextDay && (
          <div className={styles.enjoyPart}>Free Next-Day Delivery</div>
        )}
      {badgeDetails &&
        badgeDetails.vehicleFit && (
          <div className={styles.enjoyPart}>VECHICLE SPECIFIC</div>
        )}
      {badgeDetails &&
        badgeDetails.dealAvailable && (
          <div className={`${styles.enjoyPart} ${styles.deals}`}>Hot Deal</div>
        )}
      {lastBadge && (
        <div className={`${styles.enjoyPart} ${styles.deals}`}>PRICE CUT</div>
      )}
    </div>
  );
};

export default Badge;
