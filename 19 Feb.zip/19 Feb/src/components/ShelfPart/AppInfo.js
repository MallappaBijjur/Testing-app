/* @flow */
import React from 'react';
import type { Element } from 'react';
import styles from './styles.scss';

type Props = {
  application?: string,
  list: boolean,
  styles: Object,
  shelfData: Object
};

const AppInfo = (props: Props): Element<'div'> => {
  const list = props.list ? styles.show : styles.hide;
  return (
    <div className={`${props.styles.app} ${list}`}>
      {props.shelfData &&
        props.shelfData.application && (
          <div className={props.styles.application}>
            <span className={props.styles.label}> Application:</span>
            <span>{props.shelfData.application}</span>
          </div>
        )}
      <div className={props.styles.notes}>
        <span className={props.styles.label}> Notes:</span>
        {props.shelfData.techNotes}
      </div>
    </div>
  );
};

AppInfo.defaultProps = {
  application: ''
};

export default AppInfo;
