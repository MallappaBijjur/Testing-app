/* @flow */
import React from 'react';
import type { Element } from 'react';
import { Popup, Header } from 'semantic-ui-react';
import styles from './styles.scss';

type Props = {
  list: boolean,
  styles: Object,
  price: Object
};

const ProductPrice = (props: Props): Element<'div'> => {
  const priceWidth = props.list ? styles.pos : '';
  const price = props.price ? props.price.skuPricingAndAvailability : '';
  const text =
    'A Core is an item that has the ability to be rebuilt by the manufacturer using new replacement parts. Rebuilding these items helps to reduce product cost as well as aid in recycling efforts which helps the environment. When the old part is returned to AutoZone, we refund the core charge to you.';
  return (
    <div className={`${props.styles.place} ${priceWidth}`}>
      <div className={props.styles.price}>
        <span className={props.styles.superscript}>$</span>
        <span className={props.styles.amount}>
          {price && price.retailPrice}
        </span>
      </div>
      <div className={props.styles.core}>
        <Popup trigger={<img src="/images/info.png" alt="info" />} hoverable>
          <Header as="h4" className={props.styles.header}>
            What is it?{' '}
          </Header>
          <p>{text}</p>
        </Popup>
        Core ${price && price.corePrice}
      </div>
    </div>
  );
};

export default ProductPrice;
