// @flow
import React, { PureComponent } from 'react';
import styles from './styles.scss';

type Props = {
  description: string,
  className: string
};

type State = {
  expanded: boolean
};

const mobileCharCount = 500;

export default class DescriptionMobile extends PureComponent<Props, State> {
  constructor() {
    super();
    this.state = { expanded: false };
  }

  onToggleClick = () => {
    this.setState({
      expanded: !this.state.expanded
    });
  };

  getDescription = () => {
    let { description } = this.props;
    description = description || '';
    if (description.length <= mobileCharCount || this.state.expanded) {
      return description;
    }
    return `${description.substring(0, mobileCharCount)}...`;
  };

  render() {
    const descriptionProps = this.props.description;
    const description = this.getDescription();
    return (
      <div className={this.props.className}>
        <div
          className={styles.description}
          dangerouslySetInnerHTML={{ __html: description }} // eslint-disable-line
        />
        {descriptionProps &&
        descriptionProps.length <= mobileCharCount ? null : (
          <button
            type="button"
            className={styles.readMore}
            onClick={this.onToggleClick}
          >
            <div style={{ marginBottom: '5px', fontWeight: 600 }}>
              {!this.state.expanded ? 'READ MORE' : 'READ LESS'}
            </div>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 8 13"
              width="8"
              height="13"
              style={
                !this.state.expanded ? {} : { transform: 'rotate(180deg)' }
              }
            >
              <path
                fill="#f38021"
                fillRule="evenodd"
                d="M 1.593 7.965 L 0.56 8.999 L 4 12.44 l 3.44 -3.441 l -1.033 -1.034 L 4.73 9.641 V 0.44 H 3.269 v 9.201 Z"
              />
            </svg>
          </button>
        )}
      </div>
    );
  }
}
