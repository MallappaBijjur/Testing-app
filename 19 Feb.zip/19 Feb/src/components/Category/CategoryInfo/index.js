// @flow
import React, { PureComponent } from 'react';
import DescriptionMobile from './DescriptionMobile';
import DescriptionDesktop from './DescriptionDesktop';
import styles from './styles.scss';

type Props = {
  description: string
};

// Export this for unit testing more easily
export default class CategoryInfo extends PureComponent<Props> {
  category = 'AUTO PARTS';

  render() {
    const { description } = this.props;
    const { category } = this;
    return (
      <div className={styles.wrapper}>
        <div className={styles.centeredContainer}>
          <div className={styles.header}>
            <span className={styles.content}>SHOP {category} WITH&nbsp;</span>
            <span className={styles.bold}>AUTOZONE</span>
            <span className={styles.divider}>
              <img
                src="/images/orangeRectangle.svg"
                alt="divider"
                width="84px"
                height="4px"
              />
            </span>
          </div>
          <DescriptionDesktop
            className={styles.descriptionDesktop}
            description={description}
          />
          <DescriptionMobile
            className={styles.descriptionMobile}
            description={description}
          />
        </div>
      </div>
    );
  }
}
