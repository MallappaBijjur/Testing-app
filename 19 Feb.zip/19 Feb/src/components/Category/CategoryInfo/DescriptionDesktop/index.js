// @flow
import React, { PureComponent } from 'react';
import styles from './styles.scss';

type Props = {
  description: string,
  className: string
};

export default class DescriptionDesktop extends PureComponent<Props> {
  render() {
    const { description, className } = this.props;
    return (
      <div
        className={`${styles.description} ${className}`}
        dangerouslySetInnerHTML={{ __html: description }} // eslint-disable-line
      />
    );
  }
}
