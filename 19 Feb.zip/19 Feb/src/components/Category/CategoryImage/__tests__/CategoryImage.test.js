// @flow
import React from 'react';
import { mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import CategoryImage from '../CategoryImage';

describe('<CategoryImage />', () => {
  let PROPS = {};
  beforeEach(() => {
    PROPS = {
      imageData: {
        ForeGroundImage: '/images/MEDIA_ProductCatalog/catProductImg.png',
        CTALink1:
          'https://www.autozone.com/brakes-and-traction-control/brake-pads',
        Headline2: 'With the purchse of 2 Duralast Gold Rotors',
        CTAName3: 'See Terms & Conditions',
        Headline1: 'SAVE $10',
        CTAName1: 'BUY NOW',
        CTAName2: 'VIEW DETAILS',
        BackGroundImage: '/images/MEDIA_ProductCatalog/catHeroImageBg.png',
        CTALink3:
          'https://www.autozone.com/landing/page.jsp?name=buy_online_pickup_in_store',
        CTALink2:
          'https://www.autozone.com/landing/page.jsp?name=buy_online_pickup_in_store'
      }
    };
  });

  test('renders on desktop correctly', () => {
    const wrapper = mount(<CategoryImage {...PROPS} />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders on mobile correctly', () => {
    const wrapper = mount(<CategoryImage {...PROPS} />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders nothing for no props', () => {
    const wrapper = mount(<CategoryImage />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });
});
