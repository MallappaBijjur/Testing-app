// @flow
import React from 'react';
import * as styles from './CategoryImage.scss';
import { imageServer } from '../../../config/serviceAPI';

type Props = {
  imageData: Object
};

const CategoryImage = (props: Props) => {
  const data = props.imageData;
  if (!data) {
    return null;
  }

  const devServer = imageServer;
  const bgImage = new URL(data.BackGroundImage, devServer);
  const fgImage = new URL(data.ForeGroundImage, devServer);
  return (
    <div>
      <div className={styles.catHeroImgContainer}>
        <img
          alt="background"
          src={bgImage}
          style={{ width: '100%', height: '270px' }}
        />
        <div className={`row ${styles.heroImageCont}`}>
          <div className="col l6 offset-l1">
            <div className={styles.heroImageCont__heading}>
              <h1>{data.Headline1}</h1>
              <p>{data.Headline2}</p>
              <div>
                <span className={styles.barStyle} />
                <a
                  href={data.CTALink1}
                  className={`btn white ${styles.catHeroImgCont__btn__white}`}
                >
                  {data.CTAName1}
                </a>
                <a
                  href={data.CTALink2}
                  className={`btn transparent ${
                    styles.catHeroImgCont__btn__black
                  }`}
                >
                  {data.CTAName2}
                </a>
                <div>
                  <a href={data.CTALink3} className={styles.catTermsNCond}>
                    {data.CTAName3}
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div className="col l4 offset-l1">
            <img alt="foreground" src={fgImage} />
          </div>
        </div>
      </div>

      <div className={styles.catHeroImgContainerMobile}>
        <img
          alt="background"
          src={bgImage}
          style={{ width: '100%', height: '173px' }}
        />

        <div className={styles.heroImageCont}>
          <div className={styles.heroImageCont__heading}>
            <h1>{data.Headline1}</h1>
            <span className={styles.barStyle} />
          </div>
          <div className={styles.heroImageCont__itemImage}>
            <img
              alt="foregroundImage"
              src={fgImage}
              style={{ width: 'auto', height: '165px' }}
            />
          </div>
        </div>
        <div className={`row ${styles.cardText}`}>
          <div className="col s12">{data.Headline2}</div>
        </div>
        <div className="row">
          <div className="col s12">
            <a
              href={data.CTALink1}
              className={`btn black ${styles.catHeroImgCont__btn__black}`}
            >
              {data.CTAName1}
            </a>
            <a
              href={data.CTALink2}
              className={`btn transparent ${styles.catHeroImgCont__btn__white}`}
            >
              {data.CTAName2}
            </a>
          </div>
        </div>
        <div className="row">
          <div className="col s12">
            <a href={data.CTALink3} className={styles.catTermsNCond}>
              {data.CTAName3}
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategoryImage;
