// @flow
import React from 'react';
import { Link } from 'react-router-dom';
import * as styles from './CatListItem.scss';

type Props = {
  data: Object
};

export default class CatListItemMobile extends React.Component<Props> {
  rightArrowSVG = () => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="12"
      height="7"
      viewBox="0 0 12 7"
    >
      <path
        fill="#F38021"
        fillRule="evenodd"
        d="M7.525 5.849l1.034 1.033L12 3.442 8.559 0 7.525 1.034 9.201 2.71H0v1.462h9.201z"
      />
    </svg>
  );

  render() {
    if (this.props.data.isProduct) {
      const toURL = `/shelfPage${this.props.data.seoUrl}`;
      return (
        <Link to={toURL} className={`col l6 ${styles.catListItem}`}>
          {this.props.data.label} ({this.props.data.count})
          {this.rightArrowSVG()}
        </Link>
      );
    }
    return (
      <Link
        to={this.props.data.seoUrl}
        className={`col l6 ${styles.catListItem}`}
      >
        {this.props.data.label}
        {this.rightArrowSVG()}
      </Link>
    );
  }
}
