// @flow
import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import type { Connector } from 'react-redux';
import type { Dispatch, ReduxState } from '../../../types';
import { fetchSubCategoryData } from '../../../actions/category';
import * as styles from './ShopByCategory.scss';
import CatListItem from './CatListItem';
import CatListItemMobile from './CatListItemMobile';

type Props = {
  catData: Object,
  readyStatus: string,
  subCatData: Object,
  fetchSubCategoryData: string => void
};

type State = {
  mobile: boolean,
  subCatLabel: string,
  activeIndex: number,
  displaySubCat: boolean
};

type SubItemProps = {
  data: Object
};

export const SubCatListItem = ({ data }: SubItemProps) => (
  <div className="col l4">
    <Link
      to={`/shelfPage${data.seoUrl}`}
      className={styles.subCatContainer_listItem}
    >
      {data.label} ({data.count})
    </Link>
  </div>
);

export class ShopByCategoryComp extends React.Component<Props, State> {
  constructor(props: any) {
    super(props);
    this.state = {
      mobile: false,
      subCatLabel: '',
      activeIndex: -1,
      displaySubCat: false
    };
  }

  componentWillMount() {
    if (window.innerWidth < 1140) {
      this.setState({ mobile: true });
    } else {
      this.setState({ mobile: false });
    }
  }

  fetchSubCatData = (relPath: string, label: string, currentIndex: number) => {
    if (this.state.activeIndex !== currentIndex) {
      this.props.fetchSubCategoryData(relPath);
      this.setState({
        subCatLabel: label,
        activeIndex: currentIndex,
        displaySubCat: true
      });
    } else {
      this.setState({
        activeIndex: -1,
        displaySubCat: false
      });
    }
  };

  renderListItems = () => {
    const childCat = this.props.catData;
    const listItems =
      childCat &&
      childCat.map((item, index) => (
        <CatListItem
          key={item.NId}
          data={item}
          fetchSubCatData={this.fetchSubCatData}
          itemIndex={index}
          activeIndex={this.state.activeIndex}
        />
      ));
    return listItems;
  };

  renderListItemsMobile = () => {
    const childCat = this.props.catData;
    const listItems =
      childCat &&
      childCat.map(item => <CatListItemMobile key={item.NId} data={item} />);
    return listItems;
  };

  renderSubCat = () => {
    const readyStat = this.props.readyStatus;
    if (readyStat === 'SUB_CATEGORY_SUCCESS') {
      const childCat = this.props.subCatData.childCategories;
      const listItems =
        childCat &&
        childCat.map(item => <SubCatListItem key={item.NId} data={item} />);
      return listItems;
    } else if (readyStat === 'SUB_CATEGORY_REQUESTING') {
      return <div>Loading...</div>;
    }
    return null;
  };

  renderForLargeScreen = () => {
    const label = this.state.subCatLabel;
    return (
      <div>
        <div className={styles.catContainer}>
          <div className={styles.catContainer__content}>
            <header>
              <div className={styles.catContainer__heading}>
                SHOP BY <span className={styles.bold}>CATEGORY</span>
              </div>
              <div className={styles.catContainer__heading__highlight} />
            </header>
            <div className="row">{this.renderListItems()}</div>
          </div>
        </div>
        {this.state.displaySubCat && (
          <div className={styles.subCatContainer}>
            <div className={`row ${styles.subCatContainer_content}`}>
              <div className={`row ${styles.subCatContainer_heading}`}>
                {`Narrow Your Results for ${label}`}
              </div>
              <div className="row ">{this.renderSubCat()}</div>
            </div>
          </div>
        )}
      </div>
    );
  };

  renderForSmallScreen = () => (
    <div className={styles.catContainer}>
      <div className={styles.catContainer__content}>
        <header>
          <div className={styles.catContainer__heading}>
            SHOP BY <span className={styles.bold}>CATEGORY</span>
          </div>
          <div className={styles.catContainer__heading__highlight} />
        </header>
        <div className="row">{this.renderListItemsMobile()}</div>
      </div>
    </div>
  );

  render() {
    if (!this.props.catData) {
      return null;
    } else if (this.state.mobile) {
      return this.renderForSmallScreen();
    }
    return this.renderForLargeScreen();
  }
}
/* istanbul ignore next */
const connector: Connector<{}, Props> = connect(
  (state: ReduxState) => ({
    subCatData: state.subCategory.subCatData,
    readyStatus: state.subCategory.readyStatus
  }),
  (dispatch: Dispatch) => ({
    fetchSubCategoryData: param => dispatch(fetchSubCategoryData(param))
  })
);

export default connector(ShopByCategoryComp);
