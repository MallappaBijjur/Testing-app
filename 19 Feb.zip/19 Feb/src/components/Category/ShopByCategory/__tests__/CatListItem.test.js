// @flow
import React from 'react';
import { mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import { StaticRouter } from 'react-router-dom';

import CatListItem from '../CatListItem';

describe('<CatListItem />', () => {
  let PROPS = {};
  let fetchSubCatData = () => {};
  beforeEach(() => {
    fetchSubCatData = jest.fn();
    PROPS = {
      fetchSubCatData,
      data: {
        seoUrl: '/parts/brakes-and-traction-control',
        label: 'Brakes And Traction Control',
        leafCategory: true,
        isProduct: true
      },
      activeIndex: 0,
      itemIndex: 0
    };
  });

  test('renders correctly if leaf', () => {
    const wrapper = mount(
      <StaticRouter context={{}}>
        <CatListItem {...PROPS} />
      </StaticRouter>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders correctly if not leaf', () => {
    PROPS.data.leafCategory = false;
    const wrapper = mount(
      <StaticRouter context={{}}>
        <CatListItem {...PROPS} />
      </StaticRouter>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders correctly if not active', () => {
    PROPS.activeIndex = 1;
    const wrapper = mount(
      <StaticRouter context={{}}>
        <CatListItem {...PROPS} />
      </StaticRouter>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders correctly if not a product', () => {
    PROPS.data.isProduct = false;
    PROPS.data.leafCategory = false;
    const wrapper = mount(
      <StaticRouter context={{}}>
        <CatListItem {...PROPS} />
      </StaticRouter>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('fetches subcategory on click', () => {
    const wrapper = mount(
      <StaticRouter context={{}}>
        <CatListItem {...PROPS} />
      </StaticRouter>
    );
    wrapper
      .find('div')
      .props()
      .onClick();
    expect(fetchSubCatData.mock.calls.length).toBe(1);
  });

  test('handles keyup event witthout error', () => {
    const preventDefault = jest.fn();
    const wrapper = mount(
      <StaticRouter context={{}}>
        <CatListItem {...PROPS} />
      </StaticRouter>
    );
    expect(wrapper.find('div').props().onKeyUp).toBeTruthy();
    wrapper
      .find('div')
      .props()
      .onKeyUp({ preventDefault });
    expect(preventDefault.mock.calls.length).toBe(1);
  });
});
