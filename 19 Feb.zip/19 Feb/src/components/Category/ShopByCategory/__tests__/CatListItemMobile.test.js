// @flow
import React from 'react';
import { mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import { StaticRouter } from 'react-router-dom';

import CatListItemMobile from '../CatListItemMobile';

describe('<CatListItemMobile />', () => {
  let PROPS = {};
  beforeEach(() => {
    PROPS = {
      data: {
        seoUrl: '/parts/brakes-and-traction-control',
        label: 'Brakes And Traction Control',
        count: 2,
        isProduct: true
      }
    };
  });

  test('renders correctly if it is product', () => {
    const wrapper = mount(
      <StaticRouter context={{}}>
        <CatListItemMobile {...PROPS} />
      </StaticRouter>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders correctly if it is not product', () => {
    PROPS.data.isProduct = false;
    const wrapper = mount(
      <StaticRouter context={{}}>
        <CatListItemMobile {...PROPS} />
      </StaticRouter>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });
});
