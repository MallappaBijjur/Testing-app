// @flow
import React from 'react';
import { mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import { StaticRouter } from 'react-router-dom';

import { ShopByCategoryComp, SubCatListItem } from '../ShopByCategory';
import CatListItem from '../CatListItem';

describe('<ShopByCategory />', () => {
  let PROPS = {};
  beforeEach(() => {
    PROPS = {
      fetchSubCategoryData: jest.fn(),
      catData: [
        {
          seoUrl: '/parts/cooling-heating-and-climate-control',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl:
            '/images/MEDIA_ProductCatalog/m3490038_cat-cooling-heating-and-climate.jpg',
          NId: '14299999',
          count: 212017,
          label: 'Cooling, Heating And Climate Control',
          leafCategory: false
        },
        {
          seoUrl: '/parts/drivetrain',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl: '/images/MEDIA_ProductCatalog/m3490043_cat-drivetrain.jpg',
          NId: '196199999',
          count: 292346,
          label: 'Drivetrain',
          leafCategory: false
        },
        {
          seoUrl: '/parts/interior',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl: '/images/MEDIA_ProductCatalog/m3490074_cat-interior.jpg',
          NId: '139299999',
          count: 220993,
          label: 'Interior',
          leafCategory: true
        }
      ],
      subCatData: {
        childCategories: [
          {
            seoUrl: '/parts/cooling-heating-and-climate-control',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl:
              '/images/MEDIA_ProductCatalog/m3490038_cat-cooling-heating-and-climate.jpg',
            NId: '14299999',
            count: 212017,
            label: 'Cooling, Heating And Climate Control',
            leafCategory: false
          },
          {
            seoUrl: '/parts/drivetrain',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl:
              '/images/MEDIA_ProductCatalog/m3490043_cat-drivetrain.jpg',
            NId: '196199999',
            count: 292346,
            label: 'Drivetrain',
            leafCategory: false
          },
          {
            seoUrl: '/parts/interior',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl: '/images/MEDIA_ProductCatalog/m3490074_cat-interior.jpg',
            NId: '139299999',
            count: 220993,
            label: 'Interior123',
            leafCategory: true
          }
        ]
      },
      readyStatus: 'SUB_CATEGORY_SUCCESS'
    };
  });

  test('renders correctly for desktop', () => {
    window.innerWidth = 1200;
    const wrapper = mount(
      <StaticRouter context={{}}>
        <ShopByCategoryComp {...PROPS} />
      </StaticRouter>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders correctly for mobile', () => {
    window.innerWidth = 1000;
    const wrapper = mount(
      <StaticRouter context={{}}>
        <ShopByCategoryComp {...PROPS} />
      </StaticRouter>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders nothing if no data is passed', () => {
    window.innerWidth = 1200;
    const wrapper = mount(
      <StaticRouter context={{}}>
        <ShopByCategoryComp />
      </StaticRouter>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('shows loading while fetching subcategory', () => {
    window.innerWidth = 2000;
    PROPS.readyStatus = 'SUB_CATEGORY_REQUESTING';
    const wrapper = mount(
      <StaticRouter context={{}}>
        <ShopByCategoryComp {...PROPS} />
      </StaticRouter>
    );
    wrapper
      .find(CatListItem)
      .at(2)
      .props()
      .fetchSubCatData('', 'test label', 2);
    expect(PROPS.fetchSubCategoryData.mock.calls.length).toBe(1);
    wrapper.update();
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('shows no subcategory if request fails', () => {
    window.innerWidth = 2000;
    PROPS.readyStatus = 'SUB_CATEGORY_FAILURE';
    const wrapper = mount(
      <StaticRouter context={{}}>
        <ShopByCategoryComp {...PROPS} />
      </StaticRouter>
    );
    wrapper
      .find(CatListItem)
      .at(2)
      .props()
      .fetchSubCatData('', 'test label', 2);
    expect(PROPS.fetchSubCategoryData.mock.calls.length).toBe(1);
    wrapper.update();
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('shows subcategory on leaf item click', () => {
    window.innerWidth = 2000;
    const wrapper = mount(
      <StaticRouter context={{}}>
        <ShopByCategoryComp {...PROPS} />
      </StaticRouter>
    );
    wrapper
      .find(CatListItem)
      .at(2)
      .props()
      .fetchSubCatData('', 'test label', 2);
    expect(PROPS.fetchSubCategoryData.mock.calls.length).toBe(1);
    wrapper.update();
    expect(wrapper.find(SubCatListItem).length).toBe(3);
  });

  test('hides subcategory on clicking same item again', () => {
    window.innerWidth = 2000;
    const wrapper = mount(
      <StaticRouter context={{}}>
        <ShopByCategoryComp {...PROPS} />
      </StaticRouter>
    );
    wrapper
      .find(CatListItem)
      .at(2)
      .props()
      .fetchSubCatData('', 'test label', 2);
    expect(PROPS.fetchSubCategoryData.mock.calls.length).toBe(1);
    wrapper.update();
    expect(wrapper.find(SubCatListItem).length).toBe(3);
    // simulate click to hide subcategory
    wrapper
      .find(CatListItem)
      .at(2)
      .props()
      .fetchSubCatData('', 'test label', 2);
    expect(PROPS.fetchSubCategoryData.mock.calls.length).toBe(1);
    wrapper.update();
    expect(wrapper.find(SubCatListItem).length).toBe(0);
  });
});
