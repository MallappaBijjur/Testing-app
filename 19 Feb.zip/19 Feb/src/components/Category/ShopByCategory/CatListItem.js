/* @flow */
import React from 'react';
import { Link } from 'react-router-dom';
import * as styles from './CatListItem.scss';

type Props = {
  fetchSubCatData: (string, string, number) => void,
  data: Object,
  itemIndex: number,
  activeIndex: number
};

export default class CatListItem extends React.Component<Props> {
  rightArrowSVG = () => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="12"
      height="7"
      viewBox="0 0 12 7"
    >
      <path
        fill="#F38021"
        fillRule="evenodd"
        d="M7.525 5.849l1.034 1.033L12 3.442 8.559 0 7.525 1.034 9.201 2.71H0v1.462h9.201z"
      />
    </svg>
  );

  downArrowSVG = () => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="14"
      height="8"
      viewBox="0 0 14 8"
    >
      <path
        fill="#F38021"
        fillRule="evenodd"
        d="M7 5.214L1.476 0 0 1.393 7 8l7-6.607L12.524 0z"
      />
    </svg>
  );

  upArrowSVG = () => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="14"
      height="8"
      viewBox="0 0 14 8"
    >
      <path
        fill="#F38021"
        fillRule="evenodd"
        d="M7 2.786L12.524 8 14 6.607 7 0 0 6.607 1.476 8z"
      />
    </svg>
  );

  handleClick = () => {
    this.props.fetchSubCatData(
      this.props.data.seoUrl,
      this.props.data.label,
      this.props.itemIndex
    );
  };

  handleKeyUp = (e: Object) => e.preventDefault();

  render() {
    const activeState = this.props.activeIndex === this.props.itemIndex;
    if (this.props.data.leafCategory) {
      const arrowSVG = activeState ? this.upArrowSVG() : this.downArrowSVG();
      return (
        <div
          id={this.props.itemIndex}
          className={`col l6 ${
            activeState ? styles.catListItem__active : styles.catListItem
          }`}
          onClick={this.handleClick}
          onKeyUp={this.handleKeyUp}
          role="button"
          tabIndex="0"
        >
          {this.props.data.label}
          {arrowSVG}
        </div>
      );
    }
    const toURL = this.props.data.isProduct
      ? `/shelfPage${this.props.data.seoUrl}`
      : this.props.data.seoUrl;
    return (
      <Link to={toURL} className={`col l6 ${styles.catListItem}`}>
        {this.props.data.label}
        {this.rightArrowSVG()}
      </Link>
    );
  }
}
