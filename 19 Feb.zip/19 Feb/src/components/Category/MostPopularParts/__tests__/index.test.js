// @flow
import React from 'react';
import { mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import { StaticRouter } from 'react-router-dom';

import MostPopularParts from '../index';

describe('<MostPopularParts />', () => {
  let PROPS = {};
  beforeEach(() => {
    PROPS = {
      data: [
        {
          seoUrl: '/parts/batteries-starting-and-chargingbsc',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl:
            '/images/MEDIA_ProductCatalog/m3880002_cat_batteries-starting-and-charging.jpg',
          NId: '10199999',
          count: 79044,
          label: 'Batteries, Starting And Charging_BSC',
          leafCategory: false
        },
        {
          seoUrl: '/parts/brakes-and-traction-control',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl:
            '/images/MEDIA_ProductCatalog/m3490090_cat-brakes-and-traction.jpg',
          NId: '11499999',
          count: 311429,
          label: 'Brakes And Traction Control',
          leafCategory: false
        },
        {
          seoUrl: '/parts/collision-body-parts-and-hardware',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl:
            '/images/MEDIA_ProductCatalog/m3490041_cat-collision-body-parts.jpg',
          NId: '196099999',
          count: 239077,
          label: 'Collision, Body Parts And Hardware',
          leafCategory: false
        },
        {
          seoUrl: '/parts/cooling-heating-and-climate-control',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl:
            '/images/MEDIA_ProductCatalog/m3490038_cat-cooling-heating-and-climate.jpg',
          NId: '14299999',
          count: 212017,
          label: 'Cooling, Heating And Climate Control',
          leafCategory: false
        },
        {
          seoUrl: '/parts/drivetrain',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl: '/images/MEDIA_ProductCatalog/m3490043_cat-drivetrain.jpg',
          NId: '196199999',
          count: 292346,
          label: 'Drivetrain',
          leafCategory: false
        },
        {
          seoUrl: '/parts/electrical-and-lighting',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl:
            '/images/MEDIA_ProductCatalog/m3490044_cat-electrical-and-lighting.jpg',
          NId: '193399999',
          count: 379079,
          label: 'Electrical And Lighting',
          leafCategory: false
        },
        {
          seoUrl: '/parts/emission-control-and-exhaust',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl:
            '/images/MEDIA_ProductCatalog/m3490045_cat-emission-control-and-exhaust.jpg',
          NId: '182699999',
          count: 134763,
          label: 'Emission Control And Exhaust',
          leafCategory: false
        },
        {
          seoUrl: '/parts/engine-management',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl:
            '/images/MEDIA_ProductCatalog/m3490051_cat-engine-management.jpg',
          NId: '11199999',
          count: 128703,
          label: 'Engine Management',
          leafCategory: false
        },
        {
          seoUrl: '/parts/external-engine',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl:
            '/images/MEDIA_ProductCatalog/m3490055_cat-external-engine.jpg',
          NId: '13199999',
          count: 255145,
          label: 'External Engine',
          leafCategory: false
        },
        {
          seoUrl: '/parts/filters-and-pcv',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl:
            '/images/MEDIA_ProductCatalog/m3490056_cat-filters-and-pcv.jpg',
          NId: '114199999',
          count: 38284,
          label: 'Filters And PCV',
          leafCategory: false
        },
        {
          seoUrl: '/parts/fuel-delivery',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl:
            '/images/MEDIA_ProductCatalog/m3490057_cat-fuel-delivery.jpg',
          NId: '115699999',
          count: 91581,
          label: 'Fuel Delivery',
          leafCategory: false
        },
        {
          seoUrl: '/parts/gaskets',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl: '/images/MEDIA_ProductCatalog/m3510027_cat-gaskets.jpg',
          NId: '130999999',
          count: 90688,
          label: 'Gaskets',
          leafCategory: false
        },
        {
          seoUrl: '/parts/ignition-tune-up-and-routine-maintenance',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl:
            '/images/MEDIA_ProductCatalog/m3490059_cat-ignition-tuneup.jpg',
          NId: '132499999',
          count: 222484,
          label: 'Ignition, Tune Up And Routine Maintenance',
          leafCategory: false
        },
        {
          seoUrl: '/parts/interior',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl: '/images/MEDIA_ProductCatalog/m3490074_cat-interior.jpg',
          NId: '139299999',
          count: 220993,
          label: 'Interior',
          leafCategory: false
        },
        {
          seoUrl: '/parts/internal-engine',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl:
            '/images/MEDIA_ProductCatalog/m3490063_cat-internal-engine.jpg',
          NId: '140999999',
          count: 144918,
          label: 'Internal Engine',
          leafCategory: false
        },
        {
          seoUrl: '/parts/powertrain',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl: '/images/MEDIA_ProductCatalog/m3490068_cat-powertrain.jpg',
          NId: '147899999',
          count: 98154,
          label: 'Powertrain',
          leafCategory: false
        },
        {
          seoUrl: '/parts/suspension-steering-tire-and-wheel',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl:
            '/images/MEDIA_ProductCatalog/m3490073_cat-suspension-steering-tire-and-wheel.jpg',
          NId: '148599999',
          count: 320759,
          label: 'Suspension, Steering, Tire And Wheel',
          leafCategory: false
        },
        {
          seoUrl: '/truck-and-towing',
          '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
          imageUrl: '/autozone/tpl/prodimg.jpg',
          NId: '151399999',
          count: 263696,
          label: 'Truck And Towing',
          leafCategory: false
        }
      ]
    };
  });

  test('renders correctly on desktop', () => {
    global.innerWidth = 2000;
    const wrapper = mount(
      <StaticRouter context={{}}>
        <MostPopularParts {...PROPS} />
      </StaticRouter>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders correctly on mobile', () => {
    global.innerWidth = 1000;
    const wrapper = mount(
      <StaticRouter context={{}}>
        <MostPopularParts {...PROPS} />
      </StaticRouter>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders correctly with data', () => {
    const wrapper = mount(
      <StaticRouter context={{}}>
        <MostPopularParts {...PROPS} />
      </StaticRouter>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders correctly without data', () => {
    const wrapper = mount(
      <StaticRouter context={{}}>
        <MostPopularParts />
      </StaticRouter>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });
});
