// @flow
import React, { PureComponent } from 'react';
import { Link } from 'react-router-dom';
import styles from './styles.scss';

type Props = {
  data: Object
};

/* const flatten = (popularCategories) => {
  const arrays = [];
  Object.keys(popularCategories).forEach((item) => {
    arrays.push(popularCategories[item]);
  });
  const merged = [].concat(...arrays);
  return merged;
}; */

const totalItemCount = 12;

export default class MostPopularParts extends PureComponent<Props> {
  getCard = (item: Object) => (
    <Link
      key={item.seoUrl}
      to={`/shelfPage${item.seoUrl}`}
      className={styles.cardBlock}
    >
      <div className={styles.cardImageContent}>
        <img
          className={styles.cardImage}
          src={item.imageUrl} // "/images/popular_placeholder.png"
          alt="logo"
        />
      </div>
      <div className={styles.cardLabel}>{item.label}</div>
    </Link>
  );

  getCardRow = (items: Object, index: number) => {
    const self = this;
    return (
      <div key={index} className={styles.cardRow}>
        {items.map(item => self.getCard(item))}
      </div>
    );
  };

  getRows = (items: Object, rowCount: number, itemsPerRow: number) => {
    const rows = [];
    let pointer = 0;
    for (let i = 0; i < rowCount; i += 1) {
      const row = this.getCardRow(
        items.slice(pointer, pointer + itemsPerRow),
        i
      );
      rows.push(row);
      pointer += itemsPerRow;
    }
    return rows;
  };

  isMobile = global.innerWidth < 1140;
  rowWidth = global.innerWidth - 20;
  itemWidth = this.isMobile ? 143 : 184;

  render() {
    if (!this.props.data) {
      return null;
    }
    const itemsPerRow =
      Math.floor(this.rowWidth / this.itemWidth) > 6
        ? 6
        : Math.floor(this.rowWidth / this.itemWidth);
    const rowCount = Math.ceil(totalItemCount / itemsPerRow);
    const mostpopularData = this.props.data.slice(0, totalItemCount);
    return (
      <div>
        <div className={styles.headerContainer}>
          <div className={styles.centeredContainer}>
            <div className={styles.header}>
              <span className={styles.content}>MOST&nbsp;</span>
              <span className={styles.bold}>POPULAR PARTS</span>
              <span className={styles.divider}>
                <img
                  src="/images/orangeRectangle.svg"
                  alt="divider"
                  width="84px"
                  height="4px"
                />
              </span>
            </div>
          </div>
        </div>
        <div className={styles.category}>
          <div className={styles.cardRowContent}>
            {this.getRows(mostpopularData, rowCount, itemsPerRow)}
          </div>
        </div>
      </div>
    );
  }
}
