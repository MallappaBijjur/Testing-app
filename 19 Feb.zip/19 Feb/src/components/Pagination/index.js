/* @flow */
import React from 'react';
import FlatPagination from 'material-ui-flat-pagination';
import { withRouter } from 'react-router-dom';
// import { Icon, Pagination } from 'semantic-ui-react';
import styles from './styles.scss';

type Props = {
  perPage: any,
  location: any,
  history: any,
  num: any,
  pageData: any
};

type State = {
  offset: any,
  pageNumber: any
};

class PaginationExamplePagination extends React.Component<Props, State> {
  constructor() {
    super();
    this.state = {
      offset: 0,
      pageNumber: ''
    };
  }

  handleClick(offset) {
    const limit = this.props.perPage;
    const { pathname } = this.props.location;
    const { history: { push } } = this.props;
    const { search } = this.props.location;
    const { num } = this.props;
    const currentPage = Math.floor(offset / limit) + 1;
    this.setState(
      {
        offset,
        pageNumber: currentPage
      },
      () => {
        const something = search.includes('filters')
          ? push({
              pathname: `${pathname}`,
              search: `filters=${num}&pageNumber=${this.state.pageNumber}`
            })
          : push({
              pathname: `${pathname}`,
              search: `pageNumber=${this.state.pageNumber}`
            });
        return something;
      }
    );
  }

  render() {
    const paginationSytle = {
      style: {
        color: 'rgb(0,0,0) !important',
        height: '25px',
        marginTop: '12px',
        padding: '0 5px',
        lineHeight: '1px !important'
      },
      activeLink: {
        color: 'rgb(0,0,0)',
        fontWeight: 'bolder',
        fontSize: '16px',
        padding: '0 5px',
        margin: '0 10px',
        borderBottom: '3px solid rgb(242,97,0)'
      },
      otherLink: {
        color: 'rgb(160,160,160)',
        fontWeight: 'bolder',
        fontSize: '16px',
        padding: '0 10px',
        margin: '0 10px'
      },
      next: {
        color: 'rgb(160,160,160)'
      }
    };
    return (
      <div className={styles.pagination}>
        <FlatPagination
          style={paginationSytle.style}
          offset={this.state.offset}
          limit={this.props.perPage}
          total={this.props.pageData}
          nextPageLabel={
            <span>
              <span className={styles.next}>NEXT</span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="14"
                height="8"
                viewBox="0 0 14 8"
              >
                <path
                  fill="#F26100"
                  d="M8.78 6.823L9.984 8.03 14 4.015 9.985 0 8.78 1.206l1.956 1.956H0v1.706h10.735z"
                />
              </svg>
            </span>
          }
          previousPageLabel={
            <span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="14"
                height="8"
                viewBox="0 0 14 8"
              >
                <path
                  fill="#F26100"
                  d="M5.22 6.823L4.016 8.03 0 4.015 4.015 0 5.22 1.206 3.265 3.162H14v1.706H3.265z"
                />
              </svg>
              <span className={styles.prev}>PREV</span>
            </span>
          }
          currentPageLabelStyle={paginationSytle.activeLink}
          otherPageLabelStyle={paginationSytle.otherLink}
          onClick={(e, offset) => this.handleClick(offset)}
        />
      </div>
    );
  }
}

export default withRouter(PaginationExamplePagination);
