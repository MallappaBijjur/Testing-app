/* @flow */

import React from 'react';
import type { Element } from 'react';
import styles from './styles.scss';

type Props = { data: Object };

const ShelfHeading = ({ data }: Props): Element<'div'> => (
  <div className={styles.headingSection}>
    <h1 className={styles.productShelfHeading}>
      {' '}
      {data.totalNumrecords} Results for
      <span className={styles.boldHeading}> Oxygen sensor</span>
    </h1>
  </div>
);

export default ShelfHeading;
