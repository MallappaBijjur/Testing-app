/* @flow */
import React from 'react';
import { createStore } from 'redux';
import { Provider, connect } from 'react-redux';
import { MuiThemeProvider } from 'material-ui/styles';
import { mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import RaisedButton from 'material-ui/RaisedButton';

import ForgotForm from '../index';

let mockData = null;
beforeEach(() => {
  mockData = {
    mf_forgotpasswordpage_forgot_invalid_email: 'Email is not valid',
    mf_forgotpasswordpage_forgot_label: 'Email or Username',
    _links: {
      'oc:createAccountPage': {
        method: 'GET',
        href: 'http://dv-camaro1-xl07:8289/autozone/v1/page/createAccountPage'
      },
      curies: [
        {
          templated: true,
          name: 'oc',
          href: '/rels/{rel}'
        }
      ],
      'oc:getResetPasswordPageContents': {
        method: 'GET',
        href: 'http://dv-camaro1-xl07:8289/autozone/v1/page/resetPasswordPage'
      }
    },
    mf_forgotpasswordpage_forgot: 'Forgot your MyZone password?',
    mf_forgotpasswordpage_forgot_required: 'Required',
    mf_forgotpasswordpage_forgot_desc:
      'Enter the email address or username associated with your MyZone account',
    mf_forgotpasswordpage_forgot_button: 'Continue'
  };
});

describe('<ForgotForm />', () => {
  let PROPS = {};
  beforeEach(() => {
    PROPS = {
      label: 'test',
      input: jest.fn(),
      meta: jest.fn(),
      handleSubmit: jest.fn(),
      data: mockData
    };
  });
  test('renders correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <ForgotForm {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );

    // check classes for responsive design exist
    expect(wrapper.find('.hide-on-small-only').length).toBe(1);
    expect(wrapper.find('.show-on-small').length).toBe(1);
    expect(wrapper.find('.hide-on-med-and-up').length).toBe(1);

    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('calls handleSubmit prop on forgot form button click', () => {
    // create a mock store
    const store = createStore(() => ({}));

    // create a mock function to spy on
    const handleSubmit = jest.fn();

    // connect component with mock store
    const ConnectedForgotForm = connect(
      // mapStateToProps
      () => ({
        formValues: {}
      }),
      // mapDispatchToProps
      () => ({
        handleSubmit
      })
    )(ForgotForm);

    // create a component instance
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <ConnectedForgotForm data={mockData} />
        </MuiThemeProvider>
      </Provider>
    );

    // find the create account button and simulate a click event by calling its onClick prop
    wrapper
      .find(RaisedButton)
      .at(0)
      .props()
      .onClick();

    // check the number of calls to our mocked prop function
    expect(handleSubmit.mock.calls.length).toBe(1);
  });
});
