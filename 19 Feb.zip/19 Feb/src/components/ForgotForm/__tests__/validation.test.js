import validation from '../validation';

describe('ForgotForm validation', () => {
  const props = {
    data: {
      mf_forgotpasswordpage_forgot_required: 'required',
      mf_forgotpasswordpage_forgot_invalid_email: 'invalid'
    }
  };

  test('validates valid email successfully', () => {
    const values = {
      email: 'test@gmail.com'
    };
    const errors = validation(values, props);
    expect(errors.email).toBeUndefined();
  });

  test('validates invalid email successfully', () => {
    const values = {
      email: 'testgmail.com'
    };
    const errors = validation(values, props);
    expect(errors.email).toBe(
      props.data.mf_forgotpasswordpage_forgot_invalid_email
    );
  });
});
