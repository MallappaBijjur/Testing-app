/* @flow */
export default function(values: Object, props: Object) {
  const errors = {};
  const requiredFields = ['email'];
  requiredFields.forEach(field => {
    if (!values[field]) {
      errors[field] = props.data.mf_forgotpasswordpage_forgot_required;
    }
  });
  if (
    values.email &&
    !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)
  ) {
    errors.email = props.data.mf_forgotpasswordpage_forgot_invalid_email;
  }

  // if(values.email){
  //   if(values.email.indexOf('@') === -1) {
  //     if(!/^[a-zA-Z0-9]+$/i.test(values.email))
  //         errors.email = 'Username not valid';
  //   }
  //
  //   if(values.email.indexOf('@') !== -1 && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
  //       errors.email = props.data.mf_forgotpasswordpage_forgot_invalid_email;
  //   }
  // }
  return errors;
}
