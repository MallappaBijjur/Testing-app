/* @flow */
import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import TextField from 'material-ui/TextField';
import RaisedButton from 'material-ui/RaisedButton';
import { Field, reduxForm } from 'redux-form';
import * as styles from '../../containers/ForgotPassword/styles.scss';
import validate from './validation';

type Props = {
  data: Object,
  handleSubmit: () => void
};

type FieldProps = {
  label: string,
  input: Object,
  meta: Object
};

const styles1 = {
  floatingLabelFocusStyle: {
    background: 'white',
    height: '25px',
    'margin-top': '12px',
    padding: '0 5px',
    'line-height': '1px !important'
  }
};

const renderTextField: Function = ({
  label,
  input,
  meta: { touched, error }
}: FieldProps) => (
  <TextField
    id={label}
    floatingLabelText={label}
    hintText={label}
    className={styles.inputTextBox}
    floatingLabelFocusStyle={styles1.floatingLabelFocusStyle}
    errorText={touched && error}
    {...input}
  />
);

class ForgotForm extends PureComponent<Props> {
  render() {
    const { data, handleSubmit } = this.props;
    return (
      <div>
        <div className={styles.forgot_content}>
          <h1>{data.mf_forgotpasswordpage_forgot}</h1>
          <p>{data.mf_forgotpasswordpage_forgot_desc}</p>
        </div>
        <form>
          <div>
            <div style={{ paddingBottom: '20px', paddingTop: '10px' }}>
              <Field
                name="email"
                component={renderTextField}
                label={data.mf_forgotpasswordpage_forgot_label}
              />
            </div>
            <div className={`hide-on-small-only ${styles.regButtonSection}`}>
              <RaisedButton
                type="submit"
                onClick={handleSubmit}
                label={data.mf_forgotpasswordpage_forgot_button}
                className={styles.regPrimaryBtn}
              />
            </div>
            <div
              className={`show-on-small hide-on-med-and-up ${
                styles.regButtonMobileSection
              }`}
            >
              <RaisedButton
                type="submit"
                onClick={handleSubmit}
                label={data.mf_forgotpasswordpage_forgot_button}
                className={styles.regPrimaryBtn}
              />
            </div>
          </div>
        </form>
      </div>
    );
  }
}

const ForgotPWDForm = reduxForm({
  form: 'forgotFormValues',
  validate
})(ForgotForm);

export default connect(state => ({
  formValues: state
}))(ForgotPWDForm);
