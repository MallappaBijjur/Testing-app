/* @flow */
import React, { PureComponent } from 'react';

type Props = {
  slideCount: Number,
  slidesToScroll: Number,
  currentSlide: Number,
  goToSlide: (data: any) => void
};
class OverrideCarousel extends PureComponent<Props> {
  getIndexes = (count: any, inc: any) => {
    const arr = [];
    for (let i = 0; i < count; i += inc) {
      arr.push(i);
    }
    return arr;
  };

  getListStyles = () => ({
    margin: 0,
    top: '1.3em',
    padding: 0
  });

  getListItemStyles = () => ({
    listStyleType: 'none',
    display: 'inline-block'
  });

  getButtonStyles = (active: boolean) => ({
    border: active ? '1px solid black' : '1px solid #7c7c7c',
    borderRadius: '50%',
    width: active ? 10 : 7,
    height: active ? 10 : 7,
    background: active ? '#fff' : '#7c7c7c',
    cursor: 'pointer',
    outline: 0,
    opacity: 1,
    bottom: 0,
    margin: '0.1em',
    padding: 0
  });

  render() {
    const indexes = this.getIndexes(
      this.props.slideCount,
      this.props.slidesToScroll
    );
    return (
      <ul style={this.getListStyles()}>
        {indexes.map(index => (
          <li style={this.getListItemStyles()} key={index}>
            <button
              style={this.getButtonStyles(this.props.currentSlide === index)}
              key={`button_, ${index}!`}
              onClick={evt => {
                evt.preventDefault();
                this.props.goToSlide(index);
              }}
            />
          </li>
        ))}
      </ul>
    );
  }
}

const overrideDecorators = [
  {
    component: OverrideCarousel,
    position: 'BottomCenter'
  }
];

export default overrideDecorators;
