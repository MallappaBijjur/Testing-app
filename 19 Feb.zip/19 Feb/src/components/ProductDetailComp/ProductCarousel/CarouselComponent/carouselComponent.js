/* @flow */
import React, { PureComponent } from 'react';
import Carousel from 'nuka-carousel';
import { PinchView } from 'react-pinch-zoom-pan';
import carousalDecorators from './carousalDecorators';
import * as carouselStyle from './carousel.scss';
import * as styles from '../styles.scss';

type Props = {
  enlargedImages: any
};

class CarouselComponent extends PureComponent<Props> {
  componentDidMount() {
    setTimeout(() => {
      window.dispatchEvent(new Event('resize'));
    }, 0);
  }

  render() {
    const imageArr = this.props.enlargedImages;
    return (
      <div>
        <div className={carouselStyle.hero_banners}>
          <div className={carouselStyle.carousel_content}>
            <Carousel decorators={carousalDecorators}>
              {imageArr.map(item => (
                <div className={`${styles.imgHeight}`} key={item}>
                  <PinchView
                    backgroundColor="#fff"
                    maxScale={4}
                    containerRatio={400 / 600 * 100}
                  >
                    <img
                      src={item}
                      alt="Carousel"
                      style={{
                        margin: 'auto',
                        width: '300px',
                        height: '300px'
                      }}
                    />
                  </PinchView>
                </div>
              ))}
            </Carousel>
          </div>
        </div>
      </div>
    );
  }
}

export default CarouselComponent;
