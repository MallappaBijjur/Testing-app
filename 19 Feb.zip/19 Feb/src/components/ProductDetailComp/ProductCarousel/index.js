/* @flow */
import React, { PureComponent } from 'react';
import * as styles from './styles.scss';
import CarouselComponent from './CarouselComponent/carouselComponent';
import EnlargedImageComponent from './EnlargedImageComponent/enlargedImage';
import ThumbnailComponent from './ThumbnailComponent/thumbnailComponent';

type Props = {
  data: any
};

type State = {
  imgIndex: any
};

// Export this for unit testing more easily
class ProductCarousel extends PureComponent<Props, State> {
  constructor(props: any) {
    super(props);
    this.state = {
      imgIndex: this.props.data.viewInfo.azProductImageResponseVO
        .enlargedImages[0]
    };
  }

  showExpandedImage(index: any) {
    this.setState({
      imgIndex: this.props.data.viewInfo.azProductImageResponseVO
        .enlargedImages[index]
    });
  }

  render() {
    const enlargedImagesArr = this.props.data.viewInfo.azProductImageResponseVO
      .enlargedImages;
    const thumbnailsArr = this.props.data.viewInfo.azProductImageResponseVO
      .thumnailImages;
    if (thumbnailsArr.length > 0) {
      return (
        <div>
          <div className={`${styles.desktopSlider}`}>
            <EnlargedImageComponent
              enlargedImg={this.state.imgIndex}
              enlargedImages={enlargedImagesArr}
              thumbnailsArr={thumbnailsArr}
            />
            <div>
              <ThumbnailComponent
                thumbnailsArr={thumbnailsArr}
                showExpandedImage1={index => this.showExpandedImage(index)}
              />
            </div>
          </div>

          <div className={`${styles.mobileSlider}`}>
            <CarouselComponent enlargedImages={enlargedImagesArr} />
            <div className={styles.caption}>Pinch with 2 fingers to zoom</div>
          </div>
        </div>
      );
    }
    return <div className={styles.noProdMsg}>Image not available</div>;
  }
}

export default ProductCarousel;
