/* @flow */
import React, { PureComponent } from 'react';
import { Image, Modal } from 'semantic-ui-react';
import * as styles from '../styles.scss';

type Props = {
  enlargedImages: any,
  enlargedImg: any,
  thumbnailsArr: any
};

type State = {
  img: any
};

class EnlargedImageComponent extends PureComponent<Props, State> {
  constructor(props: any) {
    super(props);
    this.state = {
      img: this.props.enlargedImg
    };
  }
  showZoomedImg(index: number) {
    this.setState({ img: this.props.enlargedImages[index] });
  }

  showImg() {
    this.setState({ img: this.props.enlargedImg });
  }

  render() {
    const { thumbnailsArr } = this.props;
    const customStyles = {
      textAlign: 'center'
    };

    const img = {
      margin: 'auto',
      textAlign: 'center'
    };

    return (
      <Modal
        trigger={
          <div className={`${styles.enlargedImgBox}`}>
            <img
              onKeyDown={() => {}}
              src={this.props.enlargedImg}
              alt="Enlarged"
              role="presentation"
              onClick={() => this.showImg()}
            />
          </div>
        }
        size="large"
        style={customStyles}
        dimmer
        closeOnDocumentClick
        closeOnDimmerClick
      >
        <Modal.Content>
          <div>
            <Modal.Description className={styles.modalDescription}>
              <ul className={styles.modalDescUl}>
                {thumbnailsArr.map((thumbnailItem, thumbIndex) => (
                  <li
                    className={`${styles.thumbnailBox} ${styles.thumbSpacing} ${
                      styles.inlineImg
                    }`}
                    key={thumbnailItem}
                  >
                    <img
                      onKeyDown={() => {}}
                      src={thumbnailItem}
                      className={`${styles.thumbnailImage}`}
                      onClick={() => this.showZoomedImg(thumbIndex)}
                      alt="Thumbnail"
                      title="Thumbnail Image"
                      role="presentation"
                    />
                  </li>
                ))}
              </ul>
            </Modal.Description>
          </div>
          <div>
            <Image wrapped size="large" src={this.state.img} style={img} />
          </div>
        </Modal.Content>
      </Modal>
    );
  }
}

export default EnlargedImageComponent;
