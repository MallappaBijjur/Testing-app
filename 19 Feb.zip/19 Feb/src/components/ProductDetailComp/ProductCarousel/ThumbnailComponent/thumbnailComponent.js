/* @flow */
import React, { PureComponent } from 'react';
import * as styles from '../styles.scss';

type Props = {
  thumbnailsArr: any,
  showExpandedImage1: any
};

type State = {
  indexLength: any,
  indexes: any,
  disableLeft: boolean,
  disableRight: boolean,
  thumbnails: any
};

class ThumbnailComponent extends PureComponent<Props, State> {
  constructor(props: any) {
    super(props);

    const len = this.props.thumbnailsArr.length;
    let indexLen = 0;
    const indexArr = [];
    const thumbArr = [];
    if (len > 5) {
      indexLen = 5;
    } else {
      indexLen = len;
    }

    for (let i = 0; i < indexLen; i += 1) {
      indexArr.push(i);
      thumbArr.push(this.props.thumbnailsArr[i]);
    }

    this.state = {
      indexLength: indexLen,
      indexes: indexArr,
      disableLeft: true,
      disableRight: !(len > 5),
      thumbnails: thumbArr
    };
  }

  showExpandedImg = (index: any) => {
    if (this.props.showExpandedImage1) {
      this.props.showExpandedImage1(index);
    }
  };

  leftArrowClick = () => {
    const { indexes } = this.state;
    const thumbnails = this.props.thumbnailsArr;
    const tempArr = [];
    let disableLeft = true;
    let disableRight = true;

    if (indexes[0] === 0) {
      disableLeft = true;
    } else {
      disableLeft = false;
      for (let i = 0; i < indexes.length; i += 1) {
        indexes[i] -= 1;
      }
    }
    indexes.forEach(val => {
      tempArr.push(thumbnails[val]);
    });

    if (indexes[0] === 0) {
      disableLeft = true;
    } else {
      disableLeft = false;
    }

    if (indexes[this.state.indexLength - 1] === thumbnails.length - 1) {
      disableRight = true;
    } else {
      disableRight = false;
    }

    this.setState({
      thumbnails: tempArr,
      indexes,
      disableLeft,
      disableRight
    });
  };

  rightArrowClick() {
    const { indexes } = this.state;
    const thumbnails = this.props.thumbnailsArr;
    const tempArr = [];
    let disableRight = true;
    let disableLeft = false;

    if (indexes[this.state.indexLength - 1] === thumbnails.length - 1) {
      disableRight = true;
    } else {
      disableRight = false;
      for (let i = 0; i < indexes.length; i += 1) {
        indexes[i] += 1;
      }
    }
    indexes.forEach(val => {
      tempArr.push(thumbnails[val]);
    });

    if (indexes[this.state.indexLength - 1] === thumbnails.length - 1) {
      disableRight = true;
    } else {
      disableRight = false;
    }

    if (indexes[0] === 0) {
      disableLeft = true;
    } else {
      disableLeft = false;
    }

    this.setState({
      thumbnails: tempArr,
      indexes,
      disableRight,
      disableLeft
    });
  }

  render() {
    return (
      <div className={`${styles.thumbnailBlk}`}>
        <div
          onClick={this.leftArrowClick}
          onKeyDown={() => {}}
          disabled={this.state.disableLeft}
          className={`${styles.arrows} ${styles.leftArrow}`}
          role="presentation"
        >
          <img
            src="/images/left_arrow.png"
            alt="Left Arrow"
            title="Left Arrow"
            className={this.state.disableLeft ? `${styles.disabledArrow}` : ''}
          />
        </div>
        <ul>
          {this.state.thumbnails.map((thumbnailItem, thumbIndex) => (
            <li
              className={`${styles.thumbnailBox} ${styles.thumbSpacing} ${
                styles.inlineImg
              }`}
              key={thumbnailItem}
            >
              <img
                src={thumbnailItem}
                className={`${styles.thumbnailImage}`}
                onKeyDown={() => {}}
                onClick={() =>
                  this.showExpandedImg(this.state.indexes[thumbIndex])
                }
                key={this.state.indexes[thumbIndex]}
                alt="Thumbnail"
                title="Thumbnail Image"
                role="presentation"
              />
            </li>
          ))}
        </ul>
        <div
          onClick={() => this.rightArrowClick()}
          onKeyDown={() => {}}
          disabled={this.state.disableRight}
          className={`${styles.arrows} ${styles.rightArrow}`}
          role="presentation"
        >
          <img
            src="/images/right_arrow.png"
            alt="Right Arrow"
            title="Right Arrow"
            className={this.state.disableRight ? `${styles.disabledArrow}` : ''}
          />
        </div>
      </div>
    );
  }
}

export default ThumbnailComponent;
