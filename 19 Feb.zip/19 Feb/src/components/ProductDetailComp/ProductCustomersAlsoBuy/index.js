/* @flow */
import React from 'react';
import * as styles from './styles.scss';

const ProductCustomersAlsoBuy = () => (
  <div className={`row ${styles.frequent_container}`}>
    <div className={styles.frequent_inner}>
      <div className="col m3">
        <span className={styles.frequent_heading}>customers also buy</span>
        <img
          src="/images/rectangle.png"
          className={styles.recommend_titleImg}
          alt="underline"
        />
      </div>
      <div className="col m3">
        <div className={styles.frequent_grid}>
          <div className={`${styles.productPrice} ${styles.price_val}`}>
            <span className={styles.dollarSign}>$</span>
            <span className={styles.dollarValue}>124</span>
            <span className={styles.centValue}>96</span>
          </div>
          <img
            className={styles.product_img}
            src="/images/product_part_1.png"
            alt="Product"
            role="presentation"
          />
          <div className={styles.titleProduct}>DURALAST PLATINUM BATTERY</div>
          <div className={styles.ratingProduct}>
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
          </div>
        </div>
      </div>
      <div className="col m3">
        <div className={styles.frequent_grid}>
          <div className={`${styles.productPrice} ${styles.price_val}`}>
            <span className={styles.dollarSign}>$</span>
            <span className={styles.dollarValue}>124</span>
            <span className={styles.centValue}>96</span>
          </div>
          <img
            className={styles.product_img}
            src="/images/product_part_1.png"
            alt="Product"
            role="presentation"
          />
          <div className={styles.titleProduct}>DURALAST PLATINUM BATTERY</div>
          <div className={styles.ratingProduct}>
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
          </div>
        </div>
      </div>
      <div className="col m3">
        <div className={styles.frequent_grid}>
          <div className={`${styles.productPrice} ${styles.price_val}`}>
            <span className={styles.dollarSign}>$</span>
            <span className={styles.dollarValue}>124</span>
            <span className={styles.centValue}>96</span>
          </div>
          <img
            className={styles.product_img}
            src="/images/product_part_1.png"
            alt="Product"
            role="presentation"
          />
          <div className={styles.titleProduct}>DURALAST PLATINUM BATTERY</div>
          <div className={styles.ratingProduct}>
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
          </div>
        </div>
      </div>
    </div>
  </div>
);

export default ProductCustomersAlsoBuy;
