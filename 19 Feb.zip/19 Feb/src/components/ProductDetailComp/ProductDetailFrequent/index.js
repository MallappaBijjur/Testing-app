/* @flow */
import React from 'react';
import * as styles from '../../../containers/ProductDetail/styles.scss';

// Export this for unit testing more easily
const ProductDetailFrequent = () => (
  <div className={`row ${styles.frequent_container}`}>
    <div className={styles.frequent_inner}>
      <div className="col m3">
        <span className={styles.frequent_heading}>
          products frequently bought together
        </span>
        <img
          src="/images/rectangle.png"
          className={styles.recommend_titleImg}
          alt="Underline"
        />
      </div>
      <div className="col m3">
        <div className={styles.frequent_grid}>
          <div className={styles.price_val}>$343.99</div>
          <img
            className={styles.product_img}
            src="/images/duralast-static.png"
            alt="Product"
            role="presentation"
          />
          <div className={styles.titleProduct}>DURALAST PLATINUM BATTERY</div>
          <div className={styles.ratingProduct}>
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
          </div>
        </div>
      </div>
      <div className="col m3">
        <div className={styles.frequent_grid}>
          <div className={styles.price_val}>$123.99</div>
          <img
            className={styles.product_img}
            src="/images/duralast-static.png"
            alt="Product"
            role="presentation"
          />
          <div className={styles.titleProduct}>DURALAST PLATINUM BATTERY</div>
          <div className={styles.ratingProduct}>
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
          </div>
        </div>
      </div>
      <div className="col m3">
        <div className={styles.frequent_grid}>
          <div className={styles.price_val}>$555.99</div>
          <img
            className={styles.product_img}
            src="/images/duralast-static.png"
            alt="Product"
            role="presentation"
          />
          <div className={styles.titleProduct}>DURALAST PLATINUM BATTERY</div>
          <div className={styles.ratingProduct}>
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
            <img src="/images/star.png" alt="star" />
          </div>
        </div>
      </div>
    </div>
  </div>
);

// // const connector: Connector<{}, Props> = connect(null);
// const connector: Connector<{}, Props> = connect(
//   ({ forgotData }: ReduxState) => ({
//     forgotData
//   }),
//   (dispatch: Dispatch) => ({
//     fetchForgotAccountData: () =>
//       dispatch(forgotAccount.fetchForgotAccountData())
//   })
// );
export default ProductDetailFrequent;
// export default connect(null)(ForgotPassword);
