/* @flow */
import React, { PureComponent } from 'react';
import { Breadcrumb } from 'semantic-ui-react';
import * as styles from '../styles.scss';

type Props = {
  data: any
};

class DesktopCrumb extends PureComponent<Props> {
  render() {
    const breadcrumbsList = this.props.data;
    return (
      <Breadcrumb className={styles.breadcrumbLinkAZ}>
        <Breadcrumb.Section className={styles.homeLink}>
          <a href="/home" className={styles.homeLink}>
            Home{' '}
          </a>
        </Breadcrumb.Section>
        <Breadcrumb.Divider className={styles.dividerLink} />
        {breadcrumbsList &&
          breadcrumbsList.map((breadcrumbItem, index) => {
            if (
              parseInt(index, 10) === parseInt(breadcrumbsList.length - 1, 10)
            ) {
              return (
                <Breadcrumb.Section
                  active
                  key={breadcrumbItem.displayName}
                  className={styles.activeLink}
                >
                  {' '}
                  {breadcrumbItem.displayName}{' '}
                </Breadcrumb.Section>
              );
            }
            return (
              <span key={breadcrumbItem.displayName}>
                <Breadcrumb.Section className={styles.homeLink}>
                  <a href={breadcrumbItem.url} className={styles.homeLink}>
                    {' '}
                    {breadcrumbItem.displayName}{' '}
                  </a>
                </Breadcrumb.Section>
                <Breadcrumb.Divider className={styles.dividerLink} />
              </span>
            );
          })}
      </Breadcrumb>
    );
  }
}

export default DesktopCrumb;
