/* @flow */
import React, { PureComponent } from 'react';
import * as styles from './styles.scss';

type Props = {
  badgesData: Object
};

class Badges extends PureComponent<Props> {
  render() {
    const { badgesData } = this.props;
    const lastBadge =
      badgesData.dealAvailable === 'true' &&
      !(
        badgesData.vehicleFit === 'true' &&
        badgesData.eligibleForNextDay === 'true'
      );
    return (
      <div>
        {badgesData.eligibleForNextDay === 'true' && (
          <div className={styles.enjoyPart}>NEXT-DAY DELIVERY</div>
        )}
        {badgesData.vehicleFit === 'true' && (
          <div className={styles.enjoyPart}>VECHICLE SPECIFIC</div>
        )}
        {badgesData.dealAvailable === 'true' && (
          <div className={styles.savenow}>SAVE NOW</div>
        )}
        {lastBadge && <div className={styles.pricecut}>PRICE CUT</div>}
      </div>
    );
  }
}

export default Badges;
