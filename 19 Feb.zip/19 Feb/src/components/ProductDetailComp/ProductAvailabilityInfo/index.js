/* @flow */
import React, { PureComponent } from 'react';
import type { Connector } from 'react-redux';
import { connect } from 'react-redux';
import RaisedButton from 'material-ui/RaisedButton';
import { Icon } from 'semantic-ui-react';
import * as styles from './styles.scss';
import Badges from './Badges';
import PartCart from '../ProductPart';
import ProductCarousel from '../ProductCarousel';
import * as BazaarVoice from '../../ThirdPartyApis/BazaarVoiceAPI';
import * as productAction from '../../../actions/productDetails';
import type { Dispatch } from '../../../types';

type Props = {
  data: any,
  addToCartCall: (data: any) => void
};

type State = {
  expanded: boolean,
  count: number,
  price: any,
  staticPrice: any
};

// Export this for unit testing more easily
class ProductAvailability extends PureComponent<Props, State> {
  constructor(props: any) {
    super(props);
    this.state = {
      expanded: false,
      count: 1,
      price: this.props.data.viewInfo.productAvailabilityInfo[0].retailPrice,
      staticPrice: this.props.data.viewInfo.productAvailabilityInfo[0]
        .retailPrice
    };
  }

  componentWillMount() {
    BazaarVoice.loadBazaarVoiceRating();
  }

  onToggleClick = () => {
    this.setState({
      expanded: !this.state.expanded
    });
  };

  incrementCount = () => {
    const countValue = this.state.count + 1;
    const multiplyValue = (this.state.staticPrice * countValue).toFixed(2);
    this.setState({
      count: countValue,
      price: multiplyValue
    });
  };

  decrementCount = val => {
    const countValue = this.state.count - 1;
    const minusValue = (val - this.state.staticPrice).toFixed(2);
    this.setState({
      count: countValue,
      price: minusValue
    });
  };

  addToCart = forPostData => {
    const postData = forPostData;
    postData.quantity = this.state.count;
    postData.skuNumber = this.props.data.viewInfo.productAvailabilityInfo[0].skuId;
    this.props.addToCartCall(postData);
  };

  render() {
    const productData = this.props.data.viewInfo;
    const mainTitle = productData.azPDPResponseVO;
    const retailPrice = this.state.price.toString().split('.');
    const forPostData = productData.azPdpAddToCartVO;
    const { catalogRefId } = forPostData;

    return (
      <div className={`row ${styles.font}`}>
        <div className="col s12 m6">
          <div className="row">
            <Badges badgesData={productData.aZBadgesFlagVO} />
          </div>
          <div>
            <ProductCarousel data={this.props.data} />
          </div>
        </div>
        <div className="col s12 m6">
          <div>
            <span className={styles.titleProduct}>
              {' '}
              {mainTitle.skuDescription}{' '}
            </span>
          </div>
          {mainTitle.quickNote !== 'Optional' && (
            <div>
              <span className={styles.productSubTitle}>
                {' '}
                {mainTitle.quickNote}{' '}
              </span>
            </div>
          )}
          {productData.azVehicleFitproductResponseVO.vehicleFit === 'true' && (
            <div
              className={`center-align truncate ${styles.thisFits} ${
                styles.mt20
              }`}
            >
              <span>
                <Icon
                  name="check circle"
                  size="large"
                  style={{ color: 'green' }}
                />
              </span>
              <span className={styles.greenFits}>THIS FITS &nbsp;</span>
              <span>
                {productData.azVehicleFitProductResponseVO.vehicleDescription}
              </span>
            </div>
          )}
          <div className={styles.mt20}>
            <div
              id="ratingsTop"
              data-bv-show="rating_summary"
              data-bv-productid={catalogRefId}
            />
          </div>
          <div className={`row ${styles.mt20}`}>
            {mainTitle.pdpDetails.PartNumber !== '' && (
              <div className="col m4">
                <strong>Part &#35; {mainTitle.pdpDetails.PartNumber}</strong>
              </div>
            )}
            {mainTitle.pdpDetails.Warranty !== '' && (
              <div className="col m4">
                <u>
                  <strong>Warranty: {mainTitle.pdpDetails.Warranty}</strong>
                </u>
              </div>
            )}
            {mainTitle.pdpDetails.Location &&
              mainTitle.pdpDetails.Location !== '' && (
                <div className="col m4">
                  <strong>Location: {mainTitle.pdpDetails.Location}</strong>
                </div>
              )}
          </div>
          <div
            className={` ${
              this.state.expanded ? styles.noteMore : styles.note
            }`}
          >
            <strong>Notes: </strong>
            {mainTitle.pdpDetails.TechNotes}
          </div>
          {mainTitle.pdpDetails.TechNotes &&
            mainTitle.pdpDetails.TechNotes.length > 166 && (
              <div
                className="show-on-medium-and-up hide-on-med-and-down"
                style={{ margin: '0.3em 0em 2.3em 0em' }}
              >
                {!this.state.expanded ? (
                  <a
                    href="#/"
                    className={styles.readmore}
                    onClick={this.onToggleClick}
                  >
                    Read More
                  </a>
                ) : (
                  ''
                )}
                {this.state.expanded ? (
                  <a
                    href="#/"
                    className={styles.readmore}
                    onClick={this.onToggleClick}
                  >
                    Read Less
                  </a>
                ) : (
                  ''
                )}
              </div>
            )}
          {mainTitle.pdpDetails.TechNotes &&
            mainTitle.pdpDetails.TechNotes.length > 71 && (
              <div
                className="show-on-small hide-on-med-and-up"
                style={{ margin: '0.3em 0em 2.3em 0em' }}
              >
                {!this.state.expanded ? (
                  <a
                    href="#/"
                    className={styles.readmore}
                    onClick={this.onToggleClick}
                  >
                    Read More
                  </a>
                ) : (
                  ''
                )}
                {this.state.expanded ? (
                  <a
                    href="#/"
                    className={styles.readmore}
                    onClick={this.onToggleClick}
                  >
                    Read Less
                  </a>
                ) : (
                  ''
                )}
              </div>
            )}
          <hr className={styles.mt20} />
          <div className={`row ${styles.mt20}`}>
            <div className="col s6 m6">
              <span className={styles.priceSub}>$</span>
              <span className={styles.price}>{retailPrice[0]}</span>
              <span className={styles.priceSub}>{retailPrice[1]}</span>
            </div>
            <div className="col s6 m6">
              <span className="right">
                <span className={`hide-on-small-only ${styles.qty}`}>Qty </span>
                <button
                  className={styles.round}
                  disabled={this.state.count <= 1}
                  onClick={() => this.decrementCount(this.state.price)}
                >
                  <strong>-</strong>
                </button>
                <input
                  className={`center-align ${styles.qtyTextBoz}`}
                  type="text"
                  value={this.state.count}
                />
                <button
                  className={styles.round}
                  onClick={() => this.incrementCount()}
                >
                  <strong>+</strong>
                </button>
              </span>
            </div>
          </div>
          <div>
            <PartCart data={productData} />
          </div>
          <div className={`${styles.addToCartBtnSection} ${styles.mt20}`}>
            <RaisedButton
              type="submit"
              label="ADD TO CART"
              className={styles.addToCartBtnBtn}
              onClick={() => this.addToCart(forPostData)}
            />
          </div>
        </div>
      </div>
    );
  }
}

const connector: Connector<{}> = connect((dispatch: Dispatch) => ({
  addToCartCall: forPostData =>
    dispatch(productAction.addToCartCall(forPostData))
}));

/* const connector: Connector<{}> = connect(
  ({  }: ReduxState) => ({}),
  () => (dispatch: Dispatch) => ({
    addToCartCall: forPostData =>
      dispatch(productAction.addToCartCall(forPostData))
  })
); */
export default connector(ProductAvailability);
