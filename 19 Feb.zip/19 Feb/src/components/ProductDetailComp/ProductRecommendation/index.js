/* @flow */
import React from 'react';
import * as styles from './styles.scss';

const ProductRecommendation = () => (
  <div className={`row ${styles.recommend_container}`}>
    <div className={`${styles.recommend_title}`}>
      RECOMMENDED <b>FOR YOU</b>
    </div>
    <img
      src="/images/rectangle.png"
      alt="Underline"
      className={styles.recommend_titleImg}
    />
    <div>
      <div className="col m3">
        <div className={styles.gridContainer}>
          <div className={styles.badgeBlk}>
            <img
              src="/images/badge.png"
              className={styles.badge}
              alt="badge"
              role="presentation"
              title="Free Next Day Delivery Badge"
            />
          </div>
          <div className={styles.productImgBlk}>
            <img
              src="/images/product_part_1.png"
              className={styles.productImg}
              alt="product"
              role="presentation"
              title="Product"
            />
          </div>
          <div className={styles.productPricingBlk}>
            <div className={styles.productName}>POPULAR PART NAME</div>
            <div className={styles.productPrice}>
              <span className={styles.dollarSign}>$</span>
              <span className={styles.dollarValue}>124</span>
              <span className={styles.centValue}>96</span>
            </div>
            <div className={styles.seeDetailBlk}>
              <span className={styles.seeDetailTxt}>SEE DETAILS</span>
              <span className={styles.seeDetailArrow}>
                <img src="/images/arrow_orange.png" alt="Underline" />
              </span>
            </div>
          </div>
        </div>
      </div>
      <div className="col m3">
        <div className={styles.gridContainer}>
          <div className={styles.badgeBlk}>
            <img
              src="/images/hot-deal.png"
              className={styles.badge}
              alt="badge"
              role="presentation"
              title="Free Next Day Delivery Badge"
            />
          </div>
          <div className={styles.productImgBlk}>
            <img
              src="/images/product_part_2.png"
              className={styles.productImg}
              alt="product"
              role="presentation"
              title="Product"
            />
          </div>
          <div className={styles.productPricingBlk}>
            <div className={styles.productName}>POPULAR PART NAME</div>
            <div className={styles.productPrice}>
              <span className={styles.dollarSign}>$</span>
              <span className={styles.dollarValue}>124</span>
              <span className={styles.centValue}>96</span>
            </div>
            <div className={styles.seeDetailBlk}>
              <span className={styles.seeDetailTxt}>SEE DETAILS</span>
              <span className={styles.seeDetailArrow}>
                <img src="/images/arrow_orange.png" alt="Underline" />
              </span>
            </div>
          </div>
        </div>
      </div>
      <div className="col m3">
        <div className={styles.gridContainer}>
          <div className={styles.badgeBlk}>
            <img
              src="/images/new.png"
              className={styles.badge}
              alt="badge"
              role="presentation"
              title="Free Next Day Delivery Badge"
            />
          </div>
          <div className={styles.productImgBlk}>
            <img
              src="/images/product_part_2.png"
              className={styles.productImg}
              alt="product"
              role="presentation"
              title="Product"
            />
          </div>
          <div className={styles.productPricingBlk}>
            <div className={styles.productName}>POPULAR PART NAME</div>
            <div className={styles.productPrice}>
              <span className={styles.dollarSign}>$</span>
              <span className={styles.dollarValue}>124</span>
              <span className={styles.centValue}>96</span>
            </div>
            <div className={styles.seeDetailBlk}>
              <span className={styles.seeDetailTxt}>SEE DETAILS</span>
              <span className={styles.seeDetailArrow}>
                <img src="/images/arrow_orange.png" alt="Underline" />
              </span>
            </div>
          </div>
        </div>
      </div>
      <div className="col m3">
        <div className={styles.gridContainer}>
          <div className={styles.badgeBlk}>
            <img
              src="/images/new.png"
              className={styles.badge}
              alt="badge"
              role="presentation"
              title="Free Next Day Delivery Badge"
            />
          </div>
          <div className={styles.productImgBlk}>
            <img
              src="/images/product_part_2.png"
              className={styles.productImg}
              alt="product"
              role="presentation"
              title="Product"
            />
          </div>
          <div className={styles.productPricingBlk}>
            <div className={styles.productName}>POPULAR PART NAME</div>
            <div className={styles.productPrice}>
              <span className={styles.dollarSign}>$</span>
              <span className={styles.dollarValue}>124</span>
              <span className={styles.centValue}>96</span>
            </div>
            <div className={styles.seeDetailBlk}>
              <span className={styles.seeDetailTxt}>SEE DETAILS</span>
              <span className={styles.seeDetailArrow}>
                <img src="/images/arrow_orange.png" alt="Underline" />
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

export default ProductRecommendation;
