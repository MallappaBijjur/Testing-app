/* @flow */

import React, { Component } from 'react';
import styles from './styles.scss';

type Props = {
  data: Object
};

type State = {
  activeStore: boolean,
  activeShip: boolean
};

class PartCart extends Component<Props, State> {
  constructor(props: any) {
    super(props);
    this.state = {
      activeStore: false,
      activeShip: true
    };
  }

  setActiveClass = (tog: string) => {
    let storeFlag;
    let shipFlag;
    if (tog === 'store') {
      storeFlag = true;
      shipFlag = false;
    } else {
      storeFlag = false;
      shipFlag = true;
    }
    this.setState({
      activeStore: storeFlag,
      activeShip: shipFlag
    });
  };

  render() {
    const { data } = this.props;
    const availabilityInfo = data.productAvailabilityInfo[0];
    const storeClass = this.state.activeStore ? styles.active : styles.inactive;
    const shipClass = this.state.activeShip ? styles.active : styles.inactive;
    return (
      <div className="row" id="productPart">
        <button
          className={`col s6 m6 ${styles.text} ${styles.pickup} ${storeClass}
            ${availabilityInfo.storePickupAvailable ? '' : styles.notAllowed}`}
          disabled={!availabilityInfo.storePickupAvailable}
          onClick={() => this.setActiveClass('store')}
        >
          <div className={styles.layout}>
            <section className={styles.store}> Store Pick Up </section>
            <section
              className={`${
                availabilityInfo.storePickupStockLabel !== 'Out of Stock'
                  ? styles.greenFont
                  : styles.redFont
              }`}
            >
              {availabilityInfo.storePickupStockLabel}
            </section>
          </div>
        </button>
        <button
          className={`col s6 m6 ${styles.text} ${styles.pickup} ${shipClass}
            ${availabilityInfo.shipToHomeAvailable ? '' : styles.notAllowed}`}
          disabled={!availabilityInfo.shipToHomeAvailable}
          onClick={() => this.setActiveClass('ship')}
        >
          <div className={styles.layout}>
            <section className={styles.store}> Ship-To-Home </section>
            <section
              className={
                availabilityInfo.shipToHomeStockLabel !== 'Not Available'
                  ? styles.greenFont
                  : styles.redFont
              }
            >
              {availabilityInfo.shipToHomeStockLabel}
            </section>
          </div>
        </button>
        {/* <div className={styles.cart}>
          <Button color="black" fluid>
            ADD TO CART{' '}
          </Button>
        </div> */}
      </div>
    );
  }
}

export default PartCart;
