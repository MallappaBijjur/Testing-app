/* @flow */

import React, { PureComponent } from 'react';
import * as styles from '../../../containers/ProductDetail/styles.scss';

type Props = {
  data: any
};

type State = {
  seeMore: boolean,
  descMore: boolean
};

// Export this for unit testing more easily
class ProductDetailSpecification extends PureComponent<Props, State> {
  constructor(props: any) {
    super(props);
    this.state = {
      seeMore: true,
      descMore: true
    };
  }

  examplePart = () => {
    if (this.state.seeMore) {
      this.setState({ seeMore: false });
    } else {
      this.setState({ seeMore: true });
    }
  };
  examplePartDesc = () => {
    if (this.state.descMore) {
      this.setState({ descMore: false });
    } else {
      this.setState({ descMore: true });
    }
  };

  renderProdSpec = (more: boolean) => {
    const {
      productSpecification
    } = this.props.data.azPDPResponseVO.azFeaturesAndBenefit;
    return (
      <div>
        {Object.keys(productSpecification).map((colItem, col) => {
          if (more) {
            if (col <= 10) {
              if (col % 2 === 0) {
                return (
                  <div
                    className={`row ${styles.specInnerRowGrey}`}
                    key={`${colItem}_more_even`}
                  >
                    <div className="col m7 s12">{colItem}</div>
                    <div className="col m5 s12">
                      <b>{productSpecification[colItem]}</b>
                    </div>
                  </div>
                );
              }
              return (
                <div
                  className={`row ${styles.specInnerRow}`}
                  key={`${colItem}_more_odd`}
                >
                  <div className="col m7 s12">{colItem}</div>
                  <div className="col m5 s12">
                    <b>{productSpecification[colItem]}</b>
                  </div>
                </div>
              );
            }
            return null;
          } else if (!more) {
            if (col % 2 === 0) {
              return (
                <div
                  className={`row ${styles.specInnerRowGrey}`}
                  key={`${colItem}_less_even`}
                >
                  <div className="col m7 s12">{colItem}</div>
                  <div className="col m5 s12">
                    <b>{productSpecification[colItem]}</b>
                  </div>
                </div>
              );
            }
            return (
              <div
                className={`row ${styles.specInnerRow}`}
                key={`${colItem}_less_odd`}
              >
                <div className="col m7 s12">{colItem}</div>
                <div className="col m5 s12">
                  <b>{productSpecification[colItem]}</b>
                </div>
              </div>
            );
          }
          return null;
        })}
      </div>
    );
  };
  renderProdSpecMobile = (more: boolean) => {
    const {
      productSpecification
    } = this.props.data.azPDPResponseVO.azFeaturesAndBenefit;
    return (
      <div>
        {Object.keys(productSpecification).map((colItem, col) => {
          if (more) {
            if (col <= 3) {
              if (col % 2 === 0) {
                return (
                  <div
                    className={`row ${styles.specInnerRowGrey}`}
                    key={`${colItem}_even_mob`}
                  >
                    <div className="col m7 s12">{colItem}</div>
                    <div className="col m5 s12">
                      {productSpecification[colItem]}
                    </div>
                  </div>
                );
              }
              return (
                <div
                  className={`row ${styles.specInnerRow}`}
                  key={`${colItem}_odd_mob`}
                >
                  <div className="col m7 s12">{colItem}</div>
                  <div className="col m5 s12">
                    {productSpecification[colItem]}
                  </div>
                </div>
              );
            }
            return null;
          } else if (!more) {
            if (col % 2 === 0) {
              return (
                <div
                  className={`row ${styles.specInnerRowGrey}`}
                  key={`${colItem}_less_even`}
                >
                  <div className="col m7 s12">{colItem}</div>
                  <div className="col m5 s12">
                    <b>{productSpecification[colItem]}</b>
                  </div>
                </div>
              );
            }
            return (
              <div
                className={`row ${styles.specInnerRow}`}
                key={`${colItem}_less_odd`}
              >
                <div className="col m7 s12">{colItem}</div>
                <div className="col m5 s12">
                  <b>{productSpecification[colItem]}</b>
                </div>
              </div>
            );
          }
          return null;
        })}
      </div>
    );
  };

  renderProdDesc = () => {
    const desc = this.props.data.azPDPResponseVO.azFeaturesAndBenefit.value;
    const {
      featureAttributes
    } = this.props.data.azPDPResponseVO.azFeaturesAndBenefit;
    return (
      <div className={`row ${styles.specInnerRow}`}>
        <div className="col m12">
          {desc}
          <ul className={styles.feature}>
            {featureAttributes.map(x => (
              <li className={styles.featurelist} key={`${x}_feture_attribute`}>
                <img src="/images/checkmark.png" alt="checkmark" />
                {x}
              </li>
            ))}
          </ul>
        </div>
      </div>
    );
  };

  render() {
    return (
      <div className="row">
        <div className={styles.mainHeadProduct}>
          PRODUCT <b>OVERVIEW</b>
        </div>
        <img
          className={styles.bordImg}
          src="/images/rectangle.png"
          alt="Underline"
        />
        <div className="col m8 s12">
          <div className={styles.overview_inner}>
            <h3> PRODUCT SPECIFICATIONS</h3>
            <div className="hide-on-small-only">
              {this.renderProdSpec(this.state.seeMore)}
              <span className={styles.read}>
                {' '}
                {this.state.seeMore ? (
                  <a href="#/" onClick={this.examplePart}>
                    Read More
                  </a>
                ) : (
                  ''
                )}{' '}
              </span>
              <span className={styles.read}>
                {' '}
                {!this.state.seeMore ? (
                  <a href="#/" onClick={this.examplePart}>
                    Read Less
                  </a>
                ) : (
                  ''
                )}{' '}
              </span>
            </div>
            <div className="show-on-small hide-on-med-and-up">
              {this.renderProdSpecMobile(this.state.seeMore)}
              <span className={styles.read}>
                {' '}
                {this.state.seeMore ? (
                  <a href="#/" onClick={this.examplePart}>
                    Read More
                  </a>
                ) : (
                  ''
                )}{' '}
              </span>
              <span className={styles.read}>
                {' '}
                {!this.state.seeMore ? (
                  <a href="#/" onClick={this.examplePart}>
                    Read Less
                  </a>
                ) : (
                  ''
                )}{' '}
              </span>
            </div>
          </div>
        </div>
        <div className="col m4 s12">
          <div className={styles.overview_inner}>
            <h3> PRODUCT DESCRIPTION</h3>
            <div className="hide-on-small-only">{this.renderProdDesc()}</div>
            <div className="show-on-small hide-on-med-and-up">
              {this.state.descMore && (
                <div className={styles.mobileDesc}>{this.renderProdDesc()}</div>
              )}
              {!this.state.descMore && <div>{this.renderProdDesc()}</div>}
              <span className={styles.read}>
                {' '}
                {this.state.descMore ? (
                  <a href="#/" onClick={this.examplePartDesc}>
                    Read More
                  </a>
                ) : (
                  ''
                )}{' '}
              </span>
              <span className={styles.read}>
                {' '}
                {!this.state.descMore ? (
                  <a href="#/" onClick={this.examplePartDesc}>
                    Read Less
                  </a>
                ) : (
                  ''
                )}{' '}
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default ProductDetailSpecification;
