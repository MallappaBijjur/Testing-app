/* @flow */
import React from 'react';
import type { Connector } from 'react-redux';
import { connect } from 'react-redux';
import RaisedButton from 'material-ui/RaisedButton';
import * as shelfData from '../../actions/shelf';
import styles from './styles.scss';
import type { Dispatch, ReduxState } from '../../types';

type Props = { setView: boolean => void, isList: Boolean };

class DropDownSort extends React.Component<Props> {
  setView(view) {
    this.props.setView(view);
  }

  render() {
    const { isList } = this.props;
    return (
      <div>
        <RaisedButton
          className={styles.sortIcons}
          onClick={() => this.setView(true)}
          disabled={isList}
        >
          {' '}
          LIST{' '}
        </RaisedButton>
        <RaisedButton
          className={styles.sortIcons}
          onClick={() => this.setView(false)}
        >
          {' '}
          GRID{' '}
        </RaisedButton>
      </div>
    );
  }
}

const connector: Connector<{}, Props> = connect(
  ({ shelf }: ReduxState) => ({
    isList: shelf.isList
  }),
  (dispatch: Dispatch) => ({
    setView: view => dispatch(shelfData.setView(view))
  })
);

export default connector(DropDownSort);
