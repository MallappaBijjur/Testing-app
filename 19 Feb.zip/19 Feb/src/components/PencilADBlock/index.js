/* @flow */

import React from 'react';
import { Button } from 'semantic-ui-react';
import styles from './styles.scss';

const PencilAd = () => (
  <div className={styles.pencilAd}>
    <h3 className={styles.boldText}>
      Save $10 on Duralast battery
      <span className={styles.softText}> offer valid for limited time</span>
    </h3>
    <Button className={styles.buynowbutton} content="BUY NOW" basic />
  </div>
);

export default PencilAd;
