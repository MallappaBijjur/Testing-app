/* @flow */

import React from 'react';
import type { Element } from 'react';
import { Breadcrumb } from 'semantic-ui-react';
import styles from './styles.scss';

const sections = [
  { key: 'home', content: 'Home', link: true },
  { key: 'registration', content: 'Registration', link: true },
  { key: 'info', content: 'Personal Information', active: true }
];

// type Props = { info: Object };

const BreadcrumbNav = (): Element<'div'> => (
  <div className={styles.custombreadcrumb}>
    <Breadcrumb
      className={styles.breadcrumbs}
      divider="/"
      sections={sections}
    />
  </div>
);

export default BreadcrumbNav;
