/* @flow */
import React from 'react';

const TestCard = (): any => <div>TEST</div>;

export default TestCard;
