/* @flow */
import React, { PureComponent } from 'react';
import { Grid, Popup, List } from 'semantic-ui-react';
import { Link } from 'react-router-dom';
import styles from './styles.scss';
import { myAccQaAPI } from '../../config/serviceAPI';

type Props = {
  myAccountTitles: Object
};

type State = {
  auth: boolean
};

class MyAccount extends PureComponent<Props, State> {
  state = {
    auth: false
  };

  menuItems() {
    const { myAccountTitles } = this.props;
    let items;
    const { auth } = this.state;
    if (myAccountTitles) {
      if (auth) {
        items = (
          <span>
            <List.Item className={styles.listItem}>Hi User</List.Item>
            <List.Item className={styles.listItem}>My Profile</List.Item>
            <List.Item className={styles.listItem}>
              <span className={styles.subInfoDesktop}>
                {myAccountTitles.mf_homepage_header_trackmanage}
              </span>
            </List.Item>
          </span>
        );
        return items;
      }

      items = (
        <span className={styles.linkStyle}>
          <a className={styles.linktext} href={myAccQaAPI}>
            <List.Item className={styles.listItem}>
              {' '}
              {myAccountTitles.mf_homepage_header_signin}{' '}
            </List.Item>
          </a>
          <Link className={styles.linktext} to="/create">
            <List.Item className={styles.listItem}>
              {' '}
              {myAccountTitles.mf_homepage_header_createaccount}
            </List.Item>
          </Link>
          <List.Item className={styles.listItem}>
            {myAccountTitles.mf_homepage_header_trackorder}
            <span className={styles.subInfoDesktop}>
              {myAccountTitles.mf_homepage_header_trackmanage}
            </span>
          </List.Item>
        </span>
      );
      return items;
    }
    return '';
  }

  render() {
    const { auth } = this.state;
    const renderTrigger = (
      <div className={styles.myAccount}>
        <img src="/images/az-user.png" alt="user" />
        <span className={styles.account}>
          {!auth ? 'My Account' : 'Hi John'}
        </span>
        <img src="/images/dark.png" alt="down" />
      </div>
    );

    return (
      <Grid as="span" className={styles.myAccounts}>
        <Grid className={styles.top30} as="span">
          <Popup wide trigger={renderTrigger} on="click" position="bottom left">
            <Grid as="span" className={styles.top30} padded>
              <List>{this.menuItems()}</List>
            </Grid>
          </Popup>
        </Grid>

        <div as="span" className={styles.contact}>
          <img className={styles.mt} src="/images/az-chat.png" alt="contact" />
          Contact Us
        </div>
      </Grid>
    );
  }
}

export default MyAccount;
