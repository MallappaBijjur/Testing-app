/* @flow */

import React from 'react';
import type { Element } from 'react';
import MyAccount from '../MyAccount/MyAccount';

type Props = {
  styles: Object,
  myAccountTitles: Object
};

const NavInfo = (props: Props): Element<'div'> => (
  <div className={props.styles.navinfo}>
    <div className={props.styles.topContainer}>
      <div>
        <span className={props.styles.storeContainer}>
          <img
            className={props.styles.mt}
            src="/images/az-location.png"
            alt="drop icon"
          />{' '}
          Store:
        </span>
        <span className={props.styles.storeText}>1050 Elvis Presley Blvd</span>
      </div>
      <div>
        <span className={props.styles.openTil}>
          Open til &#39; 9 PM <img src="/images/down.png" alt="pin icon" />
        </span>
      </div>
    </div>
    <div className={props.styles.myAccountContent}>
      <MyAccount
        styles={props.styles}
        myAccountTitles={props.myAccountTitles}
      />
    </div>
  </div>
);

export default NavInfo;
