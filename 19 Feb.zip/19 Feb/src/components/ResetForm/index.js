/* @flow */
import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import RaisedButton from 'material-ui/RaisedButton';
import { Field, reduxForm } from 'redux-form';
import renderTextField from '../CreateForm/inputField';
import * as styles from '../../containers/ResetPassword/styles.scss';
import validate from './validation';

type Props = {
  data: Object,
  handleSubmit: () => void
};

type State = {
  inputType: ?string
};

// const styles1 = {
//   floatingLabelFocusStyle: {
//     background: 'white',
//     height: '25px',
//     'margin-top': '12px',
//     padding: '0 5px',
//     'line-height': '1px !important'
//   }
// };

// const renderPasswordField = ({
//   label,
//   input,
//   meta: { touched, error }
// }: FieldProps) => (
//   <PasswordField
//     floatingLabelText={label}
//     className={styles.inputTextBox_Password}
//     visibilityIconStyle={{
//       marginTop: '-10px',
//       opacity: '1'
//     }}
//     floatingLabelFocusStyle={styles1.floatingLabelFocusStyle}
//     errorText={touched && error}
//     {...input}
//     placeholder={label}
//   />
// );

class ResetForm extends PureComponent<Props, State> {
  constructor(props) {
    super(props);
    this.state = { inputType: 'password' };
  }

  togglePwd = () => {
    const { inputType } = this.state;
    const inputToSet = inputType === 'text' ? 'password' : 'text';
    this.setState({ inputType: inputToSet });
  };

  render() {
    const { handleSubmit, data } = this.props;
    return (
      <div>
        <div className={styles.forgot_content}>
          <h1>{data.mf_resetpwdpage_resetpassword}</h1>
          <p>{data.mf_resetpwdpage_newpassword}</p>
        </div>
        <form>
          <div>
            <div
              className={styles.testPart}
              style={{ paddingBottom: '20px', paddingTop: '10px' }}
            >
              <div className={styles.passwordHolder}>
                <Field
                  name="password"
                  component={renderTextField}
                  label={data.mf_registration_password}
                  inputType={this.state.inputType}
                />
                <span
                  id="showPassword"
                  className={styles.showPwd}
                  role="presentation"
                  onKeyUp={/* istanbul ignore next */ () => {}}
                  onClick={this.togglePwd}
                >
                  {this.state.inputType === 'password' ? 'SHOW' : 'HIDE'}
                </span>
              </div>
            </div>
            <p className={styles.resetContent}>
              {data.mf_resetpwdpage_mobile_desc}
            </p>
            <div className={`hide-on-small-only ${styles.regButtonSection}`}>
              <RaisedButton
                type="submit"
                onClick={handleSubmit}
                label={data.mf_resetpwdpage_submit_button}
                className={styles.regPrimaryBtn}
              />
            </div>
            <div
              className={`show-on-small hide-on-med-and-up ${
                styles.regButtonMobileSection
              }`}
            >
              <RaisedButton
                type="submit"
                onClick={handleSubmit}
                label={data.mf_resetpwdpage_submit_button}
                className={styles.regPrimaryBtn}
              />
            </div>
          </div>
        </form>
      </div>
    );
  }
}

const ResetPWDForm = reduxForm({
  form: 'resetFormValues',
  validate
})(ResetForm);

export default connect(state => ({
  formValues: state
}))(ResetPWDForm);
