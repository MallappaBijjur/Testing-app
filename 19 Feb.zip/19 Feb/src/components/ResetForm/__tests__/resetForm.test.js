/* @flow */
import React from 'react';
import { createStore } from 'redux';
import { Provider, connect } from 'react-redux';
import { MuiThemeProvider } from 'material-ui/styles';
import { mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import RaisedButton from 'material-ui/RaisedButton';
import ResetForm from '../index';

let mockData = null;
beforeEach(() => {
  mockData = {
    mf_resetpwdpage_password: 'Password',
    mf_resetpwdpage_error_lengthExceeds:
      'Password cannot be greater than 30 characters',
    _links: {
      'oc:createAccountPage': {
        method: 'GET',
        href: 'http://dv-camaro1-xl07:8289/autozone/v1/page/createAccountPage'
      },
      'oc:getForgotPasswordPageContents': {
        method: 'GET',
        href: 'http://dv-camaro1-xl07:8289/autozone/v1/page/forgotPasswordPage'
      },
      curies: [
        {
          templated: true,
          name: 'oc',
          href: '/rels/{rel}'
        }
      ]
    },
    mf_forgotpasswordpage_forgot_required: 'Required',
    mf_resetpwdpage_error_lengthIsShort:
      'Password cannot be less than 4 characters',
    mf_resetpwdpage_mobile_desc:
      'Passwords are case sensitive and must be at least 8 characters, with at least 1 number and 1 special character.',
    mf_resetpwdpage_show: 'SHOW',
    mf_resetpwdpage_hide: 'HIDE',
    mf_resetpwdpage_submit_button: 'Submit',
    mf_resetpwdpage_desktop_desc:
      'For your security, please create a new password.',
    mf_resetpwdpage_password_length: 'Password has to be from 4-30 characters',
    mf_resetpwdpage_resetpassword: 'Reset Password',
    mf_resetpwdpage_newpassword: 'Set your new password here'
  };
});

describe('<ResetForm />', () => {
  let PROPS = {};
  beforeEach(() => {
    PROPS = {
      label: 'test',
      input: jest.fn(),
      meta: jest.fn(),
      handleSubmit: jest.fn(),
      data: mockData
    };
  });

  test('renders correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <ResetForm {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );

    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('togglepassword works correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <ResetForm {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );
    wrapper
      .find('#showPassword')
      .props()
      .onClick();
    expect(wrapper.find('ResetForm').instance().state.inputType).toBe('text');
    wrapper
      .find('#showPassword')
      .props()
      .onClick();
    expect(wrapper.find('ResetForm').instance().state.inputType).toBe(
      'password'
    );
  });

  test('calls handleSubmit prop on forgot form button click', () => {
    const store = createStore(() => ({}));
    const handleSubmit = jest.fn();
    const ConnectedForgotForm = connect(
      () => ({
        formValues: {}
      }),
      () => ({
        handleSubmit
      })
    )(ResetForm);

    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <ConnectedForgotForm data={mockData} />
        </MuiThemeProvider>
      </Provider>
    );

    wrapper
      .find(RaisedButton)
      .at(0)
      .props()
      .onClick();

    expect(handleSubmit.mock.calls.length).toBe(1);
  });
});
