/* @flow */
import validation from '../validation';

describe('ResetForm validation', () => {
  const props = {
    data: {
      mf_forgotpasswordpage_forgot_required: 'required',
      mf_resetpwdpage_error_lengthIsShort: 'short',
      mf_resetpwdpage_error_lengthExceeds: 'large'
    }
  };

  test('validates valid password successfully', () => {
    const values = {
      password: 'abcd123#$'
    };
    const errors = validation(values, props);
    expect(errors.password).toBeUndefined();
  });

  test('validates short password successfully', () => {
    const values = {
      password: 'abc'
    };
    const errors = validation(values, props);
    expect(errors.password).toBe(
      props.data.mf_resetpwdpage_error_lengthIsShort
    );
  });

  test('validates large password successfully', () => {
    const values = {
      password: 'abcabcabcabcabcabcabcabcabcabcabc'
    };
    const errors = validation(values, props);
    expect(errors.password).toBe(
      props.data.mf_resetpwdpage_error_lengthExceeds
    );
  });
});
