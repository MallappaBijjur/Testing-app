/* @flow */
export default function(values: Object, props: Object) {
  const errors = {};
  const requiredFields = ['password'];
  requiredFields.forEach(field => {
    if (!values[field]) {
      errors[field] = props.data.mf_forgotpasswordpage_forgot_required;
    }
  });

  if (values.password && !/^.{4,}$/.test(values.password)) {
    errors.password = props.data.mf_resetpwdpage_error_lengthIsShort;
  }

  if (values.password && !/^.{0,30}$/.test(values.password)) {
    errors.password = props.data.mf_resetpwdpage_error_lengthExceeds;
  }

  return errors;
}
