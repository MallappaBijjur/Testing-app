/* @flow */

import React from 'react';
import type { Element } from 'react';
import FlatButton from 'material-ui/FlatButton';
import * as styles from '../../containers/AddVehicle/addvehicle.scss';

type Props = {
  data: any,
  handleClose: (data: any) => void
};

const stylesYmme = {
  labelStyle: {
    textDecoration: 'underline',
    textTransform: 'initial'
  },
  buttonStyle: {
    width: '47%'
  }
};

const AddedVehicleMobile = ({ data, handleClose }: Props): Element<'div'> => (
  <div className={styles.vehicleConfirmationYMMEMobile}>
    <div className={styles.ymmeMessage}>
      <FlatButton
        label="Add Vehicle"
        labelPosition="after"
        onClick={() => handleClose('ADD')}
        style={stylesYmme.buttonStyle}
        labelStyle={stylesYmme.labelStyle}
        icon={
          <img
            src="/images/roundedPlus.svg"
            alt="roundedPlus"
            role="presentation"
          />
        }
      />
      <span className={styles.verticalDivider} />
      <FlatButton
        label="Manage Vehicles"
        labelStyle={stylesYmme.labelStyle}
        style={stylesYmme.buttonStyle}
      />
    </div>
    <div className={styles.ymmeCurrentShopping}>
      <h2 className={styles.ymmeCurrentShoppingTitle}>
        Currently Shopping For<span>Clear</span>
      </h2>
      <div className={styles.ymmeCurrentShoppingVehicle}>
        {data.vehicleDisplayName}
      </div>
      <div className={styles.ymmeChooseDifferent}>
        <div className={styles.ymmeChooseDifferentTitle}>
          Choose A Different Vehicle
        </div>
        <div className={styles.ymmeChooseDifferentVehicle}>
          {data.vehicleDisplayName}
        </div>
      </div>
    </div>
  </div>
);

export default AddedVehicleMobile;
