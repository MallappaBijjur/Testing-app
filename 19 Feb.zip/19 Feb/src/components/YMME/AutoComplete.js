/* @flow */
import React, { PureComponent } from 'react';
import AutoComplete from 'material-ui/AutoComplete';
import * as styles from '../../containers/AddVehicle/YMMEDesktop.scss';

const stylesYmme = {
  textFieldStyle: {
    paddingBottom: '12px',
    height: '65px',
    width: '100%'
  },
  divStyle: {
    paddingBottom: '12px',
    float: 'left',
    width: '100%'
  },
  menuStyle: {
    width: '350px'
  },
  floatingLabelFocusStyle: {
    background: 'white',
    height: '20px',
    padding: '0',
    color: 'black',
    fontWeight: 'bold'
  },

  floatingLabelStyle: {
    height: '13px',
    top: '23px',
    margin: 'auto',
    fontFamily: 'HelveticaNeue',
    fontSize: '14px',
    lineHeight: '1.43',
    textAlign: 'left',
    color: 'gray',
    left: '15px'
  },
  floatingLabelShrinkStyle: {
    top: '34px',
    color: '#000',
    fontWeight: 'bold',
    textTransform: 'uppercase'
  },
  inputStyle: {
    fontFamily: 'AutoZoneCond-Medium'
  }
};

const arrowDownPosition = (
  <div className={styles.arrowDownPosition}>
    <svg width="24" height="24" viewBox="0 0 24 24">
      <path d="M7.41 7.84L12 12.42l4.59-4.58L18 9.25l-6 6-6-6z" />
    </svg>
  </div>
);
const arrowUpPosition = (
  <div className={styles.arrowUpPosition}>
    <svg width="24" height="24" viewBox="0 0 24 24">
      <path d="M7.41 15.41L12 10.83l4.59 4.58L18 14l-6-6-6 6z" />
    </svg>
  </div>
);

type State = {
  searchText: any,
  dataSourceList: any,
  singleRecordData: any,
  isSingleRecord: boolean,
  singleRecordReset: boolean,
  fieldEdit: boolean,
  arrowButton: any
};

type Props = {
  datasource: any,
  data: any,
  disableAutocomplete: boolean,
  maxLength: any,
  resetField: any,
  changeHandler: (value: any) => void
};

export default class commonAutocomplete extends PureComponent<Props, State> {
  constructor(props: any) {
    super(props);
    // this.onMenuClose = this.onMenuClose.bind(this);
    this.state = {
      searchText: '',
      dataSourceList: [],
      singleRecordData: '',
      isSingleRecord: false,
      singleRecordReset: false,
      fieldEdit: false,
      arrowButton: arrowDownPosition
    };
  }

  componentWillReceiveProps(nextProps: any) {
    if (this.props.datasource !== nextProps.datasource) {
      const dataGroup = nextProps.datasource;
      const dataLabel = nextProps.data.name;
      const isSingleRecord = !!(dataGroup && dataGroup.length === 1);
      console.log('single check', isSingleRecord);
      const singleRecordData = isSingleRecord
        ? dataLabel && dataGroup[0][dataLabel]
        : '';
      const singleRecordDataObject = isSingleRecord
        ? dataLabel && dataGroup[0]
        : {};
      if (nextProps.changeHandler && isSingleRecord) {
        console.log('the single value is', nextProps.datasource[0][dataLabel]);
        this.setState({
          isSingleRecord: true,
          singleRecordData,
          singleRecordReset: true,
          searchText: ''
        });
        nextProps.changeHandler(singleRecordDataObject);
      } else {
        this.setState({
          singleRecordReset: false,
          isSingleRecord: false,
          singleRecordData: '',
          searchText: ''
        });
      }

      // for setting updated datasource to autocomplete
      this.setState({
        dataSourceList: nextProps.datasource
      });
    }
  }

  onMenuClose = () => {
    let Totaldatasource = this.state.dataSourceList;
    if (this.props !== undefined) {
      if (this.props.datasource !== undefined) {
        Totaldatasource = this.props.datasource;
      }
    }
    this.setState({
      arrowButton: arrowDownPosition,
      dataSourceList: Totaldatasource
    });
  };

  handleClick = () => {
    this.setState({
      arrowButton: arrowUpPosition
    });
    console.log('handle click');
  };

  handleUpdateInput = (searchText: any) => {
    const Totaldatasource = this.props.datasource;
    if (Totaldatasource !== undefined) {
      const dropdownData = this.filterList(Totaldatasource, searchText);
      this.setState({
        dataSourceList: dropdownData,
        fieldEdit: true
      });
    }
    this.setState({
      searchText,
      arrowButton: arrowUpPosition
    });
  };

  // on select
  handleNewRequest = (content: any) => {
    this.setState({
      dataSourceList: [],
      fieldEdit: false
    });
    if (content !== '') {
      this.setState({
        arrowButton: arrowDownPosition
      });
    } else {
      this.setState({
        arrowButton: arrowUpPosition
      });
    }
    if (this.props.changeHandler) {
      this.props.changeHandler(content);
    }
  };

  filterList = (obj: any, term: any) => {
    if (obj !== undefined) {
      return obj.filter(a => {
        let data = a.year;
        if (a.year !== undefined) {
          data = a.year.toUpperCase();
        } else if (a.make !== undefined) {
          data = a.make.toUpperCase();
        } else if (a.model !== undefined) {
          data = a.model.toUpperCase();
        } else if (a.engine !== undefined) {
          data = a.engine.toUpperCase();
        }
        return data.indexOf(term.toUpperCase()) > -1;
      });
    }
    return null;
  };

  render() {
    const { data, datasource, disableAutocomplete, maxLength } = this.props;
    const {
      singleRecordData,
      isSingleRecord,
      singleRecordReset,
      fieldEdit,
      arrowButton
    } = this.state;
    let { dataSourceList } = this.state;
    const fieldEditValue = fieldEdit ? false : this.props.resetField;
    const resetField = singleRecordReset ? true : fieldEditValue;
    console.log('resetFielda is', resetField);
    console.log(dataSourceList.length);
    if (dataSourceList.length === 0) {
      dataSourceList = datasource;
    }
    const singleRecordDataVal =
      isSingleRecord && disableAutocomplete === false ? singleRecordData : '';
    return (
      <div>
        <AutoComplete
          onClick={this.handleClick}
          floatingLabelText={data.label !== undefined ? data.label : ''}
          searchText={
            resetField === true ? singleRecordDataVal : this.state.searchText
          }
          onUpdateInput={this.handleUpdateInput}
          dataSource={dataSourceList !== undefined ? dataSourceList : []}
          onInput={(e: any) => {
            if (e.target.value !== '') {
              e.target.value = e.target.value.toString().slice(0, maxLength);
            } else {
              e.target.value = '';
            }
          }}
          filter={AutoComplete.noFilter}
          openOnFocus
          underlineShow={false}
          textFieldStyle={stylesYmme.textFieldStyle}
          style={stylesYmme.divStyle}
          className={styles.labelYmme}
          listStyle={{
            maxHeight: 250,
            overflow: 'auto',
            width: '100%',
            minWidth: 200
          }}
          floatingLabelFocusStyle={stylesYmme.floatingLabelFocusStyle}
          floatingLabelStyle={stylesYmme.floatingLabelStyle}
          inputStyle={stylesYmme.inputStyle}
          menuStyle={stylesYmme.menuStyle}
          onNewRequest={this.handleNewRequest}
          onClose={this.onMenuClose}
          floatingLabelShrinkStyle={stylesYmme.floatingLabelShrinkStyle}
          dataSourceConfig={{
            text: data.name !== undefined ? data.name : '',
            value: data.name !== undefined ? data.name : ''
          }}
          disabled={disableAutocomplete}
        />
        {arrowButton}
        <div className={styles.Divider} />
      </div>
    );
  }
}
