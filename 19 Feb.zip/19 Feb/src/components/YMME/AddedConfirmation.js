/* @flow */

import React from 'react';
import type { Element } from 'react';
import * as styles from '../../containers/AddVehicle/addvehicle.scss';

type Props = {
  message: Object,
  toggleYMME: () => void,
  toggleYMMEDesktop: () => void,
  closeHandler: () => void,
  shopWithoutVehicle: () => void
};

const AddedConfirmation = ({
  message,
  toggleYMME,
  toggleYMMEDesktop,
  closeHandler,
  shopWithoutVehicle
}: Props): Element<'div'> => {
  console.log('AddedConfirmation', message);

  return (
    <div className={styles.vehicleConfirmation}>
      <div className={styles.successIcon}>
        <img src="/images/az-car.png" alt="car icon" />
      </div>
      <div className={styles.rightSection}>
        <div className={styles.title}>You are now shopping for</div>
        <div className={styles.vehicle}>{message.vehicleDisplayName}</div>
        <div className="show-on-small hide-on-med-and-up">
          <button onClick={toggleYMME} className={styles.link}>
            Change
          </button>
        </div>
        <div className="hide-on-small-only">
          <button onClick={toggleYMMEDesktop} className={styles.link}>
            Change
          </button>
          <span>-or-</span>
          <button className={styles.link} onClick={shopWithoutVehicle}>
            Shop Without Vehicle
          </button>
        </div>
        <div
          className="hide-on-small-only"
          onKeyDown={() => {}}
          onClick={closeHandler}
          role="presentation"
          style={{ float: 'right', paddingRight: '10px', marginTop: '6px' }}
        >
          <img
            src="/images/close-dark.svg"
            alt="close icon"
            role="presentation"
          />
        </div>
      </div>
    </div>
  );
};

export default AddedConfirmation;
