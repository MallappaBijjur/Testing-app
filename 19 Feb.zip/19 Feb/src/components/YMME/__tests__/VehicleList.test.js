/* @flow */
import React from 'react';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
import { MuiThemeProvider } from 'material-ui/styles';
import { mount } from 'enzyme';
import toJson from 'enzyme-to-json';

import VehicleList from '../VehicleList';

const MakeData = {
  name: 'make',
  label: 'Make'
};

describe('<vehicleList />', () => {
  test('renders vehicleList correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <VehicleList data={MakeData.name} />
        </MuiThemeProvider>
      </Provider>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });
});
