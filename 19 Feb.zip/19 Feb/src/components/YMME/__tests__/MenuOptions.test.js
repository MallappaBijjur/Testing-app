/* @flow */
import React from 'react';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
import { MuiThemeProvider } from 'material-ui/styles';
import { mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import MenuItem from 'material-ui/MenuItem';
import MenuOptions from '../MenuOptions';

let datasource = {};
let datasourceModel = {};
let datasourceEngine = {};

beforeEach(() => {
  datasource = {
    atgResponse: [
      {
        makeId: '9018099',
        '@class': 'com.autozone.diy.ymme.bean.MakeBean',
        count: '0',
        make: 'Acura'
      },
      {
        makeId: '9018001',
        '@class': 'com.autozone.diy.ymme.bean.MakeBean',
        count: '0',
        make: 'Alfa Romeo'
      }
    ]
  };

  datasourceModel = {
    atgResponse: [
      {
        '@class': 'com.autozone.diy.ymme.bean.ModelBean',
        modelId: '9637900',
        count: '0',
        model: 'RDX 2WD'
      }
    ]
  };

  datasourceEngine = {
    atgResponse: [
      {
        '@class': 'com.autozone.diy.ymme.bean.EngineBean',
        engine: '6 Cylinders   3.5L FI SOHC VTEC',
        count: '0',
        engineId: '36379001'
      }
    ]
  };
});

describe('<MenuOptions />', () => {
  test('MenuOptions renders correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <MenuOptions
            list={datasource.atgResponse}
            selectValue={datasource.atgResponse[0].make}
          />
        </MuiThemeProvider>
      </Provider>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('Model MenuOptions renders correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <MenuOptions
            list={datasourceModel.atgResponse}
            selectValue={datasourceModel.atgResponse[0].model}
          />
        </MuiThemeProvider>
      </Provider>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('engine MenuOptions renders correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <MenuOptions
            list={datasourceEngine.atgResponse}
            selectValue={datasourceEngine.atgResponse[0].engine}
          />
        </MuiThemeProvider>
      </Provider>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('MenuOptions renders correctly on click', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <MenuOptions list={datasource.atgResponse} />
        </MuiThemeProvider>
      </Provider>
    );
    const mockedEvent = { selectValue: datasourceEngine.atgResponse[0].engine };
    wrapper
      .find(MenuItem)
      .at(0)
      .simulate('click', mockedEvent);
    wrapper
      .find(MenuItem)
      .at(1)
      .simulate('click', mockedEvent);
    expect(toJson(wrapper)).toMatchSnapshot();
    console.log(
      'test',
      wrapper
        .find(MenuItem)
        .at(0)
        .props()
    );
    // wrapper.find(MenuItem).at(0).props().onClick( mockCallBack: "aaa" );
    // selectValue = jest.genMockFunction();
  });
});
