/* @flow */
import React from 'react';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
import { mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import AddedConfirmation from '../AddedConfirmation';

describe('<AddedConfirmation />', () => {
  let PROPS = {};
  beforeEach(() => {
    PROPS = {
      message: 'Message',
      toggleYMME: jest.fn(),
      toggleYMMEDesktop: jest.fn()
    };
  });
  test('AddedConfirmation renders correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <AddedConfirmation {...PROPS} />
      </Provider>
    );

    // check classes for responsive design exist
    expect(wrapper.find('.show-on-small').length).toBe(1);
    expect(wrapper.find('.hide-on-med-and-up').length).toBe(1);
    expect(wrapper.find('.hide-on-small-only').length).toBe(1);
    // check if image exist
    expect(wrapper.find('img').at(0).length).toBe(1);
    expect(wrapper.find('img').at(1).length).toBe(1);
    // check if links exist to click for desktop and mobile
    wrapper
      .find('a')
      .at(0)
      .props()
      .onClick();
    expect(PROPS.toggleYMME.mock.calls.length).toBe(1);
    wrapper
      .find('a')
      .at(1)
      .props()
      .onClick();
    expect(PROPS.toggleYMMEDesktop.mock.calls.length).toBe(1);

    expect(toJson(wrapper)).toMatchSnapshot();
  });
});
