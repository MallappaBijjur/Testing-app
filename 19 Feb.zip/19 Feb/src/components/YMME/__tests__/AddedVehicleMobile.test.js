/* @flow */
import React from 'react';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
import { MuiThemeProvider } from 'material-ui/styles';
import { mount } from 'enzyme';
import FlatButton from 'material-ui/FlatButton';
import AddedVehicleMobile from '../AddedVehicleMobile';

describe('<AddedVehicleMobile />', () => {
  let PROPS = {};
  beforeEach(() => {
    const data = {
      vehicleDisplayName: 'sample vehicle'
    };
    PROPS = {
      message: 'message',
      toggleYMME: jest.fn(),
      toggleYMMEDesktop: jest.fn(),
      data,
      handleClose: jest.fn()
    };
  });
  // test('AddedVehicleMobile renders correctly', () => {
  //   const store = createStore(() => ({}));
  //   const wrapper = mount(
  //     <Provider store={store}>
  //       <MuiThemeProvider>
  //         <AddedVehicleMobile {...PROPS} />
  //       </MuiThemeProvider>
  //     </Provider>
  //   );
  // });

  test('AddedVehicleMobile onClick renders correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <AddedVehicleMobile {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );

    wrapper
      .find(FlatButton)
      .at(0)
      .props()
      .onClick();
  });
});
