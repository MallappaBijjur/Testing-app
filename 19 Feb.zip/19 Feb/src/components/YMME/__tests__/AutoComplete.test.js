/* @flow */
import React from 'react';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
import { MuiThemeProvider } from 'material-ui/styles';
import { mount } from 'enzyme';
import AutoComplete from 'material-ui/AutoComplete';
import CommonAutocomplete from '../AutoComplete';

// let datasource : [];
const MakeData = {
  name: 'make',
  label: 'Make'
};

let datasourceMake = {};
let datasourceYear = {};
let datasourceModel = {};
let datasourceEngine = {};
let PROPS = {};

beforeEach(() => {
  datasourceYear = {
    atgResponse: [
      {
        '@class': 'com.autozone.diy.ymme.bean.YearBean',
        year: '201800',
        count: '0',
        yearId: '9018000'
      }
    ]
  };

  datasourceMake = {
    atgResponse: [
      {
        makeId: '9018099',
        '@class': 'com.autozone.diy.ymme.bean.MakeBean',
        count: '0',
        make: 'Acura'
      },
      {
        makeId: '9018001',
        '@class': 'com.autozone.diy.ymme.bean.MakeBean',
        count: '0',
        make: 'Alfa Romeo'
      }
    ]
  };

  datasourceModel = {
    atgResponse: [
      {
        '@class': 'com.autozone.diy.ymme.bean.ModelBean',
        modelId: '9637900',
        count: '0',
        model: 'RDX 2WD'
      }
    ]
  };

  datasourceEngine = {
    atgResponse: [
      {
        '@class': 'com.autozone.diy.ymme.bean.EngineBean',
        engine: '6 Cylinders   3.5L FI SOHC VTEC',
        count: '0',
        engineId: '36379001'
      }
    ]
  };

  PROPS = {
    message: 'Message',
    datasource: datasourceMake.atgResponse,
    data: MakeData,
    changeHandler: jest.fn()
  };
});

describe('<commonAutocomplete />', () => {
  test('renders correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <CommonAutocomplete {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );

    wrapper
      .find(AutoComplete)
      .props()
      .onClick();

    const content = datasourceMake.atgResponse[0];
    const index = 1;
    wrapper
      .find(AutoComplete)
      .props()
      .onNewRequest(content, index);

    wrapper
      .find(AutoComplete)
      .props()
      .onClose();
    wrapper
      .find(AutoComplete)
      .props()
      .onUpdateInput('auto');
  });

  test('renders correctly for model filter', () => {
    const store = createStore(() => ({}));
    PROPS.datasource = datasourceModel.atgResponse;
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <CommonAutocomplete {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );

    wrapper
      .find(AutoComplete)
      .props()
      .onUpdateInput('auto');
  });

  test('renders correctly for year filter', () => {
    const store = createStore(() => ({}));
    PROPS.datasource = datasourceYear.atgResponse;
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <CommonAutocomplete {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );

    wrapper
      .find(AutoComplete)
      .props()
      .onUpdateInput('auto');
  });

  test('renders correctly for engine filter', () => {
    const store = createStore(() => ({}));
    PROPS.datasource = datasourceEngine.atgResponse;
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <CommonAutocomplete {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );

    wrapper
      .find(AutoComplete)
      .props()
      .onUpdateInput('auto');
  });

  test('renders correctly on new request with content null', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <CommonAutocomplete {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );

    const content = '';
    const index = 0;
    wrapper
      .find(AutoComplete)
      .props()
      .onNewRequest(content, index);
  });
});
