/* @flow */
import React from 'react';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
import { mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import PrefferedVehicle from '../PrefferedVehicle';

const CurrentlyShoppingData = {
  vehicleDisplayName: 'No Vehicle Selected'
};

describe('<PrefferedVehicle />', () => {
  test('renders correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <PrefferedVehicle data={CurrentlyShoppingData.vehicleDisplayName} />
      </Provider>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });
});
