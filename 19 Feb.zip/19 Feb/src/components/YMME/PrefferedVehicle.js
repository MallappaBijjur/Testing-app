/* @flow */

import React from 'react';
import * as styles from '../../containers/AddVehicle/YMMEDesktop.scss';

type Props = {
  data: Object
};

const PrefferedVehicle = ({ data }: Props) => {
  console.log('Currently Shopping For', data);
  return (
    <div
      className={
        data.vehicleDisplayName !== 'No Vehicle Selected'
          ? styles.vehicleSelected
          : ''
      }
    >
      <div className={styles.leftContainer}>
        <div className={styles.yymeLabel}>Currently Shopping For</div>
        <a href="/" className={styles.link}>
          Shop Without Vehicle
        </a>
        <div className={styles.yymeVehicleSelection}>
          <img
            src="/images/az-car.png"
            alt="Vehicle"
            className={styles.noPreferedvehicleIcon}
          />
          <img
            src="/images/az-car.png"
            alt="Vehicle"
            className={styles.preferedvehicleIcon}
          />
          <div className={styles.yymeCurrentShopping}>
            {data.vehicleDisplayName}
          </div>
        </div>
        <div className={styles.horzDivider}>
          <div className="s12 m12 l12 xl12">
            <div className={styles.yymeLabel} style={{ paddingTop: '20px' }}>
              MANAGE VEHICLES
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrefferedVehicle;
