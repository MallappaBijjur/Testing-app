/* @flow */

import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import type { Connector } from 'react-redux';
import { RadioButton, RadioButtonGroup } from 'material-ui/RadioButton';
import Paper from 'material-ui/Paper';
import * as ymmeActions from '../../actions/ymmeActions';
import type { Dispatch, ReduxState } from '../../types';
import YMMETrigger from '../../containers/AddVehicle/YMMETrigger';
import styles from '../Filter/styles.scss';

type Props = {
  yearList?: any,
  addedVehicle?: any,
  fetchYMMEYearList?: () => void
};

const paperStyle = {
  margin: '0 0 10px',
  padding: '15px 5px',
  textAlign: 'left',
  display: 'inline-block'
};

const stylesRadio = {
  radioButton: {
    marginBottom: '5px'
  },
  iconStyle: {
    marginRight: '10px'
  },
  labelStyle: {
    color: '#484848'
  }
};

type State = {
  showYMME: boolean,
  viewType: string
};

class ShelfVehicle extends PureComponent<Props, State> {
  constructor(props: any) {
    super(props);
    this.state = {
      showYMME: false,
      viewType: 'MOBILE'
    };
  }

  toggleYMMEMobile = () => {
    console.log('Inside toggleYMMEDesktop 1234', this.props);
    if (this.props.fetchYMMEYearList) {
      this.props.fetchYMMEYearList();
    }
    this.setState({ showYMME: !this.state.showYMME, viewType: 'MOBILE' });
  };

  toggleYMMEDesktop = () => {
    console.log('Inside toggleYMMEDesktop 1234', this.props);
    if (this.props.fetchYMMEYearList) {
      this.props.fetchYMMEYearList();
    }
    this.setState({ showYMME: !this.state.showYMME, viewType: 'DESKTOP' });
  };

  render() {
    console.log('Confirmation Props', this.props);
    const { yearList, addedVehicle } = this.props;
    const { viewType } = this.state;
    let vehicleText;
    if (addedVehicle) {
      vehicleText = addedVehicle.vehicleDisplayName;
    }

    return (
      <div>
        {YMMETrigger(
          this.state.showYMME,
          viewType,
          yearList,
          addedVehicle,
          viewType === 'DESKTOP'
            ? this.toggleYMMEDesktop
            : this.toggleYMMEMobile
        )}
        {addedVehicle === undefined ? (
          <div className="col s12 m12 l12 xl12">
            <h5 style={{ color: '#787878' }}>
              WHAT VEHICLE ARE YOU WORKING ON?
            </h5>
            <RadioButtonGroup name="vehicle" defaultSelected="vehicle">
              <RadioButton
                value="vehicle"
                label="Shop without vehicle"
                style={stylesRadio.radioButton}
                labelStyle={stylesRadio.labelStyle}
                iconStyle={stylesRadio.iconStyle}
                checkedIcon={
                  <img
                    src="/images/radio-button-on.svg"
                    alt="radio-button-on"
                  />
                }
                uncheckedIcon={
                  <img
                    src="/images/radio-button-off.svg"
                    alt="radio-button-off"
                  />
                }
              />
            </RadioButtonGroup>
            {vehicleText}
            <div
              role="presentation"
              className="show-on-small hide-on-med-and-up"
              onKeyDown={() => {}}
              style={{
                textDecoration: 'underline',
                color: 'black',
                paddingLeft: '35px'
              }}
              onClick={this.toggleYMMEMobile}
            >
              Add a Vehicle
            </div>
            <div
              role="presentation"
              className="hide-on-small-only"
              onKeyDown={() => {}}
              style={{
                textDecoration: 'underline',
                color: 'black',
                paddingLeft: '30px'
              }}
              onClick={this.toggleYMMEDesktop}
            >
              Add a Vehicle
            </div>
          </div>
        ) : (
          <div className="col s12 m12 l12 xl12">
            <h5
              style={{ color: '#787878' }}
              className="show-on-small hide-on-med-and-up"
            >
              WORKING ON
            </h5>
            <RadioButtonGroup
              name="list"
              defaultSelected={vehicleText}
              className="show-on-small hide-on-med-and-up"
            >
              <RadioButton
                value="not light"
                label="Shop without vehicle"
                style={stylesRadio.radioButton}
                labelStyle={stylesRadio.labelStyle}
                iconStyle={stylesRadio.iconStyle}
                checkedIcon={
                  <img
                    src="/images/radio-button-on.svg"
                    alt="radio-button-on"
                  />
                }
                uncheckedIcon={
                  <img
                    src="/images/radio-button-off.svg"
                    alt="radio-button-off"
                  />
                }
              />
              <RadioButton
                value="vehicle"
                label={vehicleText}
                style={stylesRadio.radioButton}
                labelStyle={stylesRadio.labelStyle}
                iconStyle={stylesRadio.iconStyle}
                checkedIcon={
                  <img
                    src="/images/radio-button-on.svg"
                    alt="radio-button-on"
                  />
                }
                uncheckedIcon={
                  <img
                    src="/images/radio-button-off.svg"
                    alt="radio-button-off"
                  />
                }
              />
            </RadioButtonGroup>
            <div className="hide-on-small-only">
              <Paper style={paperStyle} className={styles.paperbox} zDepth={1}>
                <img
                  src="/images/vehicle/Dark.svg"
                  alt="vehicle dark"
                  style={{ float: 'left', paddingRight: '10px' }}
                />
                <h4 className={styles.paperHeading}>Viewing Items For Your</h4>
                <div className={styles.vehIcon} />
                <div className={styles.vehHolder}>
                  <img src="/images/down.png" alt="down png" />
                  <div className={styles.info}>{vehicleText}</div>
                </div>
              </Paper>
            </div>
            <div
              role="presentation"
              className="hide-on-small-only"
              onKeyDown={() => {}}
              style={{
                textDecoration: 'underline',
                color: 'black',
                paddingLeft: '30px'
              }}
              onClick={this.toggleYMMEDesktop}
            >
              Change Vehicle
            </div>
            <div
              role="presentation"
              className="show-on-small hide-on-med-and-up"
              onKeyDown={() => {}}
              style={{
                textDecoration: 'underline',
                color: 'black',
                paddingLeft: '35px'
              }}
              onClick={this.toggleYMMEMobile}
            >
              Add a different vehicle
            </div>
          </div>
        )}
      </div>
    );
  }
}

const connector: Connector<{}, Props> = connect(
  ({ ymmeData }: ReduxState) => ({
    yearList: ymmeData ? ymmeData.data.yearList : '',
    addedVehicle: ymmeData ? ymmeData.data.addedVehicle : ''
  }),
  (dispatch: Dispatch) => ({
    fetchYMMEYearList: () => dispatch(ymmeActions.fetchYMMEYearList())
  })
);

export default connector(ShelfVehicle);
