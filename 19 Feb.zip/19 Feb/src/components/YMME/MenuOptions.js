/* @flow */

import React from 'react';
import type { Element } from 'react';
import MenuItem from 'material-ui/MenuItem';
import Divider from 'material-ui/Divider';
import * as styles from '../../containers/AddVehicle/addvehicle.scss';

type Props = {
  list: Array<Object>,
  selectValue: Object => void
};

const menuOption = (item, selectValue) => (
  <div key={item}>
    <MenuItem
      className={styles.ymmeListItem}
      onClick={() => {
        selectValue(item);
      }}
      primaryText={
        (item && item.year) || item.make || item.model || item.engine
      }
    />
    <Divider />
  </div>
);

const MenuOptions = ({ list, selectValue }: Props): Element<'div'> => (
  <div>
    {list !== undefined
      ? list.map((item: any) => menuOption(item, selectValue))
      : null}
  </div>
);

export default MenuOptions;
