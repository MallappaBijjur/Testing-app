/* @flow */

import React, { PureComponent } from 'react';
import * as styles from '../../containers/AddVehicle/YMMEDesktop.scss';

type Props = {
  data: Object
};

export default class DifferentVehicles extends PureComponent<Props> {
  render() {
    const { data } = this.props;
    return (
      <div>
        <div className={styles.yymeLabel}>{data.name}</div>
      </div>
    );
  }
}
