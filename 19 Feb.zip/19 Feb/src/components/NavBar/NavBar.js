/* @flow */

import React from 'react';
import type { Element } from 'react';
import menuNavigation from '../../containers/data/menuNavigation';

type Props = {
  styles: Object
};

const NavBar = (props: Props): Element<'div'> => (
  <div className={props.styles.navAutoZone}>
    <nav>
      <div className="nav-wrapper">
        <ul id="nav-mobile" className="left hide-on-med-and-down">
          {menuNavigation.menuNavigationLeft.map(menu => (
            <li key={menu.id}>
              <a href={menu.link}>{menu.name}</a>
            </li>
          ))}
        </ul>
        <ul id="nav-mobile" className="hide-on-med-and-down right">
          {menuNavigation.menuNavigationRight.map(menu => (
            <li key={menu.id}>
              <a href={menu.link}>{menu.name}</a>
            </li>
          ))}
        </ul>
      </div>
    </nav>
  </div>
);

export default NavBar;
