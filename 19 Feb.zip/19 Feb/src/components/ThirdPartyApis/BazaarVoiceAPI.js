/* @flow */
import { rrAzrwebShelfTag, rrAzrwebPdpTag } from '../../config/serviceAPI';

export const loadBazaarVoiceRating = () => {
  const { head } = document;
  const BVTag = document.createElement('script');
  BVTag.setAttribute('async', '');
  BVTag.setAttribute('src', rrAzrwebPdpTag);
  if (head) head.appendChild(BVTag);
};

export const loadBazaarVoiceRatingShelfPage = () => {
  let $BV;

  (function bvRating() {
    function getScript(url, callback) {
      const head =
        document.getElementsByTagName('head')[0] || document.documentElement;
      const script = document.createElement('script');
      script.src = rrAzrwebShelfTag;
      script.type = 'text/javascript';
      script.charset = 'utf-8';
      script.setAttribute('async', 'async');
      script.onreadystatechange = () => {
        if (
          !this.readyState ||
          this.readyState === 'loaded' ||
          this.readyState === 'complete'
        ) {
          script.onreadystatechange = null;
          script.onload = script.onreadystatechange;
          callback();
        }
      };
      script.onload = script.onreadystatechange;
      head.insertBefore(script, head.firstChild);
    }

    // work around Firefox 3.0, 3.5 lack of document.readyState
    // property.
    // Note: Because of this workaround, the <script> fragment must
    // be included within the <head> or <div> element so that it
    // executes before the window load event is fired.

    let docReady;
    const onDocReady = () => {
      docReady = true;
    };
    if (document.readyState === undefined && document.addEventListener) {
      document.addEventListener('DOMContentLoaded', onDocReady, false);
      window.addEventListener('load', onDocReady, false);
    }

    window.loadBazaarvoiceApi = callback => {
      if (window.$BV) {
        callback();
      } else {
        getScript(rrAzrwebShelfTag, () => {
          if (docReady) {
            $BV.docReady();
          }
          callback();
        });
      }
    };
  })();
};
