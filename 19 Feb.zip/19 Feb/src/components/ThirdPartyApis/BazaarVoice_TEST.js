/*eslint-disable*/
import React, { PureComponent, type } from 'react';

type Props = {
  pid: any
};

class BazaarVoice extends PureComponent<Props> {
  constructor(props) {
    super(props);
    this.state = {};
  }

  renderRatingReviewComp = (bvtype, pid) => {
    console.log('bvtype is', bvtype);
    if (bvtype === 'RATING') {
      return <div id={`BVRRInlineRating-${this.props.pid}`} />;
    }
    if (bvtype === 'REVIEW') {
      return (
        <div id="tab-reviews">
          <div data-bv-show="reviews" data-bv-productid={pid} />
        </div>
      );
    }
  };

  render() {
    const { bvtype, pid } = this.props;
    return <div>{this.renderRatingReviewComp(bvtype, pid)}</div>;
  }
}

export default BazaarVoice;
