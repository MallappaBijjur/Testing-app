/* @flow */
import type { Element } from 'react';
import React from 'react';
import styles from './styles.scss';

type Props = {
  styles: Object
};

const Cart = (props: Props): Element<'div'> => (
  <div className={props.styles.cartContainer}>
    <img
      className={styles.cartIcon}
      src="/images/az-cart.png"
      alt="cart icon"
    />
    <span className={styles.vehicleText}>CART</span>
  </div>
);

export default Cart;
