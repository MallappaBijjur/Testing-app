/* @flow */

import React from 'react';
import type { Element } from 'react';

type Props = {
  styles: any,
  toggleYMMEDesktop: any,
  vehicleText: string,
  addedVehicle: any,
  toggleYMME: () => void
};

const Vehicle = (props: Props): Element<'div'> => (
  /* const {
    styles,
    toggleYMME,
    toggleYMMEDesktop,
    vehicleText,
    addedVehicle
  } = this.props; */
  <div>
    <div className={props.styles.vehicleTextMob}>
      <div
        className={props.styles.vahicaleContainer}
        role="button"
        onKeyUp={() => false}
        tabIndex={-45}
        onClick={props.toggleYMME}
      >
        {props.addedVehicle === undefined ? (
          <img
            className={props.styles.cartIcon}
            src="/images/az-car.png"
            alt="vehicle icon"
          />
        ) : (
          <img
            className={props.styles.tickIcon}
            src="/images/vehicle/vehicle-selection.svg"
            alt="selected vehicle icon"
          />
        )}
        <span className={props.styles.vehicleTextMob}>VEHICLE</span>
      </div>
    </div>
    <div className="hide-on-small-only">
      <div
        className={props.styles.vahicaleContainer}
        role="button"
        onKeyUp={() => false}
        tabIndex={-45}
        onClick={props.toggleYMMEDesktop}
      >
        {props.addedVehicle === undefined ? (
          <img
            className={props.styles.vehicleIcon}
            src="/images/az-car.png"
            alt="vehicle icon"
          />
        ) : (
          <img
            className={props.styles.tickIcon}
            src="/images/vehicle/vehicle-selection.svg"
            alt="selected vehicle icon"
          />
        )}
        <span
          className={props.styles.addVehicleText}
          role="button"
          onKeyUp={() => false}
          tabIndex={-45}
        >
          {props.vehicleText}
        </span>
      </div>
    </div>
  </div>
);

export default Vehicle;
