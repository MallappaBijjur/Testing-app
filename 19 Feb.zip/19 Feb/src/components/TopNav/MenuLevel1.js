/* @flow */
import React, { PureComponent } from 'react';
import Drawer from 'material-ui/Drawer';
import Divider from 'material-ui/Divider';
import { Link } from 'react-router-dom';
import AppBar from 'material-ui/AppBar';
import IconButton from 'material-ui/IconButton';
import MenuItem from 'material-ui/MenuItem';
import NavigationClose from 'material-ui/svg-icons/navigation/close';
import styles from './styles.scss';

type Props = {
  subMenuData: Object,
  changeState: () => void,
  changeState2: () => void,
  handleClose: () => void,
  handleBacklevel1: () => void,
  handleBacklevel2: () => void,
  handleBacklevel3: () => void,
  style: any,
  level1: any,
  level2: any,
  level3: any
};

type State = {
  NId: any,
  NId2: any,
  labelLevel1: any,
  labelLevel2: any,
  PopularInCat: any,
  seeMore: boolean,
  menuLength: number
};

export default class MobileMenuLevel1 extends PureComponent<Props, State> {
  constructor(props: any) {
    super(props);
    this.state = {
      NId: [],
      NId2: [],
      labelLevel1: null,
      labelLevel2: null,
      PopularInCat: [],
      seeMore: false,
      menuLength: 5
    };
  }

  handleSubLevel = (NId: any, label: any) => {
    const { childCategories } = this.props.subMenuData.list;
    this.props.changeState();
    this.setState({
      NId: childCategories[1][NId],
      labelLevel1: label,
      PopularInCat: this.props.subMenuData.list.mostPopularCategories
        .mostPopularCategories[NId]
    });
  };

  handleSubLevel2 = (NId2: any, label: any) => {
    const { childCategories } = this.props.subMenuData.list;
    this.props.changeState2();
    this.setState({
      NId2: childCategories[2][NId2],
      labelLevel2: label
    });
  };

  handleMostPop = (mostPopularTypes: any, label: any) => {
    this.props.changeState2();
    this.setState({
      NId2: mostPopularTypes,
      labelLevel2: label
    });
  };

  showMore() {
    const showMoreProp =
      this.state.menulength === 5
        ? this.setState({
            menuLength: this.state.PopularInCat.length,
            seeMore: true
          })
        : this.setState({ menuLength: 5, seeMore: false });

    return showMoreProp;
  }

  /* renderMostPopular= child =>{
    return(
      <MenuItem
        primaryText='Most Popular kdfhgdfjkghdfjghdfgdfgjkdfhgdfkjghfk'
      />
    )
  } */
  renderPopularInCat() {
    if (this.props.subMenuData.readyStatus === 'MOBILESUBMENU_SUCCESS') {
      return this.state.PopularInCat.map(item => (
        <MenuItem
          primaryText={item.label}
          className={styles.sideMenuTitle}
          id={item.NId}
          key={item.NId}
          onClick={() => {
            console.log('click trigger');
          }}
        />
      ));
    }
    return false;
  }
  renderMostPopular() {
    const mostPopular = this.props.subMenuData.headingL1;
    if (this.props.subMenuData.readyStatus === 'MOBILESUBMENU_SUCCESS') {
      const {
        mostPopularCategories
      } = this.props.subMenuData.list.mostPopularCategories;
      const MostPop = [];
      Object.keys(mostPopularCategories).map(key =>
        MostPop.push(mostPopularCategories[key])
      );
      const mostPopularTypes = [].concat([], ...MostPop);
      return (
        <span>
          <h4 className={styles.mobileMenuHeadingstyles}>{mostPopular}</h4>
          <MenuItem
            onClick={() => {
              this.handleMostPop(
                mostPopularTypes,
                `Most Popular ${mostPopular}`
              );
            }}
            innerDivStyle={{ paddingLeft: 40 }}
            leftIcon={
              <svg
                className={styles.starSVG}
                xmlns="http://www.w3.org/2000/svg"
                width="5"
                height="5"
                viewBox="0 0 10 10"
              >
                <path
                  fill="#787878"
                  fillRule="evenodd"
                  d="M9.962 3.286a.5.5 0 0 0-.462-.309H6.809L5.447.254c-.17-.339-.725-.339-.894 0L3.19 2.977H.5a.5.5 0 0 0-.354.854l2.292 2.292L1.52 9.34a.5.5 0 0 0 .758.553L5 8.078l2.722 1.815a.502.502 0 0 0 .759-.553l-.92-3.217L9.853 3.83a.5.5 0 0 0 .109-.545"
                />
              </svg>
            }
            primaryText={`Most Popular ${mostPopular}`}
            className={styles.sideMenuPopular}
          />
        </span>
      );
    }
    return false;
  }

  renderLevel() {
    if (this.props.subMenuData.readyStatus === 'MOBILESUBMENU_SUCCESS') {
      const { childCategories } = this.props.subMenuData.list;
      const child =
        childCategories &&
        childCategories[0] &&
        (childCategories[0]['10000000'] || childCategories[0]['100000']);
      return child.map(
        (item, index) => (
          <MenuItem
            primaryText={item.label}
            className={styles.sideMenuTitle}
            id={index}
            key={item.NId}
            menuid={item.NId}
            onClick={() => {
              this.handleSubLevel(item.NId, item.label);
            }}
          />
        ),
        this
      );
    }
    return false;
  }

  renderSubLevel(id: any) {
    if (this.props.subMenuData.readyStatus === 'MOBILESUBMENU_SUCCESS') {
      return id.slice(0, this.state.menuLength).map(item => (
        <MenuItem
          primaryText={item.label}
          className={styles.sideMenuTitle}
          id={item.NId}
          key={item.NId}
          onClick={() => {
            this.handleSubLevel2(item.NId, item.label);
          }}
        />
      ));
    }
    return false;
  }

  renderSubLevel2(id: any) {
    if (
      this.props.subMenuData.readyStatus === 'MOBILESUBMENU_SUCCESS' &&
      id !== undefined
    ) {
      return id.map(
        item => (
          <Link target="_self" to={`/shelfPage${item.seoUrl}`} key={item}>
            <MenuItem
              primaryText={item.label}
              className={styles.sideMenuTitle}
              onClick={() => this.props.handleClose()}
            />
          </Link>
        ),
        this
      );
    }
    return false;
  }

  render() {
    const materialStyle = {
      appBarStyle: {
        background: 'black',
        color: 'white'
      }
    };

    return (
      <div>
        <Drawer
          width="100%"
          style={this.props.style}
          openSecondary
          open={this.props.level1}
        >
          <AppBar
            className={styles.appBar}
            title="Back"
            onTitleClick={this.props.handleBacklevel1}
            style={materialStyle.appBarStyle}
            showMenuIconButton={false}
            iconElementRight={
              <IconButton
                className={styles.close}
                onClick={this.props.handleClose}
              >
                <NavigationClose />
              </IconButton>
            }
          />
          {this.renderMostPopular()}
          {this.renderLevel()}
        </Drawer>

        <Drawer
          width="100%"
          style={this.props.style}
          openSecondary
          open={this.props.level2}
        >
          <AppBar
            className={styles.appBar}
            title="Back"
            onTitleClick={this.props.handleBacklevel2}
            style={materialStyle.appBarStyle}
            showMenuIconButton={false}
            iconElementRight={
              <IconButton
                className={styles.close}
                onClick={this.props.handleClose}
              >
                <NavigationClose />
              </IconButton>
            }
          />
          <h4 className={styles.mobileMenuHeadingstyles}>
            {this.state.labelLevel1}
          </h4>
          {this.renderSubLevel(this.state.NId)}
          <p>
            <span
              role="button"
              tabIndex={-42}
              onKeyUp={() => false}
              className={
                this.state.PopularInCat.length < 5
                  ? `${styles.dNone}`
                  : `${styles.dBlock}`
              }
              onClick={() => this.showMore}
            >
              {this.state.seeMore ? (
                <span className={styles.showAll}>Show less</span>
              ) : (
                <span className={styles.showAll}>Show All</span>
              )}
            </span>
          </p>
          <Divider />
          <h4 className={styles.popularInCat}>
            <span className={styles.popularBold}>POPULAR</span> IN THIS CATEGORY
          </h4>
          {this.renderPopularInCat()}
        </Drawer>

        <Drawer
          width="100%"
          style={this.props.style}
          openSecondary
          open={this.props.level3}
        >
          <AppBar
            className={styles.appBar}
            title="Back"
            onTitleClick={this.props.handleBacklevel3}
            style={materialStyle.appBarStyle}
            showMenuIconButton={false}
            iconElementRight={
              <IconButton
                className={styles.close}
                onClick={this.props.handleClose}
              >
                <NavigationClose />
              </IconButton>
            }
          />
          <h4 className={styles.mobileMenuHeadingstyles}>
            {this.state.labelLevel2}
          </h4>
          {this.renderSubLevel2(this.state.NId2)}
        </Drawer>
      </div>
    );
  }
}
