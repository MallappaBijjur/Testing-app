/* @flow */
import React from 'react';
import { connect } from 'react-redux';
import type { Connector } from 'react-redux';
import Drawer from 'material-ui/Drawer';
import { Link } from 'react-router-dom';
import AppBar from 'material-ui/AppBar';
import IconButton from 'material-ui/IconButton';
import MenuItem from 'material-ui/MenuItem';
import Divider from 'material-ui/Divider';
import NavigationClose from 'material-ui/svg-icons/navigation/close';
import styles from './styles.scss';
import MobileMenuLevel1 from './MenuLevel1';
import * as subMenuAction from '../../actions/mobileSubMenu';
import type {
  subMenuData as subMenuDataType,
  Dispatch,
  ReduxState
} from '../../types';
import { sideNavMobQaAPI } from '../../config/serviceAPI';

type Props = {
  subMenuData: subMenuDataType,
  fetchMobileSubMenu: any => void,
  myAccountTitles: any,
  menuItems: any
};

type State = {
  auth: boolean,
  open: boolean,
  accountsTab: boolean,
  level1: boolean,
  level2: boolean,
  level3: boolean
};

class SideBarMenu extends React.Component<Props, State> {
  constructor(props) {
    super(props);
    this.state = {
      auth: false,
      open: false,
      accountsTab: false,
      level1: false,
      level2: false,
      level3: false
    };
  }

  handleSubMenu = (menu: any) => {
    this.setState({
      level1: true
    });
    this.props.fetchMobileSubMenu(menu);
  };
  changeState = () => {
    this.setState({
      level2: true
    });
  };
  changeState1 = () => {
    this.setState({
      level3: true
    });
  };
  handleToggle = () => this.setState({ open: !this.state.open });
  handleAccounts = () =>
    this.setState({ accountsTab: !this.state.accountsTab });
  handleAccountsBack = () =>
    this.setState({ accountsTab: !this.state.accountsTab });
  level1Handle = () => this.setState({ level1: !this.state.level1 });
  level2Handle = () => this.setState({ level2: !this.state.level2 });
  level3Handle = () => this.setState({ level3: !this.state.level3 });
  handleClose = () =>
    this.setState({
      auth: false,
      open: false,
      accountsTab: false,
      level1: false,
      level2: false,
      level3: false
    });

  renderlist() {
    const { myAccountTitles } = this.props;
    if (this.state.auth) {
      return (
        <span>
          <MenuItem className={styles.sideMenuItem}> Hi User </MenuItem>
          <MenuItem className={styles.sideMenuItem}> My Account </MenuItem>
          <MenuItem className={styles.sideMenuItem}> Sign Out </MenuItem>
        </span>
      );
    }
    return (
      <span>
        <a href={sideNavMobQaAPI}>
          <MenuItem className={styles.sideMenuItem}>
            {' '}
            {myAccountTitles.mf_homepage_header_signin}{' '}
          </MenuItem>
        </a>
        <Link to="/create">
          <MenuItem className={styles.sideMenuItem}>
            {' '}
            {myAccountTitles.mf_homepage_header_createaccount}{' '}
          </MenuItem>
        </Link>
        <Link to="/create">
          <MenuItem className={styles.sideMenuItem}>
            {' '}
            {myAccountTitles.mf_homepage_header_trackorder}
            <span className={styles.subInfo}>
              {' '}
              {myAccountTitles.mf_homepage_header_trackmanage}{' '}
            </span>
          </MenuItem>
        </Link>
      </span>
    );
  }

  renderMenuItemsMobile() {
    const { menuItems } = this.props;
    return menuItems.map(
      (item, index) => (
        <MenuItem
          key={item.displayName}
          primaryText={item.displayName}
          className={styles.sideMenuTitle}
          id={index}
          onClick={() => this.handleSubMenu(item)}
        />
      ),
      this
    );
  }

  render() {
    const materialStyle = {
      appBarStyle: {
        background: 'black',
        color: 'white'
      }
    };
    return (
      <div>
        <span
          className={styles.menuIcon}
          onClick={this.handleToggle}
          role="button"
          onKeyUp={() => false}
          tabIndex={-45}
        >
          <img
            className={styles.cartIcon}
            src="/images/navigation-drawer.png"
            alt="menu icon"
          />
          <span className={styles.menuText}>MENU</span>
        </span>
        <Drawer width="100%" openSecondary open={this.state.open}>
          <AppBar
            className={styles.appBar}
            title="MENU"
            showMenuIconButton={false}
            style={materialStyle.appBarStyle}
            iconElementRight={
              <IconButton className={styles.close} onClick={this.handleClose}>
                <NavigationClose />
              </IconButton>
            }
          />
          <MenuItem
            className={styles.sideMenuItem}
            onClick={this.handleAccounts}
          >
            My Account
          </MenuItem>
          <MenuItem className={styles.sideMenuItem} onClick={this.handleClose}>
            Store Locator
          </MenuItem>
          <Divider />
          <p className={styles.sideMenuItemHeading}>SHOP ALL</p>
          {this.renderMenuItemsMobile()}
          <Divider />
          <p className={styles.sideMenuItemHeading}>SHOP DEALS</p>
          <MenuItem className={styles.sideMenuItem} onClick={this.handleClose}>
            Add Vehicle
          </MenuItem>
          <MenuItem className={styles.sideMenuItem} onClick={this.handleClose}>
            Track Order
          </MenuItem>
          <MenuItem className={styles.sideMenuItem} onClick={this.handleClose}>
            Contact Us
          </MenuItem>
        </Drawer>

        <Drawer width="100%" openSecondary open={this.state.accountsTab}>
          <AppBar
            className={styles.appBar}
            title="Back"
            onTitleClick={this.handleAccountsBack}
            showMenuIconButton={false}
            style={materialStyle.appBarStyle}
            iconElementRight={
              <IconButton className={styles.close} onClick={this.handleClose}>
                <NavigationClose />
              </IconButton>
            }
          />
          <MenuItem
            primaryText="My Accounts"
            className={styles.sideMenuTitle}
            onClick={this.handleClose}
          />
          {this.renderlist()}
          <Divider />
        </Drawer>
        <MobileMenuLevel1
          subMenuData={this.props.subMenuData}
          level1={this.state.level1}
          level2={this.state.level2}
          level3={this.state.level3}
          handleClose={this.handleClose}
          handleBacklevel1={this.level1Handle}
          handleBacklevel2={this.level2Handle}
          handleBacklevel3={this.level3Handle}
          changeState={this.changeState}
          changeState2={this.changeState1}
          style={materialStyle.appBarStyle}
        />
      </div>
    );
  }
}

const connector: Connector<{}, Props> = connect(
  ({ subMenuData }: ReduxState) => ({ subMenuData }),
  (dispatch: Dispatch) => ({
    fetchMobileSubMenu: menu => dispatch(subMenuAction.fetchMobileSubMenu(menu))
  })
);

export default connector(SideBarMenu);
