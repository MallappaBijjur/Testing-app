/* @flow */

import React from 'react';
import type { Element } from 'react';
import SideBarMenu from './sidenavMobile';

type Props = {
  styles: Object,
  myAccountTitles: Object,
  menuItems: Object
};

const Menu = (props: Props): Element<'div'> => (
  <div className={props.styles.menuContainer}>
    <SideBarMenu
      menuItems={props.menuItems}
      myAccountTitles={props.myAccountTitles}
    />
  </div>
);

export default Menu;
