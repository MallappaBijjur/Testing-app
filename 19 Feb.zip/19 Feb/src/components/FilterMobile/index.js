/* @flow */

import React from 'react';
import Drawer from 'material-ui/Drawer';
import AppBar from 'material-ui/AppBar';
import Checkbox from 'material-ui/Checkbox';
import UnCheckedIcon from 'material-ui/svg-icons/toggle/check-box-outline-blank';
import CheckedIcon from 'material-ui/svg-icons/toggle/check-box';
import IconButton from 'material-ui/IconButton';
import Divider from 'material-ui/Divider';
import NavigationClose from 'material-ui/svg-icons/navigation/close';
import RaisedButton from 'material-ui/RaisedButton';
import ChipExampleArray from './chip';
import styles from './styles.scss';
import ShelfVehicle from '../YMME/ShelfVehicle';

type Props = {
  handleFilter?: string => void,
  location?: Object,
  history?: any,
  filterData?: Object,
  data?: Object,
  max?: number,
  min?: number
};

type State = {
  open: boolean,
  seeMore: boolean,
  filterLength: number
};

class FilterMobile extends React.Component<Props, State> {
  static defaultTypes = {
    history: {}
  };
  constructor(props: Props) {
    super(props);
    this.state = {
      open: false,
      seeMore: false,
      filterLength: 5
    };
    // this.showMore = this.showMore.bind(this);
    // this.handleFilter = this.handleFilter.bind(this);
  }

  // handleChange = (event, index, value) => this.setState({ value });
  handleToggle = () => this.setState({ open: !this.state.open });
  handleClose = () =>
    this.setState({
      open: false
    });

  handleFilter = (seoUrl: string) => {
    this.setState({
      open: false
    });
    // const { filterurl } = this.state;
    const { pathname } = this.props.location
      ? this.props.location
      : { pathname: '' };
    const { push } = this.props.history ? this.props.history : { push: null };
    const p = seoUrl.indexOf('?');
    const num = seoUrl.substring(p + '?filters='.length);
    // const rest = seoUrl.substring(0, p);
    // this.setState({
    //   filterquery: num
    // });
    // const filterBy = this.props.location.search;
    // const FilterData = filterBy.replace('?', '&');

    if (push) {
      push({ pathname: `${pathname}`, search: `filters=${num}` });
    }
  };

  showMore = () => {
    const fData = this.props.filterData
      ? this.props.filterData
      : { refinementMenuList: [] };
    const something =
      this.state.filterLength === 5
        ? this.setState({
            filterLength: fData.refinementMenuList[0].refinements.length,
            seeMore: true
          })
        : this.setState({ filterLength: 5, seeMore: false });
    return something;
  };

  render() {
    // const { seeMore, filterLength } = this.state;
    const { filterData } = this.props;
    const checkboxStyles = {
      block: {
        maxWidth: 250
      },
      checkbox: {
        marginBottom: 16
      }
    };
    const materialStyle = {
      appBarStyle: {
        background: 'black',
        color: 'white'
      }
    };

    return (
      <div>
        <h1 className={styles.filterName}>OXYGEN FILTER</h1>
        <div className={styles.filterMobile}>
          <h4 className={styles.boldText}>
            {this.props.min} 1-12{this.props.max} Results of{' '}
            {this.props.data && this.props.data.totalNumrecords}
            for Oxygen Filter
          </h4>
          <RaisedButton
            labelColor="white"
            backgroundColor="black"
            label="Filter"
            onClick={this.handleToggle}
          />
          <ChipExampleArray className={styles.chipSet} />
          <Drawer width="100%" openSecondary open={this.state.open}>
            <AppBar
              className={styles.appBar}
              title="Back"
              showMenuIconButton={false}
              style={materialStyle.appBarStyle}
              iconElementRight={
                <IconButton className={styles.close} onClick={this.handleClose}>
                  <NavigationClose />
                </IconButton>
              }
            />
            <h4 className={styles.filterHeading}>
              <span className={styles.filter}> FILTER </span>{' '}
              <span className={styles.lighter}>RESULTS</span>
            </h4>
            <div className={styles.vehicleFilter}>
              <ShelfVehicle />
            </div>
            <Divider />
            <Divider />
            {filterData &&
              filterData.refinementMenuList &&
              filterData.refinementMenuList.map(item => (
                <div className={styles.vehicleFilter} key={item.displayName}>
                  <p className={styles.filterSubHeading}>
                    {item.dimensionName.toUpperCase()}
                  </p>
                  {item.refinements
                    .slice(0, this.state.filterLength)
                    .map(itemRefinement => (
                      <Checkbox
                        uncheckedIcon={
                          <UnCheckedIcon style={{ fill: '#484848' }} />
                        }
                        checkedIcon={
                          <CheckedIcon style={{ fill: '#f26100' }} />
                        }
                        onClick={this.handleClose}
                        onCheck={() => {
                          if (this.props.handleFilter) {
                            this.props.handleFilter(
                              itemRefinement.properties.seoUrl
                            );
                          }
                        }}
                        key={itemRefinement.label}
                        label={`${itemRefinement.label} ${
                          itemRefinement.count
                        }`}
                        labelStyle={{ color: '#484848' }}
                        style={checkboxStyles.checkbox}
                      />
                    ))}
                  <p>
                    <button
                      className={
                        item.refinements.length <= 5
                          ? `${styles.dNone}`
                          : `${styles.dBlock}`
                      }
                      onClick={this.showMore}
                    >
                      {this.state.seeMore ? (
                        <span>Show less</span>
                      ) : (
                        <span>Show more</span>
                      )}
                    </button>
                  </p>
                  <Divider />
                </div>
              ))}
          </Drawer>
        </div>
      </div>
    );
  }
}

export default FilterMobile;
