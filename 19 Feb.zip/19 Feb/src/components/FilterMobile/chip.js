/* @flow */
import React from 'react';
import Chip from 'material-ui/Chip';

type State = {
  chipData: any
};

export default class ChipExampleArray extends React.Component<{}, State> {
  state = {
    chipData: []
  };

  styles = {
    chip: {
      marginRight: 10,
      marginTop: 10
    },
    wrapper: {
      display: 'flex',
      flexWrap: 'wrap'
    },
    deleteIcon: {
      float: 'left'
    }
  };

  handleRequestDelete = (key: number) => {
    if (key === 3) {
      console.log('delete filter');
    }

    const { chipData } = this.state;
    const chipToDelete = chipData.map(chip => chip.key).indexOf(key);
    chipData.splice(chipToDelete, 1);
    this.setState({ chipData });
  };

  renderChip(data: Object) {
    return (
      <Chip
        backgroundColor="rgb(255,255,255)"
        deleteIconStyle={this.styles.deleteIcon}
        key={data.key}
        onRequestDelete={() => this.handleRequestDelete(data.key)}
        style={this.styles.chip}
      >
        {data.label}
      </Chip>
    );
  }

  render() {
    return (
      <div style={this.styles.wrapper}>
        {this.state.chipData.map(this.renderChip, this)}
      </div>
    );
  }
}
