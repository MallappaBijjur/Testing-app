// @flow
import React from 'react';
import TextField from 'material-ui/TextField';
import * as styles from '../../containers/CreateAccount/styles.scss';

type Props = {
  label: string,
  input: Object,
  inputType: string,
  meta: Object
};

const textStyles = {
  floatingLabelFocusStyle: {
    background: 'white',
    height: '20px',
    padding: '0 5px'
  },
  errorInputStyle: {
    bottom: '12px',
    left: '-14px',
    color: '#CF1322'
  },
  errorInputStyleRewards: {
    bottom: '12px',
    color: '#CF1322'
  },
  borderGrey: {
    border: '1px solid #ccc'
  },
  errorUnderline: {
    border: '1px solid $autozone-red',
    left: 0,
    bottom: 0,
    opacity: 1,
    display: 'block',
    width: '100%'
  },
  errorUnderlinePwd: {
    border: '1px solid $autozone-red',
    left: '-1px',
    bottom: '-1px',
    opacity: 1,
    display: 'block',
    width: '100%'
  },
  labelStyle: {
    height: '13px',
    top: 0,
    bottom: 0,
    margin: 'auto'
  },
  labelShrinkStyle: {
    height: '20px'
  }
};

const renderTextField = ({
  label,
  input,
  inputType,
  meta: { touched, error }
}: Props) => (
  <TextField
    id={input.name}
    floatingLabelText={label}
    hintText={label}
    type={inputType}
    className={styles.inputTextBox}
    floatingLabelFocusStyle={textStyles.floatingLabelFocusStyle}
    errorStyle={textStyles.errorInputStyle}
    errorText={touched && error}
    inputStyle={textStyles.borderGrey}
    floatingLabelStyle={textStyles.labelStyle}
    floatingLabelShrinkStyle={textStyles.labelShrinkStyle}
    underlineFocusStyle={textStyles.errorUnderline}
    {...input}
  />
);

export default renderTextField;
