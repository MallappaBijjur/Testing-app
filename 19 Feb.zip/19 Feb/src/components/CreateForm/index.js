// @flow
import React, { PureComponent } from 'react';
import TextField from 'material-ui/TextField';
import Checkbox from 'material-ui/Checkbox';
import RaisedButton from 'material-ui/RaisedButton';
import { Field, reduxForm } from 'redux-form';
import { connect } from 'react-redux';
import { Accordion } from 'semantic-ui-react';
import * as styles from '../../containers/CreateAccount/styles.scss';
import validate from './validation';
import renderTextField from './inputField';
import { createFormQaAPI } from '../../config/serviceAPI';

type Props = {
  handleSubmit: () => void,
  SubmitStatus: () => void,
  data: Object
};

type checkBoxProps = {
  input: Object,
  label: string
};

type RewarProps = {
  label: string,
  input: any,
  meta: Object
};

const styles1 = {
  errorInputStyleRewards: {
    bottom: '12px',
    color: '#CF1322'
  }
};

const renderCheckbox: Function = ({ input, label }: checkBoxProps) => (
  <Checkbox
    label={label}
    checked={!!input.value}
    onCheck={input.onChange}
    {...input}
  />
);

const renderRewardTextField: Function = ({
  label,
  input,
  meta: { touched, error }
}: RewarProps) => (
  <TextField
    id={label}
    className={styles.rewardsText}
    hintText={label || '9101000389891796'}
    floatingLabelText={label}
    floatingLabelStyle={{
      top: '29px',
      left: '15px',
      fontWeight: 'normal',
      border: 'none'
    }}
    floatingLabelFocusStyle={{
      color: '#a9aaa8',
      left: '15px',
      paddingBottom: '5px'
    }}
    style={{
      width: '100%',
      height: '56px',
      border: '1px solid black'
    }}
    errorText={touched && error}
    errorStyle={styles1.errorInputStyleRewards}
    {...input}
  />
);

type State = {
  activeIndex: number,
  inputType: string
};

class CreateForm extends PureComponent<Props, State> {
  constructor(props) {
    super(props);
    this.state = { activeIndex: 0, inputType: 'password' };
  }

  submitFormHandler = () => {
    const { handleSubmit, SubmitStatus } = this.props;
    handleSubmit();
    if (SubmitStatus) {
      console.log('SubmitStatus ', SubmitStatus);
    }
  };

  handleClick = (e, titleProps) => {
    const { index } = titleProps;
    const { activeIndex } = this.state;
    const newIndex = activeIndex === index ? -1 : index;
    this.setState({ activeIndex: newIndex });
  };

  togglePwd = () => {
    const { inputType } = this.state;
    const inputToSet = inputType === 'text' ? 'password' : 'text';
    this.setState({ inputType: inputToSet });
  };

  handleKeyUp = e => e.preventDefault();

  render() {
    const { activeIndex } = this.state;
    const { data } = this.props;

    let arrowButton;
    if (activeIndex === 0) {
      arrowButton = (
        <div className={styles.arrowDownPosition}>
          <svg width="24" height="24" viewBox="0 0 24 24">
            <path d="M7.41 15.41L12 10.83l4.59 4.58L18 14l-6-6-6 6z" />
          </svg>
        </div>
      );
    } else {
      arrowButton = (
        <div className={styles.arrowUpPosition}>
          <svg width="24" height="24" viewBox="0 0 24 24">
            <path d="M7.41 7.84L12 12.42l4.59-4.58L18 9.25l-6 6-6-6z" />
          </svg>
        </div>
      );
    }
    return (
      <form>
        <div>
          <div style={{ paddingBottom: '20px' }}>
            <Field
              name="firstName"
              component={renderTextField}
              label={data.mf_registration_firstName}
              inputType="text"
            />
            <Field
              name="lastName"
              component={renderTextField}
              label={data.mf_registration_lastName}
              inputType="text"
            />
            <Field
              name="postalCode"
              component={renderTextField}
              label={data.mf_registration_zip}
              inputType="text"
            />
            <Field
              name="phoneNumber"
              component={renderTextField}
              label={data.mf_registration_phone}
              inputType="text"
            />
            <Field
              name="email"
              component={renderTextField}
              label={data.mf_registration_email}
              inputType="text"
            />
            <div className={styles.passwordHolder}>
              <Field
                name="password"
                component={renderTextField}
                label={data.mf_registration_password}
                inputType={this.state.inputType}
              />
              <span
                className={styles.showPwd}
                onClick={this.togglePwd}
                role="button"
                onKeyUp={this.handleKeyUp}
                tabIndex="0"
              >
                {this.state.inputType === 'password' ? 'SHOW' : 'HIDE'}
              </span>
            </div>
          </div>
          <div className={styles.regRewardSection}>
            <Accordion>
              <Accordion.Title
                active={activeIndex === 0}
                index={0}
                onClick={this.handleClick}
              >
                <div className={styles.regRewardSectionTop}>
                  {data.mf_registration_rewards}
                  {arrowButton}
                </div>
              </Accordion.Title>
              <Accordion.Content active={activeIndex === -1}>
                <div className={styles.regRewardSectionMid}>
                  {data.mf_registration_rewards_msg}
                </div>
                <Field
                  name="reward"
                  component={renderRewardTextField}
                  label={data.mf_registration_rewards_textbox_lbl}
                />
              </Accordion.Content>
            </Accordion>
          </div>
          <div className={styles.regSubscription}>
            <div className={styles.offerCheckBox}>
              <Field name="subscribe" component={renderCheckbox} />
            </div>
            <div className={styles.receiveOffer}>
              {data.mf_registration_privacy}
              <a
                href="/readYourPolicy"
                style={{
                  display: 'block',
                  textDecoration: 'underline',
                  color: '#333'
                }}
              >
                {data.mf_registration_privacy_2}
              </a>
            </div>
            <div className={styles.regReadTerms}>
              {data.mf_registration_TermsandConditions}
              <a href="/termsAndConditions">
                {data.mf_registration_TermsandConditions_2}
              </a>
            </div>
            <div className={styles.regButtonSection}>
              <RaisedButton
                onClick={this.submitFormHandler}
                // disabled={pristine || submitting}
                label={data.mf_registration_signUp}
                className={styles.regPrimaryBtn}
              />
              <RaisedButton
                // disabled={pristine || submitting}
                label={data.mf_registration_cancel}
                className={styles.regSecondaryBtn}
              />
            </div>
            <div className={styles.regSignInLink}>
              {data.mf_registration_SignIn}
              <a href={createFormQaAPI}>{data.mf_registration_SignIn_2}</a>
            </div>
          </div>
        </div>
      </form>
    );
  }
}

const CreateFormRedux = reduxForm({
  form: 'createFormValues',
  touchOnBlur: false,
  validate
})(CreateForm);

// const selector = formValueSelector('createFormValues');

const connectedCreateForm = connect(state => ({
  initialValues: state.formInfo.defaultFormData,
  formValues: state.form.createFormValues && state.form.createFormValues.values,
  SubmitStatus: state.formInfo.SubmitStatus
}))(CreateFormRedux);

export default connectedCreateForm;
