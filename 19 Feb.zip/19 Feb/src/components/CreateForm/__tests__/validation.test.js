// @flow
import validation from '../validation';

describe('CreateForm Validation', () => {
  test('validation', () => {
    const values = {
      firstName: '1',
      lastName: '2',
      postalCode: 'abc',
      phoneNumber: '123',
      email: 'xyz',
      password: '1',
      reward: 'p'
    };

    const props = {
      mf_registration_required_lbl: 'test',
      data: {
        mf_registration_error_firstname_alphabets: 'test',
        mf_registration_error_lastname_alphabets: 'test',
        mf_registration_error_zip_not_valid: 'test',
        mf_registration_error_phone_not_valid: 'test',
        mf_registration_error_email_not_valid: 'test',
        mf_registration_error_password: 'test',
        mf_registration_error_rewards: 'test'
      }
    };

    const errors = validation(values, props);

    expect(Object.keys(errors).length).toBe(Object.keys(values).length);
  });
});
