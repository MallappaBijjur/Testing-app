/* @flow */

export default function(values: Object, props: Object) {
  const errors = {};
  const requiredFields = [
    'firstName',
    'lastName',
    'email',
    'postalCode',
    'phoneNumber',
    'password'
  ];
  requiredFields.forEach(field => {
    if (!values[field]) {
      errors[field] = props.data.mf_registration_required_lbl;
    }
  });

  if (values.firstName && !/(^[a-z ]+$)/i.test(values.firstName)) {
    errors.firstName = props.data.mf_registration_error_firstname_alphabets;
  }
  if (values.lastName && !/(^[a-z ]+$)/i.test(values.lastName)) {
    errors.lastName = props.data.mf_registration_error_lastname_alphabets;
  }

  if (values.postalCode && !/^[0-9]*$/i.test(values.postalCode)) {
    errors.postalCode = props.data.mf_registration_error_zip_not_valid;
  }
  if (values.phoneNumber && !/^\d{10}$/.test(values.phoneNumber)) {
    errors.phoneNumber = props.data.mf_registration_error_phone_not_valid;
  }
  if (
    values.email &&
    !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)
  ) {
    errors.email = props.data.mf_registration_error_email_not_valid;
  }
  if (values.password && !/^.{4,30}$/.test(values.password)) {
    errors.password = props.data.mf_registration_error_password;
  }
  if (values.reward && !/^\d{16}$/.test(values.reward)) {
    errors.reward = props.data.mf_registration_error_rewards;
  }

  return errors;
}
