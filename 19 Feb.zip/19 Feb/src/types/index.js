/* @flow */
/* eslint-disable no-use-before-define */

import type { Store as ReduxStore } from 'redux';

import type { Reducers } from '../reducers';

// Reducers
export type Home = {
  +readyStatus: string,
  +err: any,
  +list: Array<Object>
};

export type UserInfo = {
  +[userId: string]: {
    +readyStatus: string,
    +err: any,
    +info: Object
  }
};

export type NavInfo = {
  +[title: string]: {
    +readyStatus: string,
    +err: any,
    +info: Object
  }
};

export type CreateAccountData = {
  +readyStatus: string,
  +err: any,
  +viewInfo: Object
};

export type submitForm = {
  +readyStatus: string,
  +err: any,
  +defaultFormData: Object,
  +SubmitStatus: boolean
};

export type ForgotData = {
  +readyStatus: string,
  +err: any,
  +viewInfo: Object
};

export type SubmitForgotForm = {
  +readyStatus: string,
  +err: any,
  +formValues: Object
};

export type ResetFormData = {
  +readyStatus: string,
  +err: any,
  +viewInfo: Object
};

export type ResetForgotForm = {
  +readyStatus: string,
  +err: any,
  +formValues: Object
};

export type myAccountData = {
  +readyStatus: string,
  +err: any,
  +list: any
};

export type subMenuData = {
  +readyStatus: string,
  +err: any,
  +list: any,
  +headingL1: any
};

export type HeroContentData = {
  +readyStatus: string,
  +err: any,
  +viewInfo: Object
};

export type CategoryData = {
  +readyStatus: string,
  +err: any,
  +catData: Object
};

export type SubCategoryData = {
  +readyStatus: string,
  +err: any,
  +subCatData: Object
};

export type SplitContentData = {
  +readyStatus: string,
  +err: any,
  +viewInfo: Object
};

export type ProductData = {
  +readyStatus: string,
  +err: any,
  +viewInfo: Object
};

export type ShelfData = {
  readyStatus: string,
  isList: boolean,
  parts: Object,
  price: any,
  skuIds: Array<number>,
  relatedParts: Object,
  relatedProducts: Object
};

export type TopNavData = {
  +readyStatus: string,
  +err: any,
  +homeData: Object,
  +subCatData: Object,
  +level1: Object,
  +level2MostPop: Object,
  +headingL1: any,
  +level2: Object,
  +headingL2: any
};

export type YMMEDataType = {
  +readyStatus: string,
  +err: any,
  +data: any
};

// State
type $ExtractFunctionReturn = <V>(v: (...args: any) => V) => V; // eslint-disable-line no-undef
export type ReduxState = $ObjMap<Reducers, $ExtractFunctionReturn>; // eslint-disable-line no-undef

// Action
export type Action =
  | { type: 'USERS_REQUESTING' }
  | { type: 'USERS_SUCCESS', data: Array<Object> }
  | { type: 'USERS_FAILURE', err: any }
  | { type: 'USER_REQUESTING', userId: string }
  | { type: 'USER_SUCCESS', userId: string, data: Object }
  | { type: 'USER_FAILURE', userId: string, err: any }
  | { type: 'CREATE_REQUESTING' }
  | { type: 'CREATE_SUCCESS', data: Object }
  | { type: 'CREATE_FAILURE', err: any }
  | { type: 'FORGOT_REQUESTING' }
  | { type: 'FORGOT_SUCCESS', data: Object }
  | { type: 'FORGOT_FAILURE', err: any }
  | { type: 'RESET_REQUESTING' }
  | { type: 'RESET_SUCCESS', data: Object }
  | { type: 'RESET_FAILURE', err: any }
  | { type: 'SUBMIT_REQUESTING' }
  | { type: 'SUBMIT_SUCCESS', data: Object }
  | { type: 'SUBMIT_FAILURE', err: any }
  | { type: 'SUBMITFORGOT_REQUESTING' }
  | { type: 'SUBMITFORGOT_SUCCESS', data: Object }
  | { type: 'SUBMITFORGOT_FAILURE', err: any }
  | { type: 'SUBMITRESET_REQUESTING' }
  | { type: 'SUBMITRESET_SUCCESS', data: Object }
  | { type: 'SUBMITRESET_FAILURE', err: any }
  | { type: 'MYACCOUNT_REQUESTING' }
  | { type: 'MYACCOUNT_SUCCESS', data: Object }
  | { type: 'MYACCOUNT_FAILURE', err: any }
  | { type: 'MOBILESUBMENU_REQUESTING' }
  | { type: 'MOBILESUBMENU_SUCCESS', data: Object, mostPopularLabel: any }
  | { type: 'MOBILESUBMENU_FAILURE', err: any }
  | { type: 'HERO_REQUESTING' }
  | { type: 'HERO_SUCCESS', data: Object }
  | { type: 'HERO_FAILURE', err: any }
  | { type: 'SPLIT_REQUESTING' }
  | { type: 'SPLIT_SUCCESS', data: Object }
  | { type: 'SPLIT_FAILURE', err: any }
  | { type: 'PRODUCT_REQUESTING', data: Object }
  | { type: 'PRODUCT_SUCCESS', data: Object }
  | { type: 'PRODUCT_FAILURE', err: any }
  | { type: 'MYACCOUNTS_REQUESTING' }
  | { type: 'MYACCOUNTS_SUCCESS', data: Object }
  | { type: 'MYACCOUNTS_FAILURE', err: any }
  | { type: 'CATEGORY_REQUESTING' }
  | { type: 'CATEGORY_SUCCESS', data: Object }
  | { type: 'CATEGORY_FAILURE', err: any }
  | { type: 'SUB_CATEGORY_REQUESTING' }
  | { type: 'SUB_CATEGORY_SUCCESS', data: Object }
  | { type: 'SUB_CATEGORY_FAILURE', err: any }
  | { type: 'ADD_TO_CART_REQUESTING' }
  | { type: 'ADD_TO_CART_SUCCESS', data: Object }
  | { type: 'ADD_TO_CART_FAILURE', err: any }
  | { type: 'HOME_REQUESTING' }
  | { type: 'HOME_SUCCESS', data: Object }
  | { type: 'HOME_FAILURE', err: any }
  | { type: 'SUBCAT_REQUESTING' }
  | { type: 'SUBCAT_SUCCESS', data: Object }
  | { type: 'SUBCAT_FAILURE', err: any }
  | { type: 'FETCH_SUBMENU', id: any, label: string }
  | { type: 'FETCH_SUBMENU_2', id: any, label: string }
  | { type: 'FETCH_MOST_POP' }
  | { type: 'RESET_NAV_DATA' }
  | { type: 'SET_VIEW', view: boolean }
  | { type: 'PARTS_SUCCESS', data: Object }
  | { type: 'PARTS_FAILURE', err: any }
  | { type: 'PARTS_REQUESTING' }
  | { type: 'PRICE_SUCCESS', data: any, skuIds: any }
  | { type: 'PRICE_FAILURE', err: any }
  | { type: 'YMME_REQUESTING' }
  | { type: 'YMME_SUCCESS', data: Object }
  | { type: 'YMME_YEAR_SUCCESS', data: Object }
  | { type: 'YMME_MAKE_SUCCESS', data: Object }
  | { type: 'YMME_MODEL_SUCCESS', data: Object }
  | { type: 'YMME_ENGINE_SUCCESS', data: Object }
  | { type: 'YMME_ADD_VEHICLE_SUCCESS', data: Object }
  | { type: 'YMME_FAILURE', err: any }
  | { type: 'YMME_VEHICLE_LIST_SUCCESS', data: Object }
  | { type: 'YMME_REMOVE_VEHICLE_SUCCESS', data: Object };

export type Dispatch = (
  action: Action | ThunkAction | PromiseAction | Array<Action>
) => any;
export type GetState = () => ReduxState;
export type ThunkAction = (dispatch: Dispatch, getState: GetState) => any;
export type PromiseAction = Promise<Action>;

// Store
export type Store = ReduxStore<ReduxState, Action>;

export type BadgeDetails = {
  eligibleForNextDay: boolean,
  vehicleFit: boolean
};
