/* @flow */
const baseURL = JSON.stringify(process.env.BASE_URL) || __BASE_URL__;
const relPath = {
  getCatData: '/autozone/v1/page/getCategoryData?seourl=',
  createAccPage: '/autozone/v1/page/createAccountPage',
  currentUser: '/autozone/v1/currentUser',
  currentUserResetPwd: '/autozone/v1/currentUser/resetPassword',
  resetPwdPage: '/autozone/v1/page/resetPasswordPage',
  forgotPwd: '/autozone/v1/currentUser/forgotPassword',
  forgotPwdPage: '/autozone/v1/page/forgotPasswordPage',
  homePage: '/autozone/v1/page/homePage',
  topNavMenu: '/autozone/v1/page/topNavMenu',
  pdpPageDetails: '/autozone/v1/productDetails/pdpPageDetails',
  commerceItems: '/autozone/v1/cart/commerceItems',
  shelfPageDetails: '/autozone/v1/page/shelfPageDetails',
  splitContent: '/autozone/v1/page/splitContent',
  ymme: '/autozone/v1/ymme'
};

const imageServer = 'https://dv-camaro1-xl07.autozone.com/';
const createFormQaAPI =
  'https://qa-api.autozone.com/auth/oauth/v2/authorize?client_id=l7xx85b096d1f8c3426cb3ed7724c7863444&response_type=code&redirect_uri=https://example.com&scope=ecommb2c';
const myAccQaAPI =
  'https://qa-api.autozone.com/auth/oauth/v2/authorize?client_id=l7xx85b096d1f8c3426cb3ed7724c7863444&response_type=code&redirect_uri=https://example.com&scope=ecommb2c';
const sideNavMobQaAPI =
  'https://qa-api.autozone.com/auth/oauth/v2/authorize?client_id=l7xx85b096d1f8c3426cb3ed7724c7863444&response_type=code&redirect_uri=https://example.com&scope=ecommb2c';
const rrAzrwebShelfTag =
  'https://display.ugc.bazaarvoice.com/bvstaging/static/autozone/en_US/bvapi.js';
const rrAzrwebPdpTag =
  'https://apps.bazaarvoice.com/deployments/autozone/main_site/staging/en_US/bv.js';

export {
  imageServer,
  createFormQaAPI,
  myAccQaAPI,
  sideNavMobQaAPI,
  rrAzrwebShelfTag,
  rrAzrwebPdpTag
};
export default (key: any) => baseURL + relPath[key];
