/* @flow */
import type { Dispatch } from './types';
import { fetchCreateAccountData } from './actions/createAccount';
import { fetchForgotAccountData } from './actions/forgotAccount';
import { fetchResetFormData } from './actions/resetAccount';
import NotFoundPage from './containers/NotFound';
import { Confirmation } from './containers/CreateAccount/Confirmation';
import CreateAccountPage from './containers/CreateAccount';
import ForgotPasswordPage from './containers/ForgotPassword';
import ResetPasswordPage from './containers/ResetPassword';
import MainContentComponent from './containers/HeroContentBanner/MainContentBlock';
import CatContainer from './containers/Category/index';
import ProductShelf from './containers/ProductShelf';
import ProductDetailPage from './containers/ProductDetail';
import { fetchCategoryData } from './actions/category';

export default [
  {
    path: '/',
    exact: true,
    component: MainContentComponent
  },

  {
    path: '/home',
    exact: true,
    component: MainContentComponent
  },

  {
    path: '/create',
    exact: true,
    component: CreateAccountPage, // Add your route here
    loadData: (dispatch: Dispatch) =>
      Promise.all([
        dispatch(fetchCreateAccountData()) // Register your server-side call action(s) here
      ])
  },

  {
    path: '/Confirmation',
    component: Confirmation
  },

  {
    path: '/forgotpassword',
    exact: true,
    component: ForgotPasswordPage,
    loadData: (dispatch: Dispatch) =>
      Promise.all([dispatch(fetchForgotAccountData())])
  },

  {
    path: '/resetPassword/:code',
    component: ResetPasswordPage,
    loadData: (dispatch: Dispatch) =>
      Promise.all([dispatch(fetchResetFormData())])
  },

  {
    path: '/shelfPage/:seoPath',
    component: ProductShelf
  },

  {
    path: '/product-detail',
    component: ProductDetailPage
  },

  {
    path: '/parts',
    loadData: (dispatch: Dispatch) =>
      Promise.all([dispatch(fetchCategoryData())]),
    component: CatContainer
  },

  {
    path: '*',
    component: NotFoundPage
  }
];
