// @flow
import React from 'react';
import { connect } from 'react-redux';
import type { Connector } from 'react-redux';
import type { Dispatch, ReduxState } from '../../types';
import Header from '../Header';
import { fetchCategoryData } from '../../actions/category';
import ProductBreadcrumb from '../../components/ProductDetailComp/ProductBreadcrumbs';
import {
  CategoryInfo,
  CategoryImage,
  ShopByCategory,
  MostPopularParts
} from '../../components/Category';

type Props = {
  location: Object,
  fetchCategoryData: string => void,
  catData: Object,
  readyStatus: string
};

export class CategoryContainer extends React.Component<Props> {
  componentDidMount() {
    const path = this.props.location.pathname;
    this.props.fetchCategoryData(path);
  }

  componentWillReceiveProps(newProps: Props) {
    if (this.props.location.pathname !== newProps.location.pathname) {
      newProps.fetchCategoryData(newProps.location.pathname);
    }
  }

  renderCategory = (catData: Object) => (
    <div>
      {Object.keys(catData).length !== 0 ? (
        <div>
          <Header />
          <ProductBreadcrumb data={catData.breadCrumbs} />
          <CategoryImage imageData={catData.heroImage} />
          <ShopByCategory catData={catData.childCategories} />
          <MostPopularParts data={catData.popularCategories} />
          <CategoryInfo description={catData.description} />
        </div>
      ) : null}
    </div>
  );

  render() {
    const data = this.props.catData;
    const readyStat = this.props.readyStatus;
    return (
      <div>
        {data && readyStat === 'CATEGORY_REQUESTING' && <div>Loading...</div>}
        {data && readyStat === 'CATEGORY_SUCCESS' && this.renderCategory(data)}
        {data &&
          readyStat === 'CATEGORY_FAILURE' && <div>Oops..Page Not Found</div>}
      </div>
    );
  }
}

const connector: Connector<{}, Props> = connect(
  (state: ReduxState) => ({
    catData: state.category.catData,
    readyStatus: state.category.readyStatus
  }),
  (dispatch: Dispatch) => ({
    fetchCategoryData: param => dispatch(fetchCategoryData(param))
  })
);

export default connector(CategoryContainer);
