/* @flow */
import React from 'react';
import { createStore } from 'redux';
import { Provider, connect } from 'react-redux';
import { mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import { CategoryContainer as Category } from '../index';

describe('<Category /> container', () => {
  const initialState = {
    category: {
      readyStatus: 'CATEGORY_SUCCESS',
      viewInfo: {
        '@class': 'com.autozone.diy.vo.AZCategoryDataVO',
        popularCategories: {
          '@class':
            'com.endeca.infront.cartridge.AZTopSubNavMostPopularCategoriesVO',
          mostPopularCategories: {
            10199999: [
              {
                seoUrl: '/batteries-starting-and-chargingbsc/batterybt',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490236_prd-Battery.jpg',
                NId: '10200175',
                label: 'Battery_BT'
              },
              {
                seoUrl: '/batteries-starting-and-chargingbsc/alternator',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490247_prd-Alternator.jpg',
                NId: '10600086',
                label: 'Alternator'
              },
              {
                seoUrl: '/batteries-starting-and-chargingbsc/starter',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490265_prd-Starter.jpg',
                NId: '10500045',
                label: 'Starter'
              }
            ],
            11199999: [
              {
                seoUrl: '/engine-management/oxygen-sensor',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490270_prd-Oxygen-Sensor.jpg',
                NId: '11600117',
                label: 'Oxygen Sensor'
              },
              {
                seoUrl: '/engine-management/mass-air-flow-sensor',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  'https://contentinfo.autozone.com/znetcs/product-info/en/US/c77/74-3940/image/2/',
                NId: '11600151',
                label: 'Mass Air Flow Sensor'
              },
              {
                seoUrl: '/engine-management/coolant-temperature-sensor',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490538_prd-Coolant-Temperature-Sensor.jpg',
                NId: '11600113',
                label: 'Coolant Temperature Sensor'
              }
            ],
            11499999: [
              {
                seoUrl: '/brakes-and-traction-control/brake-pads',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490185_prd-Brake-Pads-Front.jpg',
                NId: '11601233',
                label: 'Brake Pads'
              },
              {
                seoUrl: '/brakes-and-traction-control/brake-rotor',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490244_prd-Brake-Rotor-Front.jpg',
                NId: '11600854',
                label: 'Brake Rotor'
              },
              {
                seoUrl: '/brakes-and-traction-control/brake-caliper-front',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490293_prd-Brake-Caliper-Front.jpg',
                NId: '11600852',
                label: 'Brake Caliper - Front'
              }
            ],
            13199999: [
              {
                seoUrl: '/external-engine/spark-plug',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490104_prd-Spark-Plug.jpg',
                NId: '110300033',
                label: 'Spark Plug'
              },
              {
                seoUrl: '/external-engine/oil-filter',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490263_prd-Oil-Filter.jpg',
                NId: '110800000',
                label: 'Oil Filter'
              },
              {
                seoUrl: '/external-engine/alternator',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490247_prd-Alternator.jpg',
                NId: '10600086',
                label: 'Alternator'
              }
            ],
            14299999: [
              {
                seoUrl: '/cooling-heating-and-climate-control/water-pump',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490268_prd-Water-Pump.jpg',
                NId: '14400095',
                label: 'Water Pump'
              },
              {
                seoUrl: '/cooling-heating-and-climate-control/belt',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl: '/images/MEDIA_ProductCatalog/m3490269_prd-Belt.jpg',
                NId: '132700077',
                label: 'Belt'
              },
              {
                seoUrl: '/cooling-heating-and-climate-control/radiator',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490290_prd-Radiator.jpg',
                NId: '14400172',
                label: 'Radiator'
              }
            ],
            114199999: [
              {
                seoUrl: '/filters-and-pcv/oil-filter',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490263_prd-Oil-Filter.jpg',
                NId: '110800000',
                label: 'Oil Filter'
              },
              {
                seoUrl: '/filters-and-pcv/air-filter',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m6740026_prod-Air_Filter.jpg',
                NId: '110500001',
                label: 'Air Filter'
              },
              {
                seoUrl: '/filters-and-pcv/cabin-air-filter',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490338_prd-Cabin-Air-Filter.jpg',
                NId: '114100647',
                label: 'Cabin Air Filter'
              }
            ],
            115699999: [
              {
                seoUrl: '/fuel-delivery/fuel-pump',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490261_prd-Fuel-Pump.jpg',
                NId: '110200078',
                label: 'Fuel Pump'
              },
              {
                seoUrl: '/fuel-delivery/fuel-filter',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490306_prd-Fuel-Filter.jpg',
                NId: '114700540',
                label: 'Fuel Filter'
              },
              {
                seoUrl: '/fuel-delivery/fuel-cap',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490521_prd-Fuel-Cap.jpg',
                NId: '115900145',
                label: 'Fuel Cap'
              }
            ],
            130999999: [
              {
                seoUrl: '/gaskets/valve-cover-gasket',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  'https://contentinfo.autozone.com/znetcs/product-info/en/US/drm/615-204/image/2/',
                NId: '111400524',
                label: 'Valve Cover Gasket'
              },
              {
                seoUrl: '/gaskets/head-gasket-set',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490424_prd-Head-Gasket-Set.jpg',
                NId: '131500528',
                label: 'Head Gasket Set'
              },
              {
                seoUrl: '/gaskets/intake-manifold-gasket',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490461_prd-Intake-Manifold-Gasket.jpg',
                NId: '110600526',
                label: 'Intake Manifold Gasket'
              }
            ],
            132499999: [
              {
                seoUrl:
                  '/ignition-tune-up-and-routine-maintenance/wiper-blade-windshield',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  'https://contentinfo.autozone.com/znetcs/product-info/en/US/owi/DLM-17/image/2/',
                NId: '134000129',
                label: 'Wiper Blade (Windshield)'
              },
              {
                seoUrl: '/ignition-tune-up-and-routine-maintenance/batterybt',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490236_prd-Battery.jpg',
                NId: '10200175',
                label: 'Battery_BT'
              },
              {
                seoUrl: '/ignition-tune-up-and-routine-maintenance/spark-plug',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490104_prd-Spark-Plug.jpg',
                NId: '110300033',
                label: 'Spark Plug'
              }
            ],
            139299999: [
              {
                seoUrl: '/interior/ignition-lock-cylinder',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490260_prd-Ignition-Lock-Cylinder.jpg',
                NId: '192200190',
                label: 'Ignition Lock Cylinder'
              },
              {
                seoUrl: '/interior/seat-cover',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490516_prd-Seat-Cover-Custom-Front.jpg',
                NId: '140000679',
                label: 'Seat Cover'
              },
              {
                seoUrl: '/interior/door-handle-interior',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490537_prd-Door-Handle-Interior.jpg',
                NId: '139601851',
                label: 'Door Handle - Interior'
              }
            ],
            140999999: [
              {
                seoUrl: '/internal-engine/valve-cover-gasket',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  'https://contentinfo.autozone.com/znetcs/product-info/en/US/drm/615-204/image/2/',
                NId: '111400524',
                label: 'Valve Cover Gasket'
              },
              {
                seoUrl: '/internal-engine/head-gasket-set',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490424_prd-Head-Gasket-Set.jpg',
                NId: '131500528',
                label: 'Head Gasket Set'
              },
              {
                seoUrl: '/internal-engine/oil-pan-gasket',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490583_prd-Oil-Pan-Gasket.jpg',
                NId: '110800529',
                label: 'Oil Pan Gasket'
              }
            ],
            147899999: [
              {
                seoUrl: '/powertrain/engine',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490501_prd-Engine.jpg',
                NId: '147800694',
                label: 'Engine'
              },
              {
                seoUrl: '/powertrain/automatic-transmission',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490345_prd-Automatic-Transmission.jpg',
                NId: '148000410',
                label: 'Automatic Transmission'
              },
              {
                seoUrl: '/powertrain/u-joint',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490637_prd-U-Joint.jpg',
                NId: '148300178',
                label: 'U-Joint'
              }
            ],
            148599999: [
              {
                seoUrl: '/suspension-steering-tire-and-wheel/shock-strut-front',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  'https://contentinfo.autozone.com/znetcs/product-info/en/US/aub/43107/image/2/',
                NId: '149600660',
                label: 'Shock/Strut - Front'
              },
              {
                seoUrl: '/suspension-steering-tire-and-wheel/shock-strut-rear',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  'https://contentinfo.autozone.com/znetcs/product-info/en/US/aub/G44766/image/2/',
                NId: '149600661',
                label: 'Shock/Strut - Rear'
              },
              {
                seoUrl:
                  '/suspension-steering-tire-and-wheel/wheel-bearing-hub-assembly-frnt',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m6480001_prod-Wheel_Bearing_Hub_Assembly_Front.jpg',
                NId: '150303237',
                label: 'Wheel Bearing/Hub Assembly-Frnt'
              }
            ],
            182699999: [
              {
                seoUrl: '/emission-control-and-exhaust/oxygen-sensor',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490270_prd-Oxygen-Sensor.jpg',
                NId: '11600117',
                label: 'Oxygen Sensor'
              },
              {
                seoUrl: '/emission-control-and-exhaust/muffler',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490349_prd-Muffler.jpg',
                NId: '182800441',
                label: 'Muffler'
              },
              {
                seoUrl: '/emission-control-and-exhaust/catalytic-converter',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490314_prd-Catalytic-Converter.jpg',
                NId: '182800071',
                label: 'Catalytic Converter'
              }
            ],
            193399999: [
              {
                seoUrl: '/parts/electrical-and-lighting/headlight',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490267_prd-Headlight.jpg',
                NId: '192000044',
                label: 'Headlight'
              },
              {
                seoUrl: '/electrical-and-lighting/door-lock-actuator',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490454_prd-Door-Lock-Actuator.jpg',
                NId: '193400658',
                label: 'Door Lock Actuator'
              },
              {
                seoUrl: '/electrical-and-lighting/ignition-lock-cylinder',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490260_prd-Ignition-Lock-Cylinder.jpg',
                NId: '192200190',
                label: 'Ignition Lock Cylinder'
              }
            ],
            196099999: [
              {
                seoUrl: '/collision-body-parts-and-hardware/headlight',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490267_prd-Headlight.jpg',
                NId: '192000044',
                label: 'Headlight'
              },
              {
                seoUrl: '/collision-body-parts-and-hardware/door-lock-actuator',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490454_prd-Door-Lock-Actuator.jpg',
                NId: '193400658',
                label: 'Door Lock Actuator'
              },
              {
                seoUrl: '/collision-body-parts-and-hardware/motor-mount',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490375_prd-Motor-Mount.jpg',
                NId: '13100154',
                label: 'Motor Mount'
              }
            ],
            196199999: [
              {
                seoUrl: '/drivetrain/cv-axle',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490317_prd-CV-Axle.jpg',
                NId: '196700512',
                label: 'CV Axle'
              },
              {
                seoUrl: '/drivetrain/transmission-filter-a-t',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490379_prd-Transmission-Filter-A-T.jpg',
                NId: '114100543',
                label: 'Transmission Filter (A/T)'
              },
              {
                seoUrl: '/drivetrain/clutch-set',
                '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
                imageUrl:
                  '/images/MEDIA_ProductCatalog/m3490495_prd-Clutch-Set.jpg',
                NId: '196600179',
                label: 'Clutch Set'
              }
            ]
          }
        },
        description:
          "Don't let today,s small noise become tomorrow's big headache. Fix that noisy brake, loud engine or cranky starter, and you could save yourself a bunch of money down the road. Whether you're dealing with a big problem or a small one, AutoZone's specific auto parts selection has what you need to get back on the road.Don't let today,s small noise become tomorrow's big headache. Fix that noisy brake, loud engine or cranky starter, and you could save yourself a bunch of money down the road. Whether you're dealing with a big problem or a small one, AutoZone's specific auto parts selection has what you need to get back on the road.Don't let today,s small noise become tomorrow's big headache. Fix that noisy brake, loud engine or cranky starter, and you could save yourself a bunch of money down the road. Whether you're dealing with a big problem or a small one, AutoZone's specific auto parts selection has what you need to get back on the road.Don't let today,s small noise become tomorrow's big headache. Fix that noisy brake, loud engine or cranky starter, and you could save yourself a bunch of money down the road. Whether you're dealing with a big problem or a small one, AutoZone's specific auto parts selection has what you need to get back on the road.Don't let today,s small noise become tomorrow's big headache. Fix that noisy brake, loud engine or cranky starter, and you could save yourself a bunch of money down the road. Whether you're dealing with a big problem or a small one, AutoZone's specific auto parts selection has what you need to get back on the road.Don't let today,s small noise become tomorrow's big headache. Fix that noisy brake, loud engine or cranky starter, and you could save yourself a bunch of money down the road. Whether you're dealing with a big problem or a small one, AutoZone's specific auto parts selection has what you need to get back on the road.Don't let today,s small noise become tomorrow's big headache. Fix that noisy brake, loud engine or cranky starter, and you could save yourself a bunch of money down the road. Whether you're dealing with a big problem or a small one, AutoZone's specific auto parts selection has what you need to get back on the road.Don't let today,s small noise become tomorrow's big headache. Fix that noisy brake, loud engine or cranky starter, and you could save yourself a bunch of money down the road. Whether you're dealing with a big problem or a small one, AutoZone's specific auto parts selection has what you need to get back on the road.Don't let today,s small noise become tomorrow's big headache. Fix that noisy brake, loud engine or cranky starter, and you could save yourself a bunch of money down the road. Whether you're dealing with a big problem or a small one, AutoZone's specific auto parts selection has what you need to get back on the road.Don't let today,s small noise become tomorrow's big headache. Fix that noisy brake, loud engine or cranky starter, and you could save yourself a bunch of money down the road. Whether you're dealing with a big problem or a small one, AutoZone's specific auto parts selection has what you need to get back on the road.Don't let today,s small noise become tomorrow's big headache. Fix that noisy brake, loud engine or cranky starter, and you could save yourself a bunch of money down the road. Whether you're dealing with a big problem or a small one, AutoZone's specific auto parts selection has what you need to get back on the road.Don't let today,s small noise become tomorrow's big headache. Fix that noisy brake, loud engine or cranky starter, and you could save yourself a bunch of money down the road. Whether you're dealing with a big problem or a small one, AutoZone's specific auto parts selection has what you need to get back on the road.",
        childCategories: [
          {
            seoUrl: '/parts/batteries-starting-and-chargingbsc',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl:
              '/images/MEDIA_ProductCatalog/m3880002_cat_batteries-starting-and-charging.jpg',
            NId: '62mdb',
            label: 'Batteries, Starting And Charging_BSC'
          },
          {
            seoUrl: '/parts/brakes-and-traction-control',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl:
              '/images/MEDIA_ProductCatalog/m3490090_cat-brakes-and-traction.jpg',
            NId: '6uhgf',
            label: 'Brakes And Traction Control'
          },
          {
            seoUrl: '/parts/collision-body-parts-and-hardware',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl:
              '/images/MEDIA_ProductCatalog/m3490041_cat-collision-body-parts.jpg',
            NId: '38r3q7',
            label: 'Collision, Body Parts And Hardware'
          },
          {
            seoUrl: '/parts/cooling-heating-and-climate-control',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl:
              '/images/MEDIA_ProductCatalog/m3490038_cat-cooling-heating-and-climate.jpg',
            NId: '8ihy7',
            label: 'Cooling, Heating And Climate Control'
          },
          {
            seoUrl: '/parts/drivetrain',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl:
              '/images/MEDIA_ProductCatalog/m3490043_cat-drivetrain.jpg',
            NId: '38t8vz',
            label: 'Drivetrain'
          },
          {
            seoUrl: '/parts/electrical-and-lighting',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl:
              '/images/MEDIA_ProductCatalog/m3490044_cat-electrical-and-lighting.jpg',
            NId: '3758e7',
            label: 'Electrical And Lighting'
          },
          {
            seoUrl: '/parts/emission-control-and-exhaust',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl:
              '/images/MEDIA_ProductCatalog/m3490045_cat-emission-control-and-exhaust.jpg',
            NId: '30rw7z',
            label: 'Emission Control And Exhaust'
          },
          {
            seoUrl: '/parts/engine-management',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl:
              '/images/MEDIA_ProductCatalog/m3490051_cat-engine-management.jpg',
            NId: '6o1z3',
            label: 'Engine Management'
          },
          {
            seoUrl: '/parts/external-engine',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl:
              '/images/MEDIA_ProductCatalog/m3490055_cat-external-engine.jpg',
            NId: '7ux6n',
            label: 'External Engine'
          },
          {
            seoUrl: '/parts/filters-and-pcv',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl:
              '/images/MEDIA_ProductCatalog/m3490056_cat-filters-and-pcv.jpg',
            NId: '1vzpa7',
            label: 'Filters And PCV'
          },
          {
            seoUrl: '/parts/fuel-delivery',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl:
              '/images/MEDIA_ProductCatalog/m3490057_cat-fuel-delivery.jpg',
            NId: '1wvuov',
            label: 'Fuel Delivery'
          },
          {
            seoUrl: '/parts/gaskets',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl: '/images/MEDIA_ProductCatalog/m3510027_cat-gaskets.jpg',
            NId: '25zs8v',
            label: 'Gaskets'
          },
          {
            seoUrl: '/parts/ignition-tune-up-and-routine-maintenance',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl:
              '/images/MEDIA_ProductCatalog/m3490059_cat-ignition-tuneup.jpg',
            NId: '26vxnj',
            label: 'Ignition, Tune Up And Routine Maintenance'
          },
          {
            seoUrl: '/parts/interior',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl: '/images/MEDIA_ProductCatalog/m3490074_cat-interior.jpg',
            NId: '2axokf',
            label: 'Interior'
          },
          {
            seoUrl: '/parts/internal-engine',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl:
              '/images/MEDIA_ProductCatalog/m3490063_cat-internal-engine.jpg',
            NId: '2by4an',
            label: 'Internal Engine'
          },
          {
            seoUrl: '/parts/powertrain',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl:
              '/images/MEDIA_ProductCatalog/m3490068_cat-powertrain.jpg',
            NId: '2g20db',
            label: 'Powertrain'
          },
          {
            seoUrl: '/parts/suspension-steering-tire-and-wheel',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl:
              '/images/MEDIA_ProductCatalog/m3490073_cat-suspension-steering-tire-and-wheel.jpg',
            NId: '2gh0hr',
            label: 'Suspension, Steering, Tire And Wheel'
          },
          {
            seoUrl: '/truck-and-towing',
            '@class': 'com.endeca.infront.cartridge.AZRefinementVO',
            imageUrl: '/autozone/tpl/prodimg.jpg',
            NId: '2i50zj',
            label: 'Truck And Towing'
          }
        ],
        HeroImage: {
          CTALink1:
            'https://www.autozone.com/ignition-tune-up-and-routine-maintenance/battery',
          Headline1: '$20 Gift Card Through',
          CTAName1: 'View Details',
          CTAName2: 'See Details',
          BackGroundImage:
            '/images/MEDIA_ProductCatalog/DarkTextureExample.jpeg',
          CTALink2:
            'https://www.autozone.com/landing/page.jsp?name=duralast-battery',
          mobile: 'true',
          desktop: 'true'
        }
      }
    }
  };
  let ConnectedCategory;
  let mapStateToProps;
  let mapDispatchToProps;

  beforeEach(() => {
    mapStateToProps = state => ({
      data: state.category,
      location: { pathname: 'xyz' }
    });
    mapDispatchToProps = () => ({ fetchCategoryData: jest.fn() });
    ConnectedCategory = connect(mapStateToProps, mapDispatchToProps)(Category);
  });

  test('renders correctly', () => {
    const fakeStore = createStore(() => initialState);
    const wrapper = mount(
      <Provider store={fakeStore}>
        <ConnectedCategory />
      </Provider>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders Loading for ongoing request', () => {
    initialState.category.readyStatus = 'CATEGORY_REQUESTING';
    const fakeStore = createStore(() => initialState);
    const wrapper = mount(
      <Provider store={fakeStore}>
        <ConnectedCategory />
      </Provider>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders error page for failed request', () => {
    initialState.category.readyStatus = 'CATEGORY_FAILURE';
    const fakeStore = createStore(() => initialState);
    const wrapper = mount(
      <Provider store={fakeStore}>
        <ConnectedCategory />
      </Provider>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });
});
