/* @flow */

import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import type { Connector } from 'react-redux';
import { withRouter } from 'react-router-dom';
import Header from '../Header';
import ProductBreadcrumbs from '../../components/ProductDetailComp/ProductBreadcrumbs';
import ShelfHeading from '../../components/Heading-filter';
import DropDownSort from '../../components/SortFilter';
import FilterSideBar from '../../components/Filter';
import FilterMobile from '../../components/FilterMobile';
import PencilAd from '../../components/PencilADBlock';
import PaginationExamplePagination from '../../components/Pagination';
import ProductPart from '../ProductPart';
import styles from './styles.scss';
import type { Dispatch, ReduxState } from '../../types';
import * as shelfAction from '../../actions/shelf';
import * as BazaarVoice from '../../components/ThirdPartyApis/BazaarVoiceAPI';

type Props = {
  location: Object,
  getPartDetails: string => void,
  history: any,
  parts: Object,
  isList: boolean,
  skuIds: Array<number>
};

type State = {
  filterquery: any,
  min: number,
  max: number
};

export class ProductShelf extends PureComponent<Props, State> {
  constructor(props) {
    super(props);
    this.state = {
      filterquery: '',
      min: 0,
      max: 0
    };
  }

  componentDidMount() {
    const { pathname } = this.props.location;
    const newPath = pathname.replace('/shelfPage', '');
    this.props.getPartDetails(newPath);
  }

  componentWillReceiveProps(newProps) {
    if (this.props.location.search !== newProps.location.search) {
      const filterBy = newProps.location.search;
      const FilterData = filterBy.replace('?', '&');
      const { pathname } = this.props.location;
      const newPath = pathname.replace('/shelfPage', '');
      this.props.getPartDetails(`${newPath}${FilterData}`);
    }
  }

  componentWillUpdate() {
    BazaarVoice.loadBazaarVoiceRatingShelfPage();
  }

  componentDidUpdate() {
    const { skuIds } = this.props;
    /* istanbul ignore next */
    window.loadBazaarvoiceApi(() => {
      window.$BV.ui('rr', 'inline_ratings', {
        productIds: skuIds.map(String),
        containerPrefix: `BVRRInlineRating`
      });
    });
  }

  handleFilter(seoUrl: string) {
    const { pathname } = this.props.location;
    const { history: { push } } = this.props;
    let num = '';
    if (seoUrl) {
      const p = seoUrl.indexOf('?');
      num = seoUrl.substring(p + '?filters='.length);
      this.setState({
        filterquery: num
      });
    } else {
      this.setState({
        filterquery: ''
      });
    }

    push({ pathname: `${pathname}`, search: `filters=${num}` });
  }

  renderPagination() {
    const { parts } = this.props;
    const shelfPart = parts.azshelfPageRecordsVO;
    if (shelfPart && shelfPart.totalNumrecords > 12) {
      return (
        <PaginationExamplePagination
          num={this.state.filterquery}
          perPage={shelfPart.recsPerPage}
          pageData={shelfPart.totalNumrecords}
        />
      );
    }
    return '';
  }

  render() {
    const { isList, parts } = this.props;
    const col = isList ? 12 : 4;
    const shelfPart = parts.azshelfPageRecordsVO;
    const filterData = parts.refinementMenuVO;
    const skuIds = [];
    if (shelfPart && shelfPart.recordsList) {
      shelfPart.recordsList.map(item => skuIds.push(item.skuNumber));
    }
    return (
      <div>
        <Header />
        {shelfPart &&
          shelfPart.recordsList && (
            <div className={styles.productShelf}>
              <ProductBreadcrumbs
                data={
                  parts.breadCrumbsVO && parts.breadCrumbsVO.listOfBreadCrumb
                }
              />
              <div className={styles.desktopOnly}>
                <div className={styles.cols6}>
                  <ShelfHeading
                    min={this.state.min}
                    max={this.state.max}
                    data={shelfPart}
                  />
                </div>
                <div className={styles.cols6}>
                  <DropDownSort />
                </div>
                <div className={styles.clearfix} />
                <div className={styles.cols20}>
                  <FilterSideBar
                    handleFilter={seoUrl => this.handleFilter(seoUrl)}
                    filterData={filterData}
                  />
                </div>
              </div>
              <div className={styles.mobileFilter}>
                <FilterMobile
                  handleFilter={seoUrl => this.handleFilter(seoUrl)}
                  min={this.state.min}
                  max={this.state.max}
                  data={shelfPart}
                  filterData={filterData}
                />
              </div>
              <div className={`${styles.cols80}`}>
                <span className={styles.desktopOnly}>
                  <PencilAd className={styles.mb20} />
                </span>
                <div className="row">
                  {shelfPart &&
                    shelfPart.recordsList &&
                    shelfPart.recordsList.map(item => (
                      <div
                        key={item.partNumber}
                        className={`col s12 xl${col} ${styles.pad0}`}
                      >
                        <ProductPart shelfPart={item} skuIds={skuIds} />
                      </div>
                    ))}
                </div>
                {this.renderPagination()}
              </div>
            </div>
          )}{' '}
        : {<div>Loading...</div>}
      </div>
    );
  }
}

/* istanbul ignore next */
const connector: Connector<{}> = connect(
  ({ shelf }: ReduxState) => ({
    isList: shelf.isList,
    parts: shelf.parts,
    skuIds: shelf.skuIds,
    shelf,
    readyStatus: shelf.readyStatus
  }),
  (dispatch: Dispatch) => ({
    getPartDetails: newPath => dispatch(shelfAction.getPartDetails(newPath))
  })
);

export default withRouter(connector(ProductShelf));
