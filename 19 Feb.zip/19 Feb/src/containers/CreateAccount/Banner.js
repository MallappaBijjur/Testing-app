/* @flow */
import React, { PureComponent } from 'react';
import * as styles from './styles.scss';

type Props = {
  data: Object
};

export default class Banner extends PureComponent<Props> {
  render() {
    // console.log('Banner props data', this.props.data);
    const { data } = this.props;
    return (
      <div className={styles.regBannerWrapper}>
        <h2 className={styles.regBannerHeading}>
          {data.mf_registration_myZoneAcc_msg}
        </h2>
        <div className={styles.regBannerInfos}>
          <div className={styles.regBannerInfo}>
            <span>
              <img
                className={styles.regDollarImg}
                src="/images/regDollar.png"
                alt="Logo"
                role="presentation"
              />
            </span>
            <div className={styles.regMargin}>
              {data.mf_registration_myZoneAcc_benefit_msg_1}
            </div>
          </div>
          <div className={styles.regBannerInfo}>
            <span>
              <img
                className={styles.regBasketImg}
                src="/images/regBasket.png"
                alt="Logo"
                role="presentation"
              />
            </span>
            <div className={styles.regMargin}>
              {data.mf_registration_myZoneAcc_benefit_msg_2}
            </div>
          </div>
          <div className={styles.regBannerInfo}>
            <span>
              <img
                className={styles.regNoteImg}
                src="/images/regNote.png"
                alt="Logo"
                role="presentation"
              />
            </span>
            <div className={styles.regMargin}>
              {data.mf_registration_myZoneAcc_benefit_msg_3}
            </div>
          </div>
        </div>
      </div>
    );
  }
}
