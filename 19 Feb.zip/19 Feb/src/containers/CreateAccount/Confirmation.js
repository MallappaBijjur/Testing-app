// @flow
import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import lightBaseTheme from 'material-ui/styles/baseThemes/lightBaseTheme';
import RaisedButton from 'material-ui/RaisedButton';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import styles from './styles.scss';

type Props = {
  successValues: Object
};

class Confirmation extends PureComponent<Props> {
  render() {
    const { successValues } = this.props;
    return (
      <div className={styles.confirmationContainer}>
        <div className={styles.AccountConfirmationPage}>
          <div className="row">
            <div className="col">
              <div style={{ paddingTop: '20px' }}>
                <img
                  src="/images/logo-mobile.png"
                  alt="Logo"
                  role="presentation"
                  width="200px"
                  height="70px"
                  className="show-on-small hide-on-med-and-up"
                />
                <img
                  src="/images/Autozonelogo.png"
                  alt="Logo"
                  role="presentation"
                  width="238px"
                  height="43px"
                  className="hide-on-small-only"
                />
              </div>
              <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                <div>
                  <h2>{successValues.mf_regConfirmation_welcome}</h2>
                  <div
                    style={{ paddingBottom: '10px', maxWidth: '350px' }}
                    className="s12 show-on-small hide-on-med-and-up"
                  >
                    <img
                      src="/images/autoZoneRewards.png"
                      alt="Logo"
                      role="presentation"
                      width="100%"
                    />
                  </div>
                  <div
                    className={styles.fontNormal}
                    style={{
                      marginBottom: '25px'
                    }}
                  >
                    {successValues.mf_regConfirmation_registered}
                  </div>
                  <div className={styles.subRewardSignIn}>
                    {successValues.mf_regconfirmation_signin_msg}
                  </div>
                  <div className={styles.subRegEmail}>
                    <div>{successValues.mf_regconfirmation_email}</div>
                    <span className={styles.fontNormal}>
                      {successValues.login}
                    </span>
                  </div>
                  <div className={styles.subRegReward}>
                    <div> {successValues.mf_regconfirmation_rewards_id} </div>
                    <span className={styles.fontNormal}>
                      {successValues.rewardsId}
                    </span>
                  </div>
                  <div className="row">
                    <div
                      className="col s12 m6 l6 xl6"
                      style={{ 'padding-left': '0', float: 'right' }}
                    >
                      <RaisedButton
                        label={successValues.mf_regConfirmation_completeBtn}
                        className={styles.subCompleteProfile}
                      />
                    </div>
                    <div
                      className="col s12 m6 l6 xl6"
                      style={{ 'padding-left': '0' }}
                    >
                      <RaisedButton
                        label={successValues.mf_regconfirmation_shop_for_parts}
                        className={styles.confirmationShopping}
                      />
                    </div>
                  </div>
                </div>
              </MuiThemeProvider>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export { Confirmation };
/* istanbul ignore next */
const connectedConfirmation = connect(state => ({
  successValues: state.formInfo.successValues
}))(Confirmation);

export default connectedConfirmation;
