// @flow
import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';

import { Confirmation } from '../Confirmation';

describe('<Confirmation />', () => {
  let mockData = null;
  let PROPS = {};
  beforeEach(() => {
    mockData = {
      mf_regConfirmation_welcome: 'test',
      mf_regConfirmation_registered: 'test',
      mf_regconfirmation_signin_msg: 'test',
      mf_regconfirmation_email: 'test',
      login: 'test',
      mf_regconfirmation_rewards_id: 'test',
      rewardsId: 'test',
      mf_regConfirmation_completeBtn: 'test',
      mf_regconfirmation_shop_for_parts: 'test'
    };
    PROPS = {
      successValues: mockData
    };
  });

  test('renders correctly', () => {
    const wrapper = shallow(<Confirmation {...PROPS} />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });
});
