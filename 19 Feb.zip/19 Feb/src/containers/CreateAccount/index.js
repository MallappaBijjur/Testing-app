// @flow
import React, { PureComponent } from 'react';
import type { Element } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import type { Connector } from 'react-redux';
import type {
  CreateAccountData as CreateAccountDataType,
  Dispatch,
  ReduxState
} from '../../types';
import CreateForm from '../../components/CreateForm';
import * as styles from './styles.scss';
import * as createAccount from '../../actions/createAccount';
import * as submitForm from '../../actions/submitForm';
import Banner from './Banner';

type Props = {
  createAccountData: CreateAccountDataType,
  fetchCreateAccountData: () => void,
  submitFormAction: Object => void,
  successValues: Object
};

// Export this for unit testing more easily
export class CreateAccount extends PureComponent<Props> {
  componentDidMount() {
    this.props.fetchCreateAccountData();
  }

  handleSubmit = (formInfo: Object) => {
    const formValues = {
      login: `${formInfo.email}`,
      password: `${formInfo.password}`,
      email: `${formInfo.email}`,
      firstName: `${formInfo.firstName}`,
      lastName: `${formInfo.lastName}`,
      addresses: [
        {
          items: {
            type: 'homeAddress',
            postalCode: `${formInfo.postalCode}`,
            phoneNumber: `${formInfo.phoneNumber}`
          }
        }
      ],
      otherOptions: {
        mobileApp: 'true',
        activeSubscriptionsAsCSV: 'receivePromoAndSpecialEvents'
      }
    };
    this.props.submitFormAction(formValues);
  };

  renderCreateForm = (): Element<'p' | typeof CreateForm> => {
    const { createAccountData, successValues } = this.props;

    if (successValues && successValues.readyStatus === 'SUBMIT_FAILURE') {
      return (
        <div>
          <p className={styles.errorMsg}>{successValues.err.title}</p>
          <CreateForm
            data={createAccountData.viewInfo}
            onSubmit={this.handleSubmit}
          />
        </div>
      );
    }

    return (
      <div>
        {createAccountData &&
          createAccountData.readyStatus === 'CREATE_SUCCESS' && (
            <CreateForm
              data={createAccountData.viewInfo}
              onSubmit={this.handleSubmit}
            />
          )}
        {createAccountData.readyStatus === 'CREATE_FAILURE' && (
          <div>Oops..Page Not Found</div>
        )}
      </div>
    );
  };

  render() {
    const { createAccountData } = this.props;
    if (createAccountData.readyStatus === 'CREATE_FAILURE') {
      return <div>Oops..Page Not Found</div>;
    }
    if (createAccountData.readyStatus !== 'CREATE_SUCCESS') {
      return <div>Loading..</div>;
    }
    return (
      <div className={styles.regMainContainer}>
        <div className={styles.registerationPage}>
          <div className="row">
            <div className="col s12 m12 l5 xl5">
              <div className={styles.regLeftSection}>
                <Link to="/">
                  <img
                    style={{
                      display: 'block',
                      position: 'relative',
                      left: '-60px'
                    }}
                    src="/images/backBtn.png"
                    alt="Logo"
                    role="presentation"
                    width="90px"
                    height="58px"
                  />
                </Link>
                <div style={{ paddingTop: '20px' }}>
                  <img
                    src="/images/logo-mobile.png"
                    alt="Logo"
                    role="presentation"
                    width="200px"
                    height="70px"
                    className="show-on-small hide-on-med-and-up"
                  />
                  <img
                    src="/images/Autozonelogo.png"
                    alt="Logo"
                    role="presentation"
                    width="238px"
                    height="43px"
                    className="hide-on-small-only"
                  />
                </div>
                <h1
                  style={{ paddingBottom: '10px' }}
                  className="show-on-small hide-on-med-and-up"
                >
                  {createAccountData.viewInfo.mf_registration_welcome_lbl}
                </h1>
                <h1
                  style={{ paddingBottom: '10px' }}
                  className="hide-on-small-only"
                >
                  {createAccountData.viewInfo.mf_registration_createAccount}
                </h1>
                <div>{this.renderCreateForm()}</div>
              </div>
            </div>
            <div className="col l7 xl7 hide-on-med-and-down hide-on-small-only">
              <div className={styles.regRightGrid}>
                <Banner data={createAccountData.viewInfo} />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
/* istanbul ignore next */
const connector: Connector<{}, Props> = connect(
  (state: ReduxState) => ({
    createAccountData: state.createAccountData,
    successValues: state.formInfo
  }),
  (dispatch: Dispatch) => ({
    fetchCreateAccountData: () =>
      dispatch(createAccount.fetchCreateAccountData()),
    submitFormAction: values => dispatch(submitForm.submitFormAction(values))
  })
);

export default connector(CreateAccount);
