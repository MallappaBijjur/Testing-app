/* @flow */
import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import type { Connector } from 'react-redux';
import Header from '../Header';
import * as ProductDetails from '../../actions/productDetails';
import type {
  ProductData as ProductDataType,
  Dispatch,
  ReduxState
} from '../../types';
import ProductFrequent from '../../components/ProductDetailComp/ProductDetailFrequent';
import ProductAvailability from '../../components/ProductDetailComp/ProductAvailabilityInfo';
import ProductSpec from '../../components/ProductDetailComp/ProductDetailSpecification';
import ProductRecommendation from '../../components/ProductDetailComp/ProductRecommendation';
import ProductCustomersAlsoBuy from '../../components/ProductDetailComp/ProductCustomersAlsoBuy';
import ProductBreadcrumbs from '../../components/ProductDetailComp/ProductBreadcrumbs';

type Props = {
  productData: ProductDataType,
  fetchProductAllData: (vsearch: any) => void,
  location: Object
};

// Export this for unit testing more easily
export class ProductDetail extends PureComponent<Props> {
  componentDidMount() {
    window.scrollTo(0, 0);
    this.props.fetchProductAllData(this.props.location.search);
  }
  renderProdMain = () => {
    const { productData } = this.props;

    const { catalogRefId } = this.props.productData.viewInfo.azPdpAddToCartVO;
    console.log('productData VIdeo', catalogRefId);
    return (
      <div className="row">
        {productData &&
          productData.readyStatus === 'PRODUCT_SUCCESS' && (
            <div>
              <ProductSpec data={productData.viewInfo} />
              <div id="tab-reviews">
                <div
                  data-bv-show="reviews"
                  data-bv-productid={
                    this.props.productData.viewInfo.azPdpAddToCartVO
                      .catalogRefId
                  }
                />
              </div>
              <video width="100%" poster="/images/video.png">
                <source src="/images/autozone_video.mp4" type="video/mp4" />
                <track kind="captions" />
                Your browser does not support the video tag
              </video>
              <ProductRecommendation />
            </div>
          )}
      </div>
    );
  };
  renderProdAvail = () => {
    const { productData } = this.props;
    return (
      <div className="row">
        {productData.readyStatus === 'PRODUCT_SUCCESS' && (
          <div>
            <ProductBreadcrumbs
              data={productData.viewInfo && productData.viewInfo.breadCrumbList}
            />
            <ProductAvailability data={productData} />
          </div>
        )}
      </div>
    );
  };
  render() {
    const { productData } = this.props;
    if (productData.readyStatus !== 'PRODUCT_SUCCESS') {
      return <div>Loading...</div>;
    }

    return (
      <div>
        <Header />
        <div className="col m12 s12">
          <div className="row">{this.renderProdAvail()}</div>
          <div className="row">
            <ProductFrequent />
          </div>
          <div className="row">
            <ProductCustomersAlsoBuy />
          </div>
          {this.renderProdMain()}
        </div>
      </div>
    );
  }
}

const connector: Connector<{}, Props> = connect(
  ({ productData }: ReduxState) => ({
    productData
  }),
  (dispatch: Dispatch) => ({
    fetchProductAllData: search =>
      dispatch(ProductDetails.fetchProductAllData(search))
  })
);
export default connector(ProductDetail);
