/* @flow */
const menuNavigation = {
  menuNavigationLeft: [
    {
      id: 'autoParts',
      name: 'AUTO PARTS',
      link: '#'
    },
    {
      id: 'Accessories',
      name: 'ACCESSORIES',
      link: '#'
    },
    {
      id: 'Tools',
      name: 'TOOLS',
      link: '#'
    },
    {
      id: 'OilandFluids',
      name: 'OIL & FLUIDS',
      link: '#'
    },
    {
      id: 'Performance',
      name: 'PERFORMANCE',
      link: '#'
    },
    {
      id: 'Featured',
      name: 'FEATURED',
      link: '#'
    }
  ],

  menuNavigationRight: [
    {
      id: 'Repairhelp',
      name: 'Repair Help',
      link: '#'
    },
    {
      id: 'Deals',
      name: 'Deals',
      link: '#'
    }
  ]
};

export default menuNavigation;
