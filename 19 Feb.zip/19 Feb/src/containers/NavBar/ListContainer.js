/* @flow */
import React, { PureComponent } from 'react';
import type { Node } from 'react';
import { Link } from 'react-router-dom';
import styles from './styles.scss';

type ItemType = {
  seoUrl: string,
  NId: string,
  label: string
};

type Props = {
  onMouseOverMenu: (string, string, number) => void,
  content: Array<ItemType>,
  currentLevel: number,
  seeMore: boolean,
  children: Node
};

class ListContainer extends PureComponent<Props> {
  static defaultProps = {
    currentLevel: -1,
    onMouseOverMenu: () => {},
    content: [],
    seeMore: false,
    children: []
  };

  render() {
    const { content } = this.props;
    return (
      <div>
        {this.props.children}
        {content && (
          <div className={`col s12 ${styles.top}`}>
            <ul>
              {content.map((item: ItemType) => (
                <Link
                  target="_self"
                  to={`/shelfPage${item.seoUrl}`}
                  key={item.seoUrl}
                >
                  <li
                    key={item.label}
                    onFocus={() => false}
                    onMouseOver={() =>
                      this.props.onMouseOverMenu(
                        item.NId,
                        item.label,
                        this.props.currentLevel
                      )
                    }
                  >
                    {item.label}
                  </li>
                </Link>
              ))}
              <li> {this.props.seeMore ? <a href="#/">See More</a> : ''} </li>
            </ul>
          </div>
        )}
      </div>
    );
  }
}

export default ListContainer;
