/* @flow */
import React, { PureComponent } from 'react';
import PopOverMenuComponentFeatured from './PopOverMenuComponent';
import MenuSlider from './MenuSlider';

type Props = {
  open: boolean,
  anchorEl: Object,
  handleRequestClose: Function,
  menuKey: string,
  currentLevel: number,
  subCatData: Object
};

class MenuPopOver extends PureComponent<Props> {
  render() {
    const { subCatData } = this.props;
    const catContent = subCatData && subCatData.childCategories;

    return (
      <div>
        {this.props.menuKey === 'Featured' && (
          <PopOverMenuComponentFeatured
            open={this.props.open}
            anchorEl={this.props.anchorEl}
            handleRequestClose={this.props.handleRequestClose}
          />
        )}
        {this.props.menuKey !== 'Featured' && (
          <MenuSlider
            open={this.props.open}
            anchorEl={this.props.anchorEl}
            handleRequestClose={this.props.handleRequestClose}
            currentLevel={this.props.currentLevel}
            menuKey={this.props.menuKey}
            data={catContent}
          />
        )}
      </div>
    );
  }
}

export default MenuPopOver;
