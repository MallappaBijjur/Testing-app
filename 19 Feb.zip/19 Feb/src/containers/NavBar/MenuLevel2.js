// @flow
import React, { PureComponent } from 'react';
import type { Connector } from 'react-redux';
import { connect } from 'react-redux';
import ListContainer from './ListContainer';
import type { Dispatch, ReduxState } from '../../types';
import styles from './styles.scss';
import * as topNav from '../../actions/topNav';

type ItemType = {
  seoUrl: string,
  NId: string,
  label: string
};

type Props = {
  level1: Array<ItemType>,
  level2MostPop: Array<ItemType>,
  fetchLevel2: (string, string) => void,
  changeMenuState: (string, boolean) => void,
  headingL1: string
};

class MenuLevel2 extends PureComponent<Props> {
  onMouseOverMenu = (id: string, label: string) => {
    this.props.fetchLevel2(id, label);
    this.props.changeMenuState('l3', true);
    this.props.changeMenuState('p', false);
  };

  getContent = (content: Array<ItemType>): Array<ItemType> => {
    let newContent: Array<ItemType> = content;
    if (content && content.length > 5) {
      newContent = content.slice(0, 5);
    }

    return newContent;
  };
  render() {
    const { level1, level2MostPop, headingL1 } = this.props;

    return (
      <div className={`${styles.borderPart}`}>
        <ListContainer
          onMouseOverMenu={this.onMouseOverMenu}
          content={this.getContent(level1)}
          seeMore={level1.length > 5}
        >
          <div className={styles.menuHeader}>{headingL1}</div>
        </ListContainer>
        {level2MostPop &&
          level2MostPop.length > 0 && (
            <ListContainer content={level2MostPop}>
              <div className={styles.menuHeader}>
                <span className={styles.highlightLabel}>Popular</span> In This
                Category
              </div>
            </ListContainer>
          )}
      </div>
    );
  }
}

const connector: Connector<{}, Props> = connect(
  ({ topNavData }: ReduxState) => ({
    level1: topNavData.level1,
    level2MostPop: topNavData.level2MostPop,
    headingL1: topNavData.headingL1
  }),
  (dispatch: Dispatch) => ({
    fetchLevel2: (id, label) => dispatch(topNav.fetchLevel2(id, label))
  })
);

export default connector(MenuLevel2);
