/* @flow */
import React, { PureComponent } from 'react';
import FlatButton from 'material-ui/FlatButton';
import type { Connector } from 'react-redux';
import { connect } from 'react-redux';
import styles from './styles.scss';
import MenuPopOver from './MenuPopOver';
import type { Dispatch, ReduxState } from '../../types';
import * as topNav from '../../actions/topNav';

type Props = {
  styles: Object,
  fetchHomeDataCall: () => void,
  fetchSubDataCall: Object => void,
  resetTopNavData: () => void,
  homeData: Object,
  subCatData: Object
};

type State = {
  open: boolean,
  active: number,
  anchorEl: Object,
  currentLevel: number,
  menuKey: string,
  L3: boolean
};

class NavBar extends PureComponent<Props, State> {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      active: -1,
      anchorEl: {},
      currentLevel: -1,
      menuKey: '',
      L3: false
    };
  }

  componentDidMount() {
    this.props.fetchHomeDataCall();
  }

  setLevel2 = () => {
    this.setState(() => ({
      L3: !this.state.L3
    }));
  };

  handleClick(event, menu) {
    event.preventDefault();

    this.props.fetchSubDataCall(menu);
    this.setState({
      open: true,
      anchorEl: event.currentTarget,
      menuKey: menu.displayName,
      active: parseInt(event.currentTarget.id, 10)
    });
  }

  handleRequestClose = () => {
    this.props.resetTopNavData();
    this.setState({
      open: false,
      currentLevel: 1,
      active: -1
    });
  };

  render() {
    const { homeData, subCatData } = this.props;
    const headerContent =
      homeData && homeData.contents && homeData.contents[0].header;
    return (
      <div className={this.props.styles.navAutoZone}>
        <nav>
          <div>
            <ul className="left hide-on-med-and-down">
              {headerContent &&
                headerContent.navItemTOList.map((menu, index) => {
                  if (menu.rank < 9) {
                    return (
                      <li key={menu.displayName}>
                        <FlatButton
                          id={index}
                          label={menu.displayName}
                          onClick={event => this.handleClick(event, menu)}
                          className={
                            this.state.active === index
                              ? `${styles.flaButton} ${styles.activebg}`
                              : styles.flaButton
                          }
                        />
                      </li>
                    );
                  }
                  return false;
                })}
            </ul>
            <ul className="right hide-on-med-and-down">
              <li className={styles.menustyles}>
                <FlatButton className={styles.flaButton}>Deals</FlatButton>
              </li>
            </ul>
          </div>
        </nav>
        <div>
          <MenuPopOver
            open={this.state.open}
            anchorEl={this.state.anchorEl}
            handleRequestClose={this.handleRequestClose}
            currentLevel={this.state.currentLevel}
            menuKey={this.state.menuKey}
            subCatData={subCatData}
          />
        </div>
      </div>
    );
  }
}

const connector: Connector<{}, Props> = connect(
  ({ topNavData }: ReduxState) => ({
    homeData: topNavData.homeData,
    subCatData: topNavData.subCatData
  }),
  (dispatch: Dispatch) => ({
    fetchHomeDataCall: () => dispatch(topNav.fetchHomeDataCall()),
    fetchSubDataCall: menu => dispatch(topNav.fetchSubDataCall(menu)),
    firstCatGet: (id, label) => dispatch(topNav.firstCatGet(id, label)),
    fetchLevel2: (id, label) => dispatch(topNav.fetchLevel2(id, label)),
    resetTopNavData: () => dispatch(topNav.resetTopNavData())
  })
);

export default connector(NavBar);
