// @flow
import React, { PureComponent } from 'react';
import styles from './styles.scss';
import ListContainer from './ListContainer';

type ItemType = {
  seoUrl: string,
  NId: string,
  label: string
};

type Props = {
  label: string,
  content: Array<ItemType>
};

class MenuLevel3 extends PureComponent<Props> {
  render() {
    return (
      <div>
        <h1 className={styles.menuHeader}>{this.props.label}</h1>
        <ListContainer content={this.props.content} />
      </div>
    );
  }
}

export default MenuLevel3;
