/* @flow */
import React, { PureComponent } from 'react';
import type { Connector } from 'react-redux';
import { connect } from 'react-redux';
import styles from './styles.scss';
import ListContainer from './ListContainer';
import type { Dispatch, ReduxState } from '../../types';
import * as topNav from '../../actions/topNav';

type ItemType = {
  seoUrl: string,
  NId: string,
  label: string
};

type Props = {
  firstCatGet: (string, string) => void,
  changeMenuState: (string, boolean) => void,
  subCatData: Object,
  label: string,
  currentLevel: number
};

class MenuLevel1 extends PureComponent<Props> {
  onMouseOverMenu = (id, label) => {
    this.props.firstCatGet(id, label);
    this.props.changeMenuState('l2', true);
    this.props.changeMenuState('l3', false);
    this.props.changeMenuState('p', false);
  };

  onMouseMostPop = () => {
    this.props.changeMenuState('l2', false);
    this.props.changeMenuState('l3', false);
    this.props.changeMenuState('p', true);
  };

  render() {
    const { subCatData } = this.props;
    let level1Data: Array<ItemType> = [];
    if (subCatData && subCatData.childCategories) {
      if (subCatData.childCategories[0]) {
        level1Data =
          subCatData.childCategories[0]['10000000'] ||
          subCatData.childCategories[0]['100000'];
      }
    }

    return (
      <div>
        <header className={styles.menuHeader}>{this.props.label}</header>
        <svg
          className={styles.starSVG}
          xmlns="http://www.w3.org/2000/svg"
          width="10"
          height="10"
          viewBox="0 0 10 10"
        >
          <path
            fill="#787878"
            d="M9.962 3.286a.5.5 0 0 0-.462-.309H6.809L5.447.254c-.17-.339-.725-.339-.894 0L3.19 2.977H.5a.5.5 0 0 0-.354.854l2.292 2.292L1.52 9.34a.5.5 0 0 0 .758.553L5 8.078l2.722 1.815a.502.502 0 0 0 .759-.553l-.92-3.217L9.853 3.83a.5.5 0 0 0 .109-.545"
          />
        </svg>
        <span
          className={`${styles.titleSection} popular`}
          style={{ paddingTop: 10 }}
          onFocus={() => false}
          onMouseOver={() => this.onMouseMostPop()}
        >
          {`Most Popular ${this.props.label}`}{' '}
        </span>
        <ListContainer
          onMouseOverMenu={this.onMouseOverMenu}
          content={level1Data}
          currentLevel={this.props.currentLevel}
        />
      </div>
    );
  }
}

const connector: Connector<{}, Props> = connect(
  ({ topNavData }: ReduxState) => ({
    subCatData: topNavData.subCatData
  }),
  (dispatch: Dispatch) => ({
    fetchSubDataCall: () => dispatch(topNav.fetchSubDataCall()),
    firstCatGet: (id, label) => dispatch(topNav.firstCatGet(id, label)),
    fetchLevel2: (id, label) => dispatch(topNav.fetchLevel2(id, label))
  })
);

export default connector(MenuLevel1);
