/* @flow */
import React, { PureComponent } from 'react';
import Popover from 'material-ui/Popover';
import { connect, Connector } from 'react-redux';
import styles from './styles.scss';
import MenuLevel1 from './MenuLevel1';
import MenuLevel2 from './MenuLevel2';
import MenuLevel3 from './MenuLevel3';
import ListContainer from './ListContainer';

type ItemType = {
  seoUrl: string,
  NId: string,
  label: string
};

type Props = {
  open: Object,
  anchorEl: Object,
  handleRequestClose: () => void,
  currentLevel: number,
  level2Data: Array<ItemType>,
  mostPop: Object,
  menuKey: string,
  headingL2: string
};

type State = {
  l1: boolean,
  l2: boolean,
  l3: boolean,
  p: boolean
};

class MenuSlider extends PureComponent<Props, State> {
  constructor(props) {
    super(props);
    this.state = {
      l1: true,
      l2: false,
      l3: false,
      p: false
    };
  }

  componentWillReceiveProps(nextProps) {
    if (!nextProps.open) {
      this.setState({ l2: false, l3: false });
    }
  }

  getContent = content => {
    let newContent = content;
    if (content && content.length > 13) {
      newContent = content.slice(0, 13);
    }

    return newContent;
  };
  changeMenuState = (level, stat) => {
    this.setState({ [level]: stat });
  };

  render() {
    const { level2Data, headingL2, mostPop } = this.props;
    const mostPoptypes = mostPop ? mostPop.mostPopularCategories : {};
    const MostPop = [];
    Object.keys(mostPoptypes).map(key => MostPop.push(mostPoptypes[key]));
    const mostPopularTypes = [].concat([], ...MostPop);
    return (
      <Popover
        open={this.props.open}
        anchorEl={this.props.anchorEl}
        anchorOrigin={{ horizontal: 'left', vertical: 'bottom' }}
        targetOrigin={{ horizontal: 'left', vertical: 'top' }}
        onRequestClose={() => this.props.handleRequestClose()}
        className={styles.popOver}
        canAutoPosition={false}
      >
        <div className={styles.mainMenu}>
          {this.state.l1 && (
            <div className={styles.borderShow}>
              <MenuLevel1
                currentLevel={this.props.currentLevel}
                label={this.props.menuKey}
                changeMenuState={this.changeMenuState}
              />
            </div>
          )}
          {this.state.p &&
            mostPopularTypes.length > 0 && (
              <div className={styles.borderShow}>
                <header className={styles.menuHeader}>
                  Most Popular {this.props.menuKey}
                </header>
                <ListContainer
                  content={this.getContent(mostPopularTypes)}
                  seeMore={mostPopularTypes.length > 13}
                />
              </div>
            )}
          {this.state.l2 && (
            <div className={styles.borderShow}>
              <MenuLevel2
                currentLevel={this.props.currentLevel}
                changeMenuState={this.changeMenuState}
              />
            </div>
          )}
          {this.state.l3 && (
            <div className={styles.borderShow}>
              <MenuLevel3
                currentLevel={this.props.currentLevel}
                label={headingL2}
                content={level2Data}
              />
            </div>
          )}
        </div>
      </Popover>
    );
  }
}

const connector: Connector<{}, Props> = connect(({ topNavData }: Object) => ({
  level1: topNavData.level1,
  level2MostPop: topNavData.level2MostPop,
  headingL1: topNavData.headingL1,
  level2Data: topNavData.level2Data,
  headingL2: topNavData.headingL2,
  levelClose: topNavData.levelClose,
  mostPop: topNavData.subCatData.mostPopularCategories
}));

export default connector(MenuSlider);
