/* @flow */
import React from 'react';
import type { Element } from 'react';
import Popover from 'material-ui/Popover';
import Divider from 'material-ui/Divider';
import styles from './styles.scss';

type Props = {
  open: boolean,
  anchorEl: Object,
  handleRequestClose: () => void
};

const PopOverMenuComponentFeatured = (props: Props): Element<'div'> => (
  <Popover
    open={props.open}
    anchorEl={props.anchorEl}
    anchorOrigin={{ horizontal: 'left', vertical: 'bottom' }}
    targetOrigin={{ horizontal: 'left', vertical: 'top' }}
    onRequestClose={() => props.handleRequestClose()}
    className={styles.popOver}
    canAutoPosition={false}
  >
    <div className={`col s12 ${styles.top} ${styles.feature}`}>
      <ul>
        <li className={styles.featurehead}>FEATURES</li>
        <Divider />
        <li>Duralast Brake Pads</li>
        <li>Duralst Gold Battery</li>
        <li>Pennzoil Platinum Motoer Oil SAE</li>
        <li>Valvoline Premium Conventional Engine Oil</li>
        <li>Duralast Gold Alternator</li>
        <li>XtraVision Headlight</li>
      </ul>
    </div>
  </Popover>
);

export default PopOverMenuComponentFeatured;
