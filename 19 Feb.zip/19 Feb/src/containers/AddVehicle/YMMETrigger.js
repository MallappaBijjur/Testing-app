/* @flow */
import React from 'react';
import Drawer from 'material-ui/Drawer';
import Dialog from 'material-ui/Dialog';
import NavigationClose from 'material-ui/svg-icons/navigation/close';
import { AddVehicleComp } from './index';
import { YMMEDesktopComp } from './YMMEDesktop';
import * as VehicleStyles from './YMMEDesktop.scss';

const customContentStyle = {
  width: '100%',
  maxWidth: 'none',
  minHeight: '300px'
};

const renderAddVehicle = (
  showYMME: any,
  viewType: any,
  yearList: any,
  addedVehicle: any,
  toggleYMME: any
) => {
  if (yearList !== undefined && viewType === 'DESKTOP') {
    return (
      <Dialog
        modal
        contentStyle={customContentStyle}
        bodyClassName={VehicleStyles.dialogBodyClass}
        contentClassName="dialogContentCls"
        open={showYMME}
        repositionOnUpdate
      >
        <NavigationClose
          onClick={toggleYMME}
          className={VehicleStyles.vehicleCloseBtn}
        />
        <YMMEDesktopComp data={yearList} handleClose={toggleYMME} />
      </Dialog>
    );
  } else if (yearList !== undefined && viewType === 'MOBILE') {
    return (
      <Drawer width="100%" openSecondary open={showYMME} className="YMMEModal">
        <AddVehicleComp yearList={yearList} toggleYMME={toggleYMME} />
      </Drawer>
    );
  }
  return (
    <Drawer width="100%" openSecondary open={showYMME} className="YMMEModal">
      <AddVehicleComp yearList={yearList} toggleYMME={toggleYMME} />
    </Drawer>
  );
};

export default renderAddVehicle;
