/* @flow */
import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import type { Connector } from 'react-redux';
import PropTypes from 'prop-types';
import { Step, Stepper, StepLabel } from 'material-ui/Stepper';
import AppBar from 'material-ui/AppBar';
import NavigationClose from 'material-ui/svg-icons/navigation/close';
import BackButton from 'material-ui/svg-icons/navigation/arrow-back';
import IconButton from 'material-ui/IconButton';
import * as styles from './addvehicle.scss';
import * as ymmeActions from '../../actions/ymmeActions';
import type { Dispatch, ReduxState } from '../../types';
import MenuOptions from '../../components/YMME/MenuOptions';
import AddedVehicleMobile from '../../components/YMME/AddedVehicleMobile';

type Props = {
  fetchYMMEMakeList: any => void,
  fetchYMMEModelList: (any, any) => void,
  fetchYMMEEngineList: (any, any) => void,
  toggleYMME: () => void,
  ymmeAddVehicle: any => void,
  yearList: any,
  makeList: any,
  engineList: any,
  modelList: any,
  addedVehicle: () => void
};

type State = {
  stepIndex: number,
  selectedYear: string,
  selectedMake: string,
  selectedModel: string,
  vehicleAdded: boolean,
  selected: boolean
};

type RenderNumberProps = {
  index: any
};

const RenderTick = (): any => (
  <span className={styles.stepperTick}>&#10003;</span>
);

const RenderNumber = (props: RenderNumberProps): any => (
  <span className={styles.stepperNumber}>{props.index}</span>
);
RenderNumber.propTypes = {
  index: PropTypes.number.isRequired
};

// Export this for unit testing more easily
export class AddVehicleComp extends PureComponent<Props, State> {
  constructor(props: any) {
    super(props);
    this.state = {
      stepIndex: 1,
      selectedYear: '',
      selectedMake: '',
      selectedModel: '',
      vehicleAdded: true,
      selected: false
    };
  }

  componentDidMount() {
    // this.props.ymmeRemoveVehicle();
    // this.props.ymmeVehicleList();
  }

  getStepContent(stepIndex: number) {
    const { selectedYear, selectedMake, selectedModel } = this.state;
    switch (stepIndex) {
      case 1:
        return (
          <div>
            Select vehicle year <span> / Make / Model / Engine</span>
          </div>
        );
      case 2:
        return (
          <div>
            {' '}
            {selectedYear} <span>Make / Model / Engine </span>
          </div>
        );
      case 3:
        return (
          <div>
            {' '}
            {selectedYear} {selectedMake} <span>Model / Engine</span>
          </div>
        );
      case 4:
        return (
          <div>
            {' '}
            {selectedYear} {selectedMake} {selectedModel} <span>Engine</span>
          </div>
        );
      default:
        return 'Engine';
    }
  }

  selectYear = (item: any) => {
    const { stepIndex } = this.state;
    this.props.fetchYMMEMakeList(item);
    this.setState({
      selectedYear: item.year,
      stepIndex: stepIndex + 1
    });
  };

  selectMake = (item: any) => {
    const { stepIndex, selectedYear } = this.state;
    this.props.fetchYMMEModelList(selectedYear, item);
    this.setState({
      selectedMake: item.make,
      stepIndex: stepIndex + 1
    });
  };

  selectModel = (item: any) => {
    const { stepIndex, selectedModel } = this.state;
    this.props.fetchYMMEEngineList(selectedModel, item);
    this.setState({
      selectedModel: item.model,
      stepIndex: stepIndex + 1
    });
  };

  selectEngine = (item: any) => {
    this.props.toggleYMME();
    this.props.ymmeAddVehicle(item);
    this.setState({
      stepIndex: 1,
      vehicleAdded: true
    });
  };

  handleBack = () => {
    const { stepIndex } = this.state;
    if (stepIndex > 1 && stepIndex <= 4) {
      this.setState({ stepIndex: stepIndex - 1 });
    }
  };

  handleClose = (action: any) => {
    this.setState({
      stepIndex: 1,
      selectedYear: '',
      selectedMake: '',
      selectedModel: '',
      vehicleAdded: action === 'CLOSE'
    });
    if (action === 'CLOSE') {
      this.props.toggleYMME();
    }
  };

  render() {
    const { stepIndex, vehicleAdded } = this.state;
    const {
      yearList,
      makeList,
      modelList,
      engineList,
      addedVehicle
    } = this.props;
    console.log('STATE', this.state);
    console.log('addedVehicle', addedVehicle);
    const stepValues = ['YEAR', 'MAKE', 'MODEL', 'ENGINE'];
    const titleText = stepIndex === 1 ? 'ADD A VEHICLE' : 'BACK';
    let renderMenu = [];
    if (stepIndex === 1) {
      renderMenu = (
        <MenuOptions list={yearList} selectValue={this.selectYear} />
      );
    } else if (stepIndex === 2) {
      renderMenu = (
        <MenuOptions list={makeList} selectValue={this.selectMake} />
      );
    } else if (stepIndex === 3) {
      renderMenu = (
        <MenuOptions list={modelList} selectValue={this.selectModel} />
      );
    } else if (stepIndex === 4) {
      renderMenu = (
        <MenuOptions list={engineList} selectValue={this.selectEngine} />
      );
    }

    const stepLabels = stepValues.map((item, i) => {
      if (stepIndex === i + 1) {
        return (
          <Step key={item}>
            <StepLabel
              iconContainerStyle={{
                border: '1px solid #000',
                marginRight: '5px',
                height: '16px',
                lineHeight: '16px',
                width: '16px',
                padding: 0
              }}
              icon={
                stepIndex > i + 1 ? (
                  <RenderTick />
                ) : (
                  <RenderNumber index={i + 1} />
                )
              }
              style={{
                height: '45px',
                borderBottom: '2px solid #f38021',
                padding: 0,
                margin: '0 10px',
                fontSize: '12px',
                color: '#000'
              }}
            >
              {item}
            </StepLabel>
          </Step>
        );
      }
      if (stepIndex - 1 >= 0 && stepIndex - i >= 1) {
        return (
          <Step key={item}>
            <StepLabel
              iconContainerStyle={{
                border: '1px solid #000',
                marginRight: '5px',
                height: '16px',
                lineHeight: '16px',
                width: '16px',
                padding: 0,
                backgroundColor: '#000',
                color: '#fff'
              }}
              icon={
                stepIndex > i + 1 ? (
                  <RenderTick />
                ) : (
                  <RenderNumber index={i + 1} />
                )
              }
              style={{
                height: '45px',
                padding: 0,
                margin: '0 10px',
                fontSize: '12px',
                color: '#000'
              }}
            >
              {item}
            </StepLabel>
          </Step>
        );
      }
      return (
        <Step key={item}>
          <StepLabel
            iconContainerStyle={{
              border: '1px solid #a9aaa8',
              marginRight: '5px',
              height: '16px',
              lineHeight: '16px',
              width: '16px',
              padding: 0
            }}
            icon={
              stepIndex > i + 1 ? (
                <RenderTick />
              ) : (
                <RenderNumber index={i + 1} />
              )
            }
            style={{
              height: '45px',
              color: '#a9aaa8',
              fontSize: '12px',
              padding: '0 10px'
            }}
          >
            {item}
          </StepLabel>
        </Step>
      );
    });

    return (
      <div className={styles.addVehicleWrapper}>
        <div className={styles.addVehicleYMME}>
          <AppBar
            className={styles.addVehicleClose}
            title={addedVehicle && vehicleAdded ? 'SHOP BY VEHICLE' : titleText}
            titleStyle={{ height: '36px', lineHeight: '36px' }}
            onTitleClick={this.handleBack}
            showMenuIconButton={stepIndex > 1}
            iconStyleLeft={{ margin: '9px 0px', paddingRight: '5px' }}
            iconStyleRight={{ margin: '0 -5px' }}
            iconElementLeft={
              stepIndex > 1 ? (
                <BackButton
                  style={{ height: '26px', width: '26px', color: '#fff' }}
                />
              ) : null
            }
            iconElementRight={
              <IconButton
                onClick={() => this.handleClose('CLOSE')}
                style={{ height: '26px', width: '26px', padding: '9px 0 0' }}
              >
                <NavigationClose />
              </IconButton>
            }
          />
          {addedVehicle && vehicleAdded ? (
            <AddedVehicleMobile
              data={addedVehicle}
              handleClose={this.handleClose}
            />
          ) : (
            <div>
              <div className={styles.ymmeBreadcrumbHolder}>
                <Stepper
                  activeStep={stepIndex}
                  connector={null}
                  style={{ margin: '0 10px' }}
                >
                  {stepLabels}
                </Stepper>
                <hr />
                <div className={styles.ymmeBreadcrumb}>
                  {this.state.selected} {this.getStepContent(stepIndex)}
                </div>
              </div>
              <hr />
              <div className={styles.ymmeLists}>{renderMenu}</div>
            </div>
          )}
        </div>
      </div>
    );
  }
}
/* istanbul ignore next */
const connector: Connector<{}, Props> = connect(
  ({ ymmeData }: ReduxState) => ({
    makeList: ymmeData.data.makeList,
    modelList: ymmeData.data.modelList,
    engineList: ymmeData.data.engineList,
    vehicleList: ymmeData.data.vehicleList,
    addedVehicle: ymmeData.data.addedVehicle
  }),
  (dispatch: Dispatch) => ({
    fetchYMMEMakeList: year => dispatch(ymmeActions.fetchYMMEMakeList(year)),
    fetchYMMEModelList: (year, make) =>
      dispatch(ymmeActions.fetchYMMEModelList(year, make)),
    fetchYMMEEngineList: (model, make) =>
      dispatch(ymmeActions.fetchYMMEEngineList(model, make)),
    ymmeAddVehicle: engine => dispatch(ymmeActions.ymmeAddVehicle(engine)),
    ymmeRemoveVehicle: () => dispatch(ymmeActions.ymmeRemoveVehicle()),
    ymmeVehicleList: () => dispatch(ymmeActions.ymmeVehicleList())
  })
);
export default connector(AddVehicleComp);
