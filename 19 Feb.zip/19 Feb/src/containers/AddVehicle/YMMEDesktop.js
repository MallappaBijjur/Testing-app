/* @flow */
import React, { PureComponent } from 'react';
import { connect, Connector } from 'react-redux';
import RaisedButton from 'material-ui/RaisedButton';
import styles from './YMMEDesktop.scss';
import AutoCompleteComponent from '../../components/YMME/AutoComplete';
import PrefferedVehicle from '../../components/YMME/PrefferedVehicle';
import DifferentVehicles from '../../components/YMME/VehicleList';
import * as ymmeActions from '../../actions/ymmeActions';
import type { Dispatch, ReduxState } from '../../types';

type Props = {
  fetchYMMEMakeList: any => void,
  fetchYMMEModelList: (any, any) => void,
  fetchYMMEEngineList: (any, any) => void,
  ymmeAddVehicle: any => void,
  yearList: any,
  makeList: any,
  engineList: any,
  modelList: any,
  addedVehicle: () => void,
  handleClose: () => void,
  data: any
};

const CurrentlyShoppingData = {
  vehicleDisplayName: 'No Vehicle Selected'
};
const DifferentVehiclesData = {
  name: 'No Other Vehicles Exist'
};
const MakeData = {
  name: 'make',
  label: 'Make'
};
const YearData = {
  name: 'year',
  label: 'Year'
};
const ModalData = {
  name: 'model',
  label: 'Model'
};
const EngineData = {
  name: 'engine',
  label: 'Engine'
};

type State = {
  stepIndex: number,
  selectedYear: string,
  selectedModel: any,
  selectedEngine: any,
  disableYear: boolean,
  disableMake: boolean,
  disableModel: boolean,
  disableEngine: boolean,
  resetYearField: boolean,
  resetMakeField: boolean,
  resetModelField: boolean,
  resetEngineField: boolean,
  maxYearLength: number,
  maxLength: number
};

export class YMMEDesktopComp extends PureComponent<Props, State> {
  constructor(props: any) {
    super(props);
    this.state = {
      stepIndex: 1,
      selectedYear: '',
      selectedModel: null,
      selectedEngine: null,
      disableYear: false,
      disableMake: true,
      disableModel: true,
      disableEngine: true,
      resetYearField: false,
      resetMakeField: false,
      resetModelField: false,
      resetEngineField: false,
      maxYearLength: 4,
      maxLength: 100
    };
  }

  selectYear = (item: any) => {
    const { stepIndex } = this.state;
    this.props.fetchYMMEMakeList(item);
    this.setState({
      selectedYear: item.year,
      stepIndex: stepIndex + 1,
      disableMake: false,
      disableEngine: true,
      disableModel: true,
      // selectedMake: '',
      resetMakeField: true,
      resetModelField: true,
      resetEngineField: true
      // singleRecordData: ''
    });
  };

  selectMake = (item: any) => {
    const { stepIndex, selectedYear } = this.state;
    this.props.fetchYMMEModelList(selectedYear, item);
    this.setState({
      // selectedMake: item.make,
      stepIndex: stepIndex + 1,
      disableModel: false,
      disableEngine: true,
      resetYearField: false,
      resetMakeField: false,
      resetModelField: true,
      resetEngineField: true
    });
  };

  selectModel = (item: any) => {
    console.log('selectModel', item);
    const { stepIndex, selectedModel } = this.state;
    this.props.fetchYMMEEngineList(selectedModel, item);
    this.setState({
      selectedModel: item.model,
      stepIndex: stepIndex + 1,
      disableEngine: false,
      resetYearField: false,
      resetMakeField: false,
      resetModelField: false,
      resetEngineField: true
      // singleRecordData: ''
    });
  };

  selectEngine = (item: any) => {
    console.log('selectEngine', item);
    const { stepIndex } = this.state;
    this.setState({
      selectedEngine: item,
      stepIndex: stepIndex + 1,
      resetYearField: false,
      resetMakeField: false,
      resetModelField: false,
      resetEngineField: false
      // singleRecordData: ''
    });
  };

  submitVehicleHandler = () => {
    const { selectedEngine } = this.state;
    this.props.ymmeAddVehicle(selectedEngine);
    this.props.handleClose();
  };

  render() {
    const {
      disableYear,
      disableMake,
      disableModel,
      disableEngine
    } = this.state;
    const {
      yearList,
      makeList,
      modelList,
      engineList,
      addedVehicle
    } = this.props;
    let selectedVehicle = CurrentlyShoppingData;
    if (addedVehicle) {
      selectedVehicle = addedVehicle;
    }

    return (
      <div className={styles.yymeContainer}>
        <div className={styles.yymeTopContainer}>
          <div className={styles.yymeTopContainerPosition}>
            <div className="row">
              <div className="col s12 m12 l12 xl12">
                <div className={styles.yymeTitle}>
                  WHAT ARE YOU WORKING ON TODAY?
                </div>
                <div className={styles.yymeDescription}>
                  Shop for your specific vehicle to find parts that fit.
                </div>
                <div className={styles.yymeRegion}>
                  <div className={styles.yymeyear}>
                    <AutoCompleteComponent
                      data={YearData}
                      datasource={yearList}
                      changeHandler={this.selectYear}
                      disableAutocomplete={disableYear}
                      resetField={this.state.resetYearField}
                      maxLength={this.state.maxYearLength}
                    />
                  </div>
                  <div className={styles.yymeMake}>
                    <AutoCompleteComponent
                      data={MakeData}
                      datasource={makeList}
                      changeHandler={this.selectMake}
                      disableAutocomplete={disableMake}
                      resetField={this.state.resetMakeField}
                      maxLength={this.state.maxLength}
                    />
                  </div>
                  <div className={styles.yymeModelEngine}>
                    <AutoCompleteComponent
                      data={ModalData}
                      datasource={modelList}
                      changeHandler={this.selectModel}
                      disableAutocomplete={disableModel}
                      resetField={this.state.resetModelField}
                      maxLength={this.state.maxLength}
                    />
                  </div>
                  <div className={styles.yymeModelEngine}>
                    <AutoCompleteComponent
                      data={EngineData}
                      datasource={engineList}
                      changeHandler={this.selectEngine}
                      disableAutocomplete={disableEngine}
                      resetField={this.state.resetEngineField}
                      maxLength={this.state.maxLength}
                    />
                  </div>
                  <div className={styles.yymeVehicle}>
                    <div>
                      <img
                        src="/images/az-car.png"
                        alt="Logo"
                        className={styles.imgAddVehicleBtn}
                      />
                      <RaisedButton
                        onClick={this.submitVehicleHandler}
                        disabled={disableEngine !== false}
                        label="Add vehicle"
                        className={styles.addVehicleBtn}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col s12 m12 l12 xl12 ">
            <div className={`${styles.yymeBottomContainer}`}>
              <div className="col s6 m6 l6 xl6">
                <PrefferedVehicle data={selectedVehicle} />
              </div>
              <div className="col s6 m6 l6 xl6">
                <DifferentVehicles data={DifferentVehiclesData} />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

/* istanbul ignore next */
const connector: Connector<{}, Props> = connect(
  ({ ymmeData }: ReduxState) => ({
    yearList: ymmeData.data.yearList,
    makeList: ymmeData.data.makeList,
    modelList: ymmeData.data.modelList,
    engineList: ymmeData.data.engineList,
    addedVehicle: ymmeData.data.addedVehicle
  }),
  (dispatch: Dispatch) => ({
    fetchYMMEMakeList: year => dispatch(ymmeActions.fetchYMMEMakeList(year)),
    fetchYMMEModelList: (year, make) =>
      dispatch(ymmeActions.fetchYMMEModelList(year, make)),
    fetchYMMEEngineList: (model, make) =>
      dispatch(ymmeActions.fetchYMMEEngineList(model, make)),
    ymmeAddVehicle: engine => dispatch(ymmeActions.ymmeAddVehicle(engine))
  })
);
export default connector(YMMEDesktopComp);
