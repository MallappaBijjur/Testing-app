/* @flow */

import React, { PureComponent } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import lightBaseTheme from 'material-ui/styles/baseThemes/lightBaseTheme';
import RaisedButton from 'material-ui/RaisedButton';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import AutoComplete from 'material-ui/AutoComplete';
import styles from './vehicle.scss';

type State = {
  searchText: any
};

const stylesYmme = {
  textFieldStyle: {
    width: '100px'
  },
  floatingLabelFocusStyle: {
    background: 'white',
    height: '20px',
    padding: '0 5px',
    color: 'black',
    fontWeight: 'bold'
  },
  labelStyle: {
    height: '13px',
    top: 0,
    bottom: 0,
    margin: 'auto',
    color: 'black'
  }
};

const year = ['1950', '1951', '1982', '1993', '1994', '2055', '2056', '2057'];

const Make = [
  'test',
  'aaaa',
  'bbbbb',
  'aaddd',
  'aabbbb',
  'adasd',
  'ffff',
  'hhhh'
];

class YMME extends PureComponent<{}, State> {
  constructor() {
    super();
    this.state = {
      searchText: ''
    };
  }

  handleUpdateInput = (searchText: any) => {
    this.setState({
      searchText
    });
  };

  render() {
    return (
      <div className="col s12 m12 l12 xl12">
        <div className={styles.yymeContainer}>
          <div className="row">
            <div className="col s12 m12 l12 xl12">
              <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
                <div
                  className={`col s12 m12 l12 xl12 ${styles.yymeTopContainer}`}
                >
                  <div className={styles.yymeTitle}>
                    What are you working on today?
                  </div>
                  <div className={styles.yymeDescription}>
                    Shop for your specific vehicle to find parts that fit.
                  </div>

                  <div className={styles.yymeRegion}>
                    <div className={styles.yymeyear}>
                      <AutoComplete
                        floatingLabelText="Year"
                        hintText="Year"
                        searchText={this.state.searchText}
                        onUpdateInput={this.handleUpdateInput}
                        dataSource={year}
                        filter={AutoComplete.caseInsensitiveFilter}
                        openOnFocus
                        textFieldStyle={stylesYmme.textFieldStyle}
                        style={stylesYmme.textFieldStyle}
                        floatingLabelFocusStyle={
                          stylesYmme.floatingLabelFocusStyle
                        }
                        floatingLabelStyle={stylesYmme.labelStyle}
                      />
                      <div className={styles.Divider} />
                    </div>

                    <div className={styles.yymeMake}>
                      <AutoComplete
                        floatingLabelText="Make"
                        hintText="Make"
                        searchText={this.state.searchText}
                        onUpdateInput={this.handleUpdateInput}
                        dataSource={Make}
                        filter={AutoComplete.caseInsensitiveFilter}
                        openOnFocus
                        textFieldStyle={stylesYmme.textFieldStyle}
                        style={stylesYmme.textFieldStyle}
                        floatingLabelFocusStyle={
                          stylesYmme.floatingLabelFocusStyle
                        }
                        floatingLabelStyle={stylesYmme.labelStyle}
                      />
                      <div className={styles.Divider} />
                    </div>
                    <div className={styles.yymeModelEngine}>
                      <AutoComplete
                        floatingLabelText="Model"
                        hintText="Make"
                        searchText={this.state.searchText}
                        onUpdateInput={this.handleUpdateInput}
                        dataSource={Make}
                        filter={AutoComplete.caseInsensitiveFilter}
                        openOnFocus
                        textFieldStyle={stylesYmme.textFieldStyle}
                        style={stylesYmme.textFieldStyle}
                        floatingLabelFocusStyle={
                          stylesYmme.floatingLabelFocusStyle
                        }
                        floatingLabelStyle={stylesYmme.labelStyle}
                      />
                      <div className={styles.Divider} />
                    </div>
                    <div className={styles.yymeModelEngine}>
                      <AutoComplete
                        floatingLabelText="Engine"
                        hintText="Make"
                        searchText={this.state.searchText}
                        onUpdateInput={this.handleUpdateInput}
                        dataSource={Make}
                        filter={AutoComplete.caseInsensitiveFilter}
                        openOnFocus
                        textFieldStyle={stylesYmme.textFieldStyle}
                        style={stylesYmme.textFieldStyle}
                        floatingLabelFocusStyle={
                          stylesYmme.floatingLabelFocusStyle
                        }
                        floatingLabelStyle={stylesYmme.labelStyle}
                      />
                      <div className={styles.Divider} />
                    </div>
                    <div className={styles.yymeVehicle}>
                      <RaisedButton
                        label="Add vehicle"
                        className={styles.addVehicleBtn}
                      />
                    </div>
                  </div>
                </div>
                <div
                  className={`col s12 m12 l12 xl12 ${
                    styles.yymeBottomContainer
                  }`}
                >
                  <div className="col s6 m6 l6 xl6">
                    <div className={styles.leftContainer}>
                      <div className={styles.yymeLabel}>
                        Currently Shopping For
                      </div>
                      <div className={styles.yymeVehicleSelection}>
                        <img
                          src="/images/regDollar.png"
                          alt="Logo"
                          style={{ float: 'left', paddingRight: '15px' }}
                        />
                        <div>Currently Shopping For</div>
                      </div>
                      <div className={styles.horzDivider} />
                      <div className="s12 m12 l12 xl12">
                        <RaisedButton
                          label="Manage vehicle"
                          className={styles.manageVehicleBtn}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="col s6 m6 l6 xl6">
                    <div className={styles.yymeLabel}>
                      No Other Vehicles Exist
                    </div>
                  </div>
                </div>
                <div>
                  <div />
                </div>
              </MuiThemeProvider>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

// const confirmation = connect(state => {
//   console.log('STATE', state);
//   return {
//     successValues: state.formInfo.successValues
//   };
// })(YMME);

export default YMME;
