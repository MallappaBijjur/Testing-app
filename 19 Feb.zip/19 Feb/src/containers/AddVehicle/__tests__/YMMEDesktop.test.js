/* @flow */
import React from 'react';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
import { MuiThemeProvider } from 'material-ui/styles';
import { mount } from 'enzyme';
import RaisedButton from 'material-ui/RaisedButton';
import AutoCompleteComponent from '../../../components/YMME/AutoComplete';
import { YMMEDesktopComp } from '../YMMEDesktop';

let datasourceYear = {};
let datasourceMake = {};
let datasourceModel = {};
let datasourceEngine = {};
beforeEach(() => {
  datasourceYear = {
    atgResponse: [
      {
        '@class': 'com.autozone.diy.ymme.bean.YearBean',
        year: '201800',
        count: '0',
        yearId: '9018000'
      }
    ]
  };
  datasourceMake = {
    atgResponse: [
      {
        makeId: '9018099',
        '@class': 'com.autozone.diy.ymme.bean.MakeBean',
        count: '0',
        make: 'Acura'
      }
    ]
  };
  datasourceModel = {
    atgResponse: [
      {
        '@class': 'com.autozone.diy.ymme.bean.ModelBean',
        modelId: '9637900',
        count: '0',
        model: 'RDX 2WD'
      }
    ]
  };

  datasourceEngine = {
    atgResponse: [
      {
        '@class': 'com.autozone.diy.ymme.bean.EngineBean',
        engine: '6 Cylinders   3.5L FI SOHC VTEC',
        count: '0',
        engineId: '36379001'
      }
    ]
  };
});

const CurrentlyShoppingData = {
  vehicleDisplayName: 'No Vehicle Selected'
};
const DifferentVehiclesData = {
  name: 'No Other Vehicles Exist'
};
const MakeData = {
  name: 'make',
  label: 'Make'
};
const YearData = {
  name: 'year',
  label: 'Year'
};
const ModalData = {
  name: 'model',
  label: 'Model'
};
const EngineData = {
  name: 'engine',
  label: 'Engine'
};

describe('<YMMEDesktopComp />', () => {
  let PROPS = {};
  beforeEach(() => {
    PROPS = {
      stepIndex: 1,
      isDisabledAddVehicle: true,
      disableYear: false,
      disableMake: true,
      disableModel: true,
      disableEngine: true,
      yearList: datasourceYear.atgResponse,
      makeList: datasourceMake.atgResponse,
      modelList: datasourceModel.atgResponse,
      engineList: datasourceEngine.atgResponse,
      addedVehicle: 'test',
      YearData,
      ModalData,
      EngineData,
      MakeData,
      CurrentlyShoppingData,
      DifferentVehiclesData,
      data: YearData,
      ymmeData: datasourceYear,
      ymmeAddVehicle: jest.fn(),
      handleClose: jest.fn(),
      fetchYMMEMakeList: jest.fn(),
      fetchYMMEEngineList: jest.fn(),
      fetchYMMEModelList: jest.fn()
    };
  });
  test('renders correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <YMMEDesktopComp {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );

    //   // find the create account button and simulate a click event by calling its onClick prop
    // const submitVehicleHandler = jest.fn();
    wrapper
      .find(RaisedButton)
      .at(0)
      .props()
      .onClick();
    // expect(toJson(wrapper)).toMatchSnapshot();

    wrapper
      .find(AutoCompleteComponent)
      .at(0)
      .props()
      .changeHandler(datasourceYear.atgResponse[0]);
    //    wrapper.
    // find(Accordion.Title).
    // props().
    // onClick({},{index:1});
  });

  test('onchange year render correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <YMMEDesktopComp {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );

    wrapper
      .find(AutoCompleteComponent)
      .at(0)
      .props()
      .changeHandler(datasourceYear.atgResponse[0]);
  });

  test('onchange make render model correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <YMMEDesktopComp {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );

    wrapper
      .find(AutoCompleteComponent)
      .at(1)
      .props()
      .changeHandler(datasourceMake.atgResponse[0]);
  });

  test('onchange model render correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <YMMEDesktopComp {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );

    wrapper
      .find(AutoCompleteComponent)
      .at(2)
      .props()
      .changeHandler(datasourceModel.atgResponse[0]);
  });
  test('onchange engine render correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <YMMEDesktopComp {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );

    wrapper
      .find(AutoCompleteComponent)
      .at(3)
      .props()
      .changeHandler(datasourceEngine.atgResponse[0]);
  });
});
