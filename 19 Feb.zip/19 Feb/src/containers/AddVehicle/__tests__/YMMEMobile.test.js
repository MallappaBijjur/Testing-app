/* @flow */
import React from 'react';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
import { MuiThemeProvider } from 'material-ui/styles';
import { mount, shallow } from 'enzyme';
import AppBar from 'material-ui/AppBar';
import IconButton from 'material-ui/IconButton';
import { AddVehicleComp } from '../index';
import MenuOptions from '../../../components/YMME/MenuOptions';
import AddedVehicleMobile from '../../../components/YMME/AddedVehicleMobile';

let datasourceYear = {};
let datasourceMake = {};
let datasourceModel = {};
let datasourceEngine = {};
beforeEach(() => {
  datasourceYear = {
    atgResponse: [
      {
        '@class': 'com.autozone.diy.ymme.bean.YearBean',
        year: '201800',
        count: '0',
        yearId: '9018000'
      }
    ]
  };
  datasourceMake = {
    atgResponse: [
      {
        makeId: '9018099',
        '@class': 'com.autozone.diy.ymme.bean.MakeBean',
        count: '0',
        make: 'Acura'
      }
    ]
  };
  datasourceModel = {
    atgResponse: [
      {
        '@class': 'com.autozone.diy.ymme.bean.ModelBean',
        modelId: '9637900',
        count: '0',
        model: 'RDX 2WD'
      }
    ]
  };

  datasourceEngine = {
    atgResponse: [
      {
        '@class': 'com.autozone.diy.ymme.bean.EngineBean',
        engine: '6 Cylinders   3.5L FI SOHC VTEC',
        count: '0',
        engineId: '36379001'
      }
    ]
  };
});

describe('<AddVehicleComp />', () => {
  let PROPS = {};
  beforeEach(() => {
    PROPS = {
      toggleYMME: jest.fn(),
      handleClose: jest.fn(),
      stepIndex: 2,
      selectedYear: '',
      selectedMake: '',
      selectedModel: '',
      selectedEngine: '',
      vehicleAdded: true,
      iconElementLeft: '',
      yearList: datasourceYear,
      makeList: datasourceMake,
      modelList: datasourceModel,
      engineList: datasourceEngine,
      addedVehicle: 'test',
      getStepContent: jest.fn(),
      ymmeAddVehicle: jest.fn(),
      fetchYMMEModelList: jest.fn(),
      fetchYMMEMakeList: jest.fn(),
      fetchYMMEEngineList: jest.fn()
    };
  });

  test('AppBar onTitleClick renders correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <AddVehicleComp {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );
    wrapper
      .find(AppBar)
      .props()
      .onTitleClick();
  });
  test('AppBar click renders correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <AddVehicleComp {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );
    wrapper.find(IconButton).simulate('click');
    wrapper
      .find(AddedVehicleMobile)
      .props()
      .handleClose('CLOSE');
  });

  test('renders correctly with stepIndex 1', () => {
    const wrapper = shallow(<AddVehicleComp {...PROPS} />);
    wrapper.setState({
      stepIndex: 1,
      vehicleAdded: false,
      selectedYear: datasourceYear.atgResponse[0].year
    });
    wrapper
      .find(MenuOptions)
      .props()
      .selectValue(datasourceYear.atgResponse[0]);
  });

  test('renders correctly with stepIndex 2', () => {
    const wrapper = shallow(<AddVehicleComp {...PROPS} />);
    wrapper.setState({
      stepIndex: 2,
      vehicleAdded: false,
      selectedYear: datasourceYear.atgResponse[0].year
    });
    wrapper
      .find(MenuOptions)
      .props()
      .selectValue(datasourceMake.atgResponse[0]);
  });
  test('renders correctly with stepIndex 3', () => {
    const wrapper = shallow(<AddVehicleComp {...PROPS} />);
    wrapper.setState({ stepIndex: 3, vehicleAdded: false });
    wrapper
      .find(MenuOptions)
      .props()
      .selectValue(datasourceModel.atgResponse[0]);
    wrapper.setState({ stepIndex: 3 });
    wrapper
      .find(AppBar)
      .props()
      .onTitleClick();
    wrapper.setState({ stepIndex: 3 });
  });
  test('renders correctly with stepIndex 4', () => {
    const wrapper = shallow(<AddVehicleComp {...PROPS} />);
    wrapper.setState({ stepIndex: 4, vehicleAdded: false });
    wrapper
      .find(MenuOptions)
      .props()
      .selectValue(datasourceModel.atgResponse[0]);
    // console.log("TEST TEST",wrapper.find(MenuOptions).props().selectValue)
  });
  test('renders correctly with stepIndex 5', () => {
    const wrapper = shallow(<AddVehicleComp {...PROPS} />);
    wrapper.setState({ stepIndex: 5, vehicleAdded: false });
  });
});
