/* @flow */
import React from 'react';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
import { MuiThemeProvider } from 'material-ui/styles';
import { mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import { renderAddVehicle } from '../YMMETrigger';

let datasourceYear = {};
beforeEach(() => {
  datasourceYear = {
    atgResponse: [
      {
        '@class': 'com.autozone.diy.ymme.bean.YearBean',
        year: '201800',
        count: '0',
        yearId: '9018000'
      }
    ]
  };
});

describe('<YMME Trigger />', () => {
  let PROPS = {};
  beforeEach(() => {
    PROPS = {
      showYMME: false,
      viewType: 'DESKTOP',
      yearList: datasourceYear.atgResponse,
      toggleYMME: jest.fn(),
      addedVehicle: ''
    };
  });
  test('renders correctly for DESKTOP', () => {
    const store = createStore(() => ({}));
    PROPS.viewType = 'DESKTOP';
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <renderAddVehicle {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );
    wrapper.setState({ viewType: 'DESKTOP' });
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders correctly for MOBILE', () => {
    const store = createStore(() => ({}));
    PROPS.viewType = 'MOBILE';
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <renderAddVehicle {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });
});
