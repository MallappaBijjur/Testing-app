/* @flow */
export const year = {
  atgResponse: [
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '201800',
      count: '0',
      yearId: '9018000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '2017',
      count: '0',
      yearId: '9017000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '2016',
      count: '0',
      yearId: '9016000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '2015',
      count: '0',
      yearId: '9015000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '2014',
      count: '0',
      yearId: '9014000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '2013',
      count: '0',
      yearId: '9013000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '2012',
      count: '0',
      yearId: '9012000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '2011',
      count: '0',
      yearId: '9011000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '2010',
      count: '0',
      yearId: '9010000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '2009',
      count: '0',
      yearId: '9009000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '2008',
      count: '0',
      yearId: '9008000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '2007',
      count: '0',
      yearId: '9007000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '2006',
      count: '0',
      yearId: '9006000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '2005',
      count: '0',
      yearId: '9005000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '2004',
      count: '0',
      yearId: '9004000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '2003',
      count: '0',
      yearId: '9003000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '2002',
      count: '0',
      yearId: '9002000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '2001',
      count: '0',
      yearId: '9001000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '2000',
      count: '0',
      yearId: '9000000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1999',
      count: '0',
      yearId: '9999000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1998',
      count: '0',
      yearId: '9998000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1997',
      count: '0',
      yearId: '9997000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1996',
      count: '0',
      yearId: '9996000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1995',
      count: '0',
      yearId: '9995000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1994',
      count: '0',
      yearId: '9994000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1993',
      count: '0',
      yearId: '9993000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1992',
      count: '0',
      yearId: '9992000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1991',
      count: '0',
      yearId: '9991000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1990',
      count: '0',
      yearId: '9990000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1989',
      count: '0',
      yearId: '9989000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1988',
      count: '0',
      yearId: '9988000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1987',
      count: '0',
      yearId: '9987000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1986',
      count: '0',
      yearId: '9986000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1985',
      count: '0',
      yearId: '9985000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1984',
      count: '0',
      yearId: '9984000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1983',
      count: '0',
      yearId: '9983000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1982',
      count: '0',
      yearId: '9982000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1981',
      count: '0',
      yearId: '9981000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1980',
      count: '0',
      yearId: '9980000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1979',
      count: '0',
      yearId: '9979000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1978',
      count: '0',
      yearId: '9978000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1977',
      count: '0',
      yearId: '9977000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1976',
      count: '0',
      yearId: '9976000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1975',
      count: '0',
      yearId: '9975000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1974',
      count: '0',
      yearId: '9974000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1973',
      count: '0',
      yearId: '9973000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1972',
      count: '0',
      yearId: '9972000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1971',
      count: '0',
      yearId: '9971000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1970',
      count: '0',
      yearId: '9970000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1969',
      count: '0',
      yearId: '9969000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1968',
      count: '0',
      yearId: '9968000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1967',
      count: '0',
      yearId: '9967000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1966',
      count: '0',
      yearId: '9966000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1965',
      count: '0',
      yearId: '9965000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1964',
      count: '0',
      yearId: '9964000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1963',
      count: '0',
      yearId: '9963000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1962',
      count: '0',
      yearId: '9962000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1961',
      count: '0',
      yearId: '9961000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1960',
      count: '0',
      yearId: '9960000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1959',
      count: '0',
      yearId: '9959000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1958',
      count: '0',
      yearId: '9958000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1957',
      count: '0',
      yearId: '9957000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1956',
      count: '0',
      yearId: '9956000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1955',
      count: '0',
      yearId: '9955000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1954',
      count: '0',
      yearId: '9954000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1953',
      count: '0',
      yearId: '9953000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1952',
      count: '0',
      yearId: '9952000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1951',
      count: '0',
      yearId: '9951000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1950',
      count: '0',
      yearId: '9950000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1949',
      count: '0',
      yearId: '9949000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1948',
      count: '0',
      yearId: '9948000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1947',
      count: '0',
      yearId: '9947000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1946',
      count: '0',
      yearId: '9946000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1945',
      count: '0',
      yearId: '9945000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1944',
      count: '0',
      yearId: '9944000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1943',
      count: '0',
      yearId: '9943000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1942',
      count: '0',
      yearId: '9942000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1941',
      count: '0',
      yearId: '9941000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1940',
      count: '0',
      yearId: '9940000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1939',
      count: '0',
      yearId: '9939000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1938',
      count: '0',
      yearId: '9938000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1937',
      count: '0',
      yearId: '9937000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1936',
      count: '0',
      yearId: '9936000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1935',
      count: '0',
      yearId: '9935000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1934',
      count: '0',
      yearId: '9934000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1933',
      count: '0',
      yearId: '9933000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1932',
      count: '0',
      yearId: '9932000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1931',
      count: '0',
      yearId: '9931000'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.YearBean',
      year: '1930',
      count: '0',
      yearId: '9930000'
    }
  ]
};

export const makes = {
  atgResponse: [
    {
      makeId: '9018099',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Acura'
    },
    {
      makeId: '9018001',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Alfa Romeo'
    },
    {
      makeId: '9018002',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Audi'
    },
    {
      makeId: '9018159',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Blue Bird'
    },
    {
      makeId: '9018004',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'BMW'
    },
    {
      makeId: '9018005',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Buick'
    },
    {
      makeId: '9018006',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Cadillac'
    },
    {
      makeId: '9018009',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Chevrolet'
    },
    {
      makeId: '9018019',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Ford'
    },
    {
      makeId: '9018154',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Freightliner'
    },
    {
      makeId: '9018215',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Genesis'
    },
    {
      makeId: '9018068',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'GMC'
    },
    {
      makeId: '9018021',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Honda'
    },
    {
      makeId: '9018022',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Hyundai'
    },
    {
      makeId: '9018176',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'IC Co'
    },
    {
      makeId: '9018071',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'International'
    },
    {
      makeId: '9018025',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Jaguar'
    },
    {
      makeId: '9018146',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Kenworth'
    },
    {
      makeId: '9018027',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Lexus'
    },
    {
      makeId: '9018028',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Lincoln'
    },
    {
      makeId: '9018147',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Mack'
    },
    {
      makeId: '9018031',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Mercedes Benz'
    },
    {
      makeId: '9018035',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Mitsubishi'
    },
    {
      makeId: '9018036',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Nissan/Datsun'
    },
    {
      makeId: '9018149',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Peterbilt'
    },
    {
      makeId: '9018050',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Subaru'
    },
    {
      makeId: '9018206',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Thomas built'
    },
    {
      makeId: '9018055',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Volvo'
    },
    {
      makeId: '9018198',
      '@class': 'com.autozone.diy.ymme.bean.MakeBean',
      count: '0',
      make: 'Western Star'
    }
  ]
};

export const model = {
  atgResponse: [
    {
      '@class': 'com.autozone.diy.ymme.bean.ModelBean',
      modelId: '9637900',
      count: '0',
      model: 'RDX 2WD'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.ModelBean',
      modelId: '9637910',
      count: '0',
      model: 'RDX AWD'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.ModelBean',
      modelId: '9637920',
      count: '0',
      model: 'TLX'
    },
    {
      '@class': 'com.autozone.diy.ymme.bean.ModelBean',
      modelId: '9637930',
      count: '0',
      model: 'TLX SH-AWD'
    }
  ]
};

export const engine = {
  atgResponse: [
    {
      '@class': 'com.autozone.diy.ymme.bean.EngineBean',
      engine: '6 Cylinders   3.5L FI SOHC VTEC',
      count: '0',
      engineId: '36379001'
    }
  ]
};
