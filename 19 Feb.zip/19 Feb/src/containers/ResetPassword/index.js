/* @flow */

import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import type { Connector } from 'react-redux';
import * as resetAccount from '../../actions/resetAccount';
import * as submitResetForm from '../../actions/submitResetForm';
import * as styles from './styles.scss';
import ResetForm from '../../components/ResetForm';
import type {
  ResetFormData as ResetFormDataType,
  Dispatch,
  ReduxState
} from '../../types';
// Export this for unit testing more easily
type Props = {
  resetData: ResetFormDataType,
  resetFormData: Object,
  match: Object,
  fetchResetFormData: () => void,
  submitResetData: (from: Object) => void
};

export const SuccessPassword = (data: Object) => {
  console.log('data', data);
  const content = data.data;
  if (data.isSuccess) {
    return (
      <div className={styles.forgot_content}>
        <p className={styles.mailsuccess}>
          {content.mf_resetpassword_thanks_msg},{' '}
          {content.mf_resetpassword_success}
        </p>
      </div>
    );
  }
  return (
    <div className={styles.forgot_content}>
      {content.mf_resetpassword_link_expired && (
        <p className={styles.mailerror}>
          {content.mf_resetpassword_link_expired}
        </p>
      )}
      {content.mf_resetpassword_server_error && (
        <p className={styles.mailerror}>
          {content.mf_resetpassword_server_error}
        </p>
      )}
    </div>
  );
};

export class ResetPassword extends PureComponent<Props> {
  componentDidMount() {
    this.props.fetchResetFormData();
  }
  handleSubmit = (values: Object) => {
    const { match: { params } } = this.props;
    const forgotFormEmail = {
      password: values.password,
      resetPasswordKey: params.code
    };
    this.props.submitResetData(forgotFormEmail);
  };

  renderForgotForm = () => {
    const { resetData, resetFormData } = this.props;
    const { viewInfo } = resetData;
    const { formValues } = resetFormData;
    if (
      resetFormData &&
      (resetFormData.readyStatus === 'SUBMITRESET_SUCCESS' ||
        resetFormData.readyStatus === 'SUBMITRESET_FAILURE')
    ) {
      return (
        <div>
          {resetFormData.readyStatus === 'SUBMITRESET_SUCCESS' && (
            <div>
              {formValues.success === 'true' && (
                <div>
                  <SuccessPassword data={formValues} isSuccess />
                </div>
              )}
              {formValues.success === 'false' && (
                <div>
                  <SuccessPassword data={formValues} />
                </div>
              )}
            </div>
          )}
          {resetFormData.readyStatus === 'SUBMITRESET_FAILURE' && (
            <div> Please try again later </div>
          )}
        </div>
      );
    }
    return (
      <div>
        {resetData &&
          resetData.readyStatus === 'RESET_SUCCESS' && (
            <ResetForm data={viewInfo} onSubmit={this.handleSubmit} />
          )}
        {resetData.readyStatus === 'RESET_FAILURE' && (
          <div>Oops..Page Not Found</div>
        )}
      </div>
    );
  };
  render() {
    return (
      <div>
        <div className={`hide-on-small-only ${styles.NotFound}`}>
          <div className={styles.forgot_container}>
            <div className={styles.forgot_logo}>
              <img
                src="/images/az-logo.png"
                alt="Logo"
                role="presentation"
                height="43px"
              />
            </div>
            {this.renderForgotForm()}
          </div>
        </div>
        <div className="show-on-small hide-on-med-and-up">
          <div className={styles.forgot_mobile_container}>
            <div className={styles.forgot_logo}>
              <img
                src="/images/Autozonelogo.png"
                alt="Logo"
                role="presentation"
                height="43px"
              />
            </div>
            {this.renderForgotForm()}
          </div>
        </div>
      </div>
    );
  }
}

/* istanbul ignore next */
const connector: Connector<{}, Props> = connect(
  ({ resetData, resetFormData }: ReduxState) => ({
    resetData,
    resetFormData
  }),
  (dispatch: Dispatch) => ({
    fetchResetFormData: () => dispatch(resetAccount.fetchResetFormData()),
    submitResetData: values =>
      dispatch(submitResetForm.submitResetFormAction(values))
  })
);
export default connector(ResetPassword);
// export default connect(null)(ForgotPassword);
