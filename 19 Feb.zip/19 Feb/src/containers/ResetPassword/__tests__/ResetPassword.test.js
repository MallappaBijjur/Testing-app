/* @flow */
import React from 'react';
import toJson from 'enzyme-to-json';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
import { mount } from 'enzyme';
import { MuiThemeProvider } from 'material-ui/styles';
import ResetForm from '../../../components/ResetForm';
import { ResetPassword } from '../index';

describe('<ResetPassword /> container', () => {
  // const mockData = null;
  let PROPS = {};
  beforeEach(() => {
    const mockData = {
      mf_forgotpasswordpage_forgot_invalid_email: 'Email is not valid',
      mf_forgotpasswordpage_forgot_label: 'Email or Username',
      _links: {
        'oc:createAccountPage': {
          method: 'GET',
          href: 'http://dv-camaro1-xl07:8289/autozone/v1/page/createAccountPage'
        },
        curies: [
          {
            templated: true,
            name: 'oc',
            href: '/rels/{rel}'
          }
        ],
        'oc:getResetPasswordPageContents': {
          method: 'GET',
          href: 'http://dv-camaro1-xl07:8289/autozone/v1/page/resetPasswordPage'
        }
      },
      mf_forgotpasswordpage_forgot: 'Forgot your MyZone password?',
      mf_forgotpasswordpage_forgot_required: 'Required',
      mf_forgotpasswordpage_forgot_desc:
        'Enter the email address or username associated with your MyZone account',
      mf_forgotpasswordpage_forgot_button: 'Continue',
      mf_resetpwdpage_submit_button: 'submit',
      readyStatus: 'FORGOT_FAILURE'
    };

    const ResetPasswordMock = {
      email: '',
      formValues: {
        mf_resetpassword_link_expired: 'expired',
        mf_resetpassword_server_error: 'error',
        mf_forgotpassword_error_email_not_found:
          'Entered Email/User Name not found.',
        success: 'true'
      },
      readyStatus: 'SUBMITRESET_SUCCESS'
    };

    const SuccessPassword = {
      data: {
        isSuccess: 'true',
        mf_resetpassword_link_expired: 'mf_resetpassword_link_expired',
        mf_resetpassword_thanks_msg: 'mf_resetpassword_thanks_msg',
        mf_resetpassword_server_error: 'mf_resetpassword_server_error',
        mf_resetpassword_success: 'mf_resetpassword_success',
        success: 'true'
      }
    };

    PROPS = {
      //  forgotData: ForgotDataMock,
      resetFormData: ResetPasswordMock,
      resetData: {
        viewInfo: mockData,
        readyStatus: 'RESET_SUCCESS',
        match: {},
        data: SuccessPassword
      },
      fetchResetFormData: jest.fn(),
      submitResetData: jest.fn()
    };
  });

  test('renders correctly on successfull submit', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <ResetPassword {...PROPS} />
      </Provider>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders correctly on unsuccessfull submit', () => {
    PROPS.resetFormData.readyStatus = 'SUBMITRESET_FAILURE';
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <ResetPassword {...PROPS} />
      </Provider>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders correctly on link expiry', () => {
    PROPS.resetFormData.formValues.success = 'false';
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <ResetPassword {...PROPS} />
      </Provider>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders correctly on successfull initial data load', () => {
    PROPS.resetFormData = {};
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <ResetPassword {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders correctly on unsuccessfull initial data load', () => {
    PROPS.resetFormData = {};
    PROPS.resetData.readyStatus = 'RESET_FAILURE';
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <ResetPassword {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('calls submitResetData prop on submit button click', () => {
    PROPS.resetFormData = {};
    PROPS.match = {
      params: ''
    };
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <ResetPassword {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );
    wrapper
      .find(ResetForm)
      .at(0)
      .props()
      .onSubmit({ password: 'test' });
    expect(PROPS.submitResetData.mock.calls.length).toBe(1);
  });
});
