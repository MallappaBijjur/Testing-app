/* @flow */

import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import type { Connector } from 'react-redux';
import { Link } from 'react-router-dom';
import * as forgotAccount from '../../actions/forgotAccount';
import type {
  ForgotData as ForgotDataType,
  SubmitForgotForm as FogotForm,
  Dispatch,
  ReduxState
} from '../../types';
import * as styles from './styles.scss';
import ForgotForm from '../../components/ForgotForm';
// import showResults from './showResults';
import * as submitForgotForm from '../../actions/submitForgotForm';

type Props = {
  forgotData: ForgotDataType,
  forgotFormData: FogotForm,
  fetchForgotAccountData: () => void,
  submitFormAction: (form: Object) => void
};

const ForgotSuccess = data => {
  const { content } = data;
  const messageData = content;
  return (
    <div className={styles.forgot_content}>
      <h1>{messageData.mf_forgotpassword_success_email_sent_header}</h1>
      <p>
        {messageData.mf_forgotpassword_success_email_sent_message1}
        {messageData.mf_forgotpassword_success_email_sent_emailid}{' '}
        {messageData.mf_forgotpassword_success_email_sent_message2}
      </p>
    </div>
  );
};

// Export this for unit testing more easily
export class ForgotPassword extends PureComponent<Props> {
  componentDidMount() {
    this.props.fetchForgotAccountData();
  }

  handleSubmit = (values: Object) => {
    const forgotFormEmail: Object = {
      email: values.email
    };
    this.props.submitFormAction(forgotFormEmail);
  };

  renderForgotForm = () => {
    const { forgotData, forgotFormData } = this.props;
    const { formValues } = forgotFormData;
    if (
      forgotFormData &&
      (forgotFormData.readyStatus === 'SUBMITFORGOT_SUCCESS' ||
        forgotFormData.readyStatus === 'SUBMITFORGOT_FAILURE')
    ) {
      return (
        <div>
          {forgotFormData.readyStatus === 'SUBMITFORGOT_SUCCESS' && (
            <div>
              {formValues.success === 'true' && (
                <ForgotSuccess content={formValues} />
              )}
              {formValues.success === 'false' && (
                <div>
                  <p className={styles.mailerror}>
                    {formValues.mf_forgotpassword_error_email_not_found}
                  </p>
                  <ForgotForm
                    data={forgotData.viewInfo}
                    onSubmit={this.handleSubmit}
                  />
                </div>
              )}
            </div>
          )}
          {forgotFormData.readyStatus === 'SUBMITFORGOT_FAILURE' && (
            <div> Page Not Found </div>
          )}
        </div>
      );
    }
    return (
      <div>
        {forgotData &&
          forgotData.readyStatus === 'FORGOT_SUCCESS' && (
            <ForgotForm
              data={forgotData.viewInfo}
              onSubmit={this.handleSubmit}
            />
          )}
        {forgotData.readyStatus === 'FORGOT_FAILURE' && (
          <div>Oops..Page Not Found</div>
        )}
      </div>
    );
  };
  render() {
    return (
      <div>
        <div className="hide-on-small-only">
          <Link to="/">
            <img
              style={{
                display: 'block',
                position: 'relative',
                left: '0'
              }}
              src="/images/backBtn.png"
              alt="Back"
              role="presentation"
              width="90px"
              height="58px"
            />
          </Link>
        </div>
        <div className="show-on-small hide-on-med-and-up">
          <span className={styles.bgLink}>
            <Link to="/">
              <img
                style={{
                  display: 'block',
                  position: 'relative',
                  left: '0'
                }}
                src="/images/backBtn.png"
                alt="Back"
                role="presentation"
                width="90px"
                height="58px"
              />
            </Link>
          </span>
        </div>
        <div className={`hide-on-small-only ${styles.NotFound}`}>
          <div className={styles.forgot_container}>
            <div className={styles.forgot_logo}>
              <img
                src="/images/az-logo.png"
                alt="Logo"
                role="presentation"
                height="43px"
              />
            </div>
            {this.renderForgotForm()}
          </div>
        </div>
        <div className="show-on-small hide-on-med-and-up">
          <div className={styles.forgot_mobile_container}>
            <div className={styles.forgot_logo}>
              <img
                src="/images/Autozonelogo.png"
                alt="Logo"
                role="presentation"
                height="43px"
              />
            </div>
            {this.renderForgotForm()}
          </div>
        </div>
      </div>
    );
  }
}

// const connector: Connector<{}, Props> = connect(null);
/* istanbul ignore next */
const connector: Connector<{}, Props> = connect(
  ({ forgotData, forgotFormData }: ReduxState) => ({
    forgotData,
    forgotFormData
  }),
  (dispatch: Dispatch) => ({
    fetchForgotAccountData: () =>
      dispatch(forgotAccount.fetchForgotAccountData()),
    submitFormAction: values =>
      dispatch(submitForgotForm.submitFormAction(values))
  })
);
export default connector(ForgotPassword);
// export default connect(null)(ForgotPassword);
