/* @flow */
import React from 'react';
import { mount } from 'enzyme';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
import { StaticRouter } from 'react-router-dom';
import toJson from 'enzyme-to-json';
import { MuiThemeProvider } from 'material-ui/styles';
import ForgotForm from '../../../components/ForgotForm';
import { ForgotPassword } from '../index';

describe('<ForgotPassword /> container', () => {
  let mockData = null;
  let PROPS = {};
  // let submitFormAction = () => {};
  beforeEach(() => {
    mockData = {
      mf_forgotpasswordpage_forgot_invalid_email: 'Email is not valid',
      mf_forgotpasswordpage_forgot_label: 'Email or Username',
      _links: {
        'oc:createAccountPage': {
          method: 'GET',
          href: 'http://dv-camaro1-xl07:8289/autozone/v1/page/createAccountPage'
        },
        curies: [
          {
            templated: true,
            name: 'oc',
            href: '/rels/{rel}'
          }
        ],
        'oc:getResetPasswordPageContents': {
          method: 'GET',
          href: 'http://dv-camaro1-xl07:8289/autozone/v1/page/resetPasswordPage'
        }
      },
      mf_forgotpasswordpage_forgot: 'Forgot your MyZone password?',
      mf_forgotpasswordpage_forgot_required: 'Required',
      mf_forgotpasswordpage_forgot_desc:
        'Enter the email address or username associated with your MyZone account',
      mf_forgotpasswordpage_forgot_button: 'Continue',
      readyStatus: 'FORGOT_FAILURE'
    };

    const FogotFormMock = {
      email: '',
      formValues: {
        mf_forgotpassword_error_email_not_found:
          'Entered Email/User Name not found.',
        success: 'true'
      },
      readyStatus: 'SUBMITFORGOT_SUCCESS'
    };

    const FogotSuccessMock = {
      mf_forgotpassword_success_email_sent_header:
        'mf_forgotpassword_success_email_sent_header',
      mf_forgotpassword_success_email_sent_message1:
        'mf_forgotpassword_success_email_sent_message1',
      mf_forgotpassword_success_email_sent_emailid:
        'mf_forgotpassword_success_email_sent_emailid',
      mf_forgotpassword_success_email_sent_message2:
        'mf_forgotpassword_success_email_sent_message2',
      formValues: [
        {
          mf_forgotpassword_error_email_not_found:
            'Entered Email/User Name not found.',
          success: 'true'
        }
      ],
      readyStatus: 'SUBMITFORGOT_SUCCESS'
    };

    // const submitFormAction = jest.fn();
    PROPS = {
      forgotFormData: FogotFormMock,
      forgotData: {
        viewInfo: mockData,
        readyStatus: 'FORGOT_SUCCESS',
        data: FogotSuccessMock
      },
      fetchForgotAccountData: () => {},
      submitFormAction: jest.fn()
    };
  });

  test('renders correctly on successfull submit', () => {
    const wrapper = mount(
      <StaticRouter context={{}}>
        <ForgotPassword {...PROPS} />
      </StaticRouter>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders correctly on unsuccessfull submit', () => {
    PROPS.forgotFormData.readyStatus = 'SUBMITFORGOT_FAILURE';
    const wrapper = mount(
      <StaticRouter context={{}}>
        <ForgotPassword {...PROPS} />
      </StaticRouter>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders correctly on link expiry', () => {
    PROPS.forgotFormData.formValues.success = 'false';
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <StaticRouter context={{}}>
          <MuiThemeProvider>
            <ForgotPassword {...PROPS} />
          </MuiThemeProvider>
        </StaticRouter>
      </Provider>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders correctly on successfull initial data load', () => {
    PROPS.forgotFormData = {};
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <StaticRouter context={{}}>
          <MuiThemeProvider>
            <ForgotPassword {...PROPS} />
          </MuiThemeProvider>
        </StaticRouter>
      </Provider>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders correctly on unsuccessfull initial data load', () => {
    PROPS.forgotFormData = {};
    PROPS.forgotData.readyStatus = 'FORGOT_FAILURE';
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <StaticRouter context={{}}>
          <ForgotPassword {...PROPS} />
        </StaticRouter>
      </Provider>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('calls submitResetData prop on submit button click', () => {
    PROPS.forgotFormData = {};
    PROPS.match = {
      params: ''
    };
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <StaticRouter context={{}}>
          <MuiThemeProvider>
            <ForgotPassword {...PROPS} />
          </MuiThemeProvider>
        </StaticRouter>
      </Provider>
    );
    wrapper
      .find(ForgotForm)
      .at(0)
      .props()
      .onSubmit({ password: 'test' });
    expect(PROPS.submitFormAction.mock.calls.length).toBe(1);
  });
});
