/* @flow */
import React from 'react';
import { mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import Paper1 from 'material-ui/Paper';
import { Button } from 'semantic-ui-react';
import { PartCart } from '../PartCart';

jest.mock(
  'material-ui/Paper',
  () =>
    function Paper() {
      return <span>Paper</span>;
    }
);

jest.mock('semantic-ui-react', () => ({
  Button: () => null
}));

describe('<PartCart /> container', () => {
  let PROPS;
  let addToCartCall;
  const shelfPart = {
    productReviewsEnabled: true,
    techNote:
      "*** 750 Cold cranking amps (935 cranking amps)***. 120/68 reserve minutes. Warranty consists of 3 years free replacement. *Caution: Do not use a memory saver on this vehicle*. Check the customer's vehicle, battery installation could take up to 30 minutes. Battery located under hood.",
    skuReviewEnabled: false,
    vendorId: 6294,
    lifetimeWarranty: false,
    alternatePartNumber: null,
    techNotes: [
      '*** 750 Cold cranking amps (935 cranking amps)***.',
      '120/68 reserve minutes.',
      'Warranty consists of 3 years free replacement.',
      '*Caution: Do not use a memory saver on this vehicle*.',
      "Check the customer's vehicle, battery installation",
      'could take up to 30 minutes.',
      'Battery located under hood.'
    ],
    partTypeId: 175,
    skuNumber: 319465,
    oemQuickNote: null,
    locationFilter: '',
    brand: 'Duralast Platinum',
    partType: null,
    productImageUrl: '/images/MEDIA_ProductCatalog/m3490236_prd-Battery.jpg',
    aqCodes: [],
    brandName: null,
    shoprunnerElegible: false,
    count: 0,
    active: true,
    numRecords: 96,
    oemPartNumber: null,
    name: 'Battery_BT',
    brandNode: null,
    itemIdentifier: '319465_929780_18319_',
    oemBrand: null,
    productRepositoryId: '175-0',
    records: null,
    totalPrice: null,
    vehiclSpecific: true,
    description: 'Duralast Platinum/Battery_BT',
    techNoteCode: 929780,
    lineCode: 'JCI',
    seoUrl:
      '/batteries-starting-and-chargingbsc/batterybt/duralast-platinum-battery_bt/319465_929780_18319',
    detailsAction: {
      contentPath: '/parts',
      '@class': 'com.endeca.infront.cartridge.model.RecordAction',
      siteRootPath: '/pages',
      siteState: null,
      label: null,
      recordState:
        '?A=PARTS%7Csku-319465..175-0.175-0.catalog10001.en__US%7C18319%7C929780%7C4468802%7C439916'
    },
    nonAppLabels: null,
    oemTechNote: null,
    imageUrl: null,
    overrideImgBlocking: true,
    '@class': 'com.autozone.catalog.dto.EndecaProductRecord',
    labeledProperties: {},
    recordType: 'app',
    itemIdentifierFlag: null,
    quickNoteCode: 18319,
    vdpAttributeValuesFromAQs: '',
    warrantyMonths: 0,
    application: '',
    oemInfo: null,
    systemCode: 0,
    repositoryId: '319465',
    vehicleFitmentLabel: 'VehicleSpecific Products',
    weightInPounds: 0,
    attributes: {},
    partNumber: '65-AGM',
    quickNote: 'Main and auxiliary',
    category: null,
    accessory: false,
    properties: []
  };
  const priceDetails = {
    preferredStoreNumber: '117',
    aZBadgesFlagVO: {
      eligibleForNextDay: false,
      '@class': 'com.autozone.diy.vo.AZBadgesFlagVO',
      dealAvailable: false,
      vehicleFit: false
    },
    '@class': 'com.autozone.diy.vo.AZCatalogShelfPageVO',
    catalogVehicleId: '',
    skuPricingAndAvailability: {
      lowestPrice: 0,
      corePriceAvailable: true,
      rebateUrl: null,
      vendorId: null,
      bopusStore: false,
      productLine: null,
      storePickupCSSClass: null,
      SRElegible: false,
      configurableSkuMessage: null,
      shipToHomeCSSClass: null,
      storePickupLabel: 'Store Pick Up',
      shipToHomeLabel: 'Ship To Home',
      skuId: '319465',
      highestPrice: 0,
      '@class': 'com.autozone.diy.commerce.pricing.AZPricingDealsInfo',
      onlineStockLabel: null,
      productId: null,
      rebatesAvaialble: false,
      shipToHomeStockLabel: 'Not Available',
      skuAddedTocart: false,
      storePickupAvailable: false,
      dealAvailable: false,
      skuUnavailable: false,
      storePickupStockLabel: 'Out of Stock',
      skuAvailabilityInfo: {
        unAvailableInStoreAndVdpStore: false,
        lowestPrice: null,
        unavailOnlineQoh: false,
        hubAvail: false,
        storeAvail: true,
        availableInOnline: false,
        webCorePrice: null,
        availableInVdpOnline: false,
        shippingAvailabilityMessage: null,
        availableInStore: true,
        storeTotalPrice: '209.99',
        orderByMessage: null,
        showSearchAnotherStoreLink: false,
        storeRetailPrice: '191.99',
        unAvailableInOnlineAndVdpOnline: true,
        unavailQoh: true,
        eligibleForNextDay: null,
        item: null,
        '@class': 'com.autozone.diy.valueobject.SKUAvailabilityPriceInfo',
        webRetailPrice: null,
        webTotalPrice: null,
        availableForDirectShipping: false,
        exceptionItem: false,
        storeCorePrice: '18.0',
        availableInVdpStore: false,
        messageCutOffTime: null,
        nextDayAvailableMessage: null,
        skuid: '319465'
      },
      estimatedDeliveryMessage: 'Not Available',
      shipToHomeAvailable: false,
      dealUrl: false,
      configurableSku: false,
      retailPrice: 191.99,
      categoryId: null,
      corePrice: 18
    },
    warranty: '3 years',
    azVehicleFitproductResponseVO: {
      '@class': 'com.autozone.diy.vo.AZVehicleFitProductResponseVO',
      vehicleDescription: null,
      vehicleFit: false,
      showYmme: true
    }
  };

  beforeEach(() => {
    addToCartCall = jest.fn();
    PROPS = {
      priceDetails,
      shelfPart,
      addToCartCall,
      stylesClass: {
        addplace: 'addplace',
        ship: 'ship',
        pickup: 'pickup',
        text: 'text',
        store: 'store',
        instock: 'instock',
        cart: 'cart'
      }
    };
  });

  test('renders components for successfull request', () => {
    const wrapper = mount(<PartCart {...PROPS} />);
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('renders components for successfull request', () => {
    const wrapper = mount(<PartCart {...PROPS} />);
    wrapper
      .find(Paper1)
      .at(0)
      .props()
      .onClick();
    expect(wrapper.state().activeStore).toBe(true);
    expect(wrapper.state().activeShip).toBe(false);
  });

  test('renders components for successfull request', () => {
    const wrapper = mount(<PartCart {...PROPS} />);
    wrapper
      .find(Paper1)
      .at(1)
      .props()
      .onClick();
    expect(wrapper.state().activeStore).toBe(false);
    expect(wrapper.state().activeShip).toBe(true);
  });

  test('renders components for successfull request', () => {
    const wrapper = mount(<PartCart {...PROPS} />);
    wrapper
      .find(Button)
      .props()
      .onClick();
    expect(addToCartCall.mock.calls.length).toBe(1);
  });

  test('renders components for successfull request', () => {
    const priceDetails = {
      preferredStoreNumber: '117',
      aZBadgesFlagVO: {
        eligibleForNextDay: false,
        '@class': 'com.autozone.diy.vo.AZBadgesFlagVO',
        dealAvailable: false,
        vehicleFit: false
      },
      '@class': 'com.autozone.diy.vo.AZCatalogShelfPageVO',
      catalogVehicleId: '',
      skuPricingAndAvailability: {
        lowestPrice: 0,
        corePriceAvailable: true,
        rebateUrl: null,
        vendorId: null,
        bopusStore: false,
        productLine: null,
        storePickupCSSClass: null,
        SRElegible: false,
        configurableSkuMessage: null,
        shipToHomeCSSClass: null,
        storePickupLabel: 'Store Pick Up',
        shipToHomeLabel: 'Ship To Home',
        skuId: '319465',
        highestPrice: 0,
        '@class': 'com.autozone.diy.commerce.pricing.AZPricingDealsInfo',
        onlineStockLabel: null,
        productId: null,
        rebatesAvaialble: false,
        shipToHomeStockLabel: 'Not Available',
        skuAddedTocart: false,
        storePickupAvailable: true,
        dealAvailable: false,
        skuUnavailable: false,
        storePickupStockLabel: 'Out of Stock',
        skuAvailabilityInfo: {
          unAvailableInStoreAndVdpStore: false,
          lowestPrice: null,
          unavailOnlineQoh: false,
          hubAvail: false,
          storeAvail: true,
          availableInOnline: false,
          webCorePrice: null,
          availableInVdpOnline: false,
          shippingAvailabilityMessage: null,
          availableInStore: true,
          storeTotalPrice: '209.99',
          orderByMessage: null,
          showSearchAnotherStoreLink: false,
          storeRetailPrice: '191.99',
          unAvailableInOnlineAndVdpOnline: true,
          unavailQoh: true,
          eligibleForNextDay: null,
          item: null,
          '@class': 'com.autozone.diy.valueobject.SKUAvailabilityPriceInfo',
          webRetailPrice: null,
          webTotalPrice: null,
          availableForDirectShipping: false,
          exceptionItem: false,
          storeCorePrice: '18.0',
          availableInVdpStore: false,
          messageCutOffTime: null,
          nextDayAvailableMessage: null,
          skuid: '319465'
        },
        estimatedDeliveryMessage: 'Not Available',
        shipToHomeAvailable: false,
        dealUrl: false,
        configurableSku: false,
        retailPrice: 191.99,
        categoryId: null,
        corePrice: 18
      },
      warranty: '3 years',
      azVehicleFitproductResponseVO: {
        '@class': 'com.autozone.diy.vo.AZVehicleFitProductResponseVO',
        vehicleDescription: null,
        vehicleFit: false,
        showYmme: true
      }
    };
    const wrapper = mount(<PartCart {...PROPS} />);
    wrapper
      .find(Button)
      .props()
      .onClick();
      wrapper.setProps({priceDetails})
    expect(addToCartCall.mock.calls.length).toBe(1);
  });

});


