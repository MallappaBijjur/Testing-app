/* @flow */

import React, { Component } from 'react';
import Paper from 'material-ui/Paper';
import { Button } from 'semantic-ui-react';
import type { Connector } from 'react-redux';
import { connect } from 'react-redux';
import styles from './styles.scss';
import * as shelfAction from '../../actions/shelf';
import type { Dispatch } from '../../types';

const style = {
  height: 58,
  width: '50%',
  textAlign: 'center',
  display: 'inline-block'
};

type Props = {
  stylesClass: Object,
  addToCartCall: (Object, Object, boolean) => void,
  priceDetails: any,
  shelfData: Object
};

type State = {
  activeStore: boolean,
  activeShip: boolean
};

export class PartCart extends Component<Props, State> {
  constructor(props) {
    super(props);
    this.state = {
      activeStore: true,
      activeShip: false
    };
  }

  setActiveClass(tog) {
    let storeFlag;
    let shipFlag;
    if (tog === 'store') {
      storeFlag = true;
      shipFlag = false;
    } else {
      storeFlag = false;
      shipFlag = true;
    }
    this.setState({
      activeStore: storeFlag,
      activeShip: shipFlag
    });
  }

  addToCart(priceDetails, shelfData, isStorePickUp) {
    this.props.addToCartCall(priceDetails, shelfData, isStorePickUp);
  }

  render() {
    const storeClass = this.state.activeStore ? styles.active : styles.inactive;
    const shipClass = this.state.activeShip ? styles.active : styles.inactive;
    const { priceDetails, shelfData } = this.props;
    const temp: any = priceDetails
      ? priceDetails.skuPricingAndAvailability
      : '';
    const pickUpStyle = temp.storePickupAvailable ? '' : styles.notAvailable;
    const shipStyle = temp.storePickupAvailable ? '' : styles.notAvailable;
    return (
      <div className={this.props.stylesClass.addplace}>
        <div className={this.props.stylesClass.ship}>
          <Paper
            className={this.props.stylesClass.pickup}
            style={style}
            zDepth={1}
            rounded={false}
            onClick={() => this.setActiveClass('store')}
          >
            <div className={`${this.props.stylesClass.text} ${storeClass}`}>
              <div className={this.props.stylesClass.store}>
                {temp.storePickupLabel}
              </div>
              <div
                className={`${this.props.stylesClass.instock} ${pickUpStyle}`}
              >
                {temp.storePickupStockLabel}
              </div>
            </div>
          </Paper>
          <Paper
            style={style}
            zDepth={1}
            rounded={false}
            onClick={() => this.setActiveClass('ship')}
          >
            <div className={`${this.props.stylesClass.text} ${shipClass}`}>
              <div className={this.props.stylesClass.store}>
                {temp.shipToHomeLabel}
              </div>
              <div className={`${this.props.stylesClass.instock} ${shipStyle}`}>
                {temp.shipToHomeStockLabel}
              </div>
            </div>
          </Paper>
        </div>
        <div className={this.props.stylesClass.cart}>
          <Button
            color="black"
            fluid
            onClick={() =>
              this.addToCart(priceDetails, shelfData, this.state.activeStore)
            }
          >
            ADD TO CART{' '}
          </Button>
        </div>
      </div>
    );
  }
}

/* istanbul ignore next */
const connector: Connector<{}> = connect(
  () => ({}),
  () => (dispatch: Dispatch) => ({
    addToCartCall: (priceDetails, shelfData, isStorePickUp) =>
      dispatch(
        shelfAction.addToCartCall(priceDetails, shelfData, isStorePickUp)
      )
  })
);

export default connector(PartCart);
