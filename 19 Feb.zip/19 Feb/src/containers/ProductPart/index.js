/* @flow */
import React from 'react';
import { connect } from 'react-redux';
import type { Connector } from 'react-redux';
import ProductImage from '../../components/ShelfPart/ProductImage';
import ProductLabel from '../../components/ShelfPart/ProductLabel';
import ProductPrice from '../../components/ShelfPart/ProductPrice';
import { PartCart } from './PartCart';
import AppInfo from '../../components/ShelfPart/AppInfo';
import styles from './styles.scss';
import type { ReduxState } from '../../types';

type Props = {
  isList: boolean,
  shelfPart: Object,
  price: Object
};

export class ProductPart extends React.Component<Props> {
  render() {
    const { isList, shelfPart, price } = this.props;
    const layout = isList ? styles.list : styles.product;
    const bobby = isList ? styles.prod : '';
    const shelfData = shelfPart || '';
    const skyId = shelfData.skuNumber;
    let currentPrice /* : Object */ = {};
    console.log('skyId', skyId);

    if (price && price.length > 0) {
      currentPrice = price.find(item => {
        console.log('item.skuPricingAndAvailability.skuId', item.skuPricingAndAvailability.skuId)
        if (skyId === parseInt(item.skuPricingAndAvailability.skuId, 10)) {
          currentPrice = item;
          return item;
        }
        return false;
      });
    }

    return (
      <div className={`${layout} ${styles.layoutmob}`}>
        <div className={styles.head}>
          <ProductLabel
            styles={styles}
            mobile
            shelfData={shelfData}
            price={currentPrice}
          />
        </div>
        <div className={isList ? styles.image : styles.mobileImage}>
          <div className={styles.mob}>
            <ProductImage
              styles={`${styles.partimage}`}
              list={isList}
              currentPrice={currentPrice}
              data={{
                productImageUrl: shelfData.productImageUrl,
                seoUrl: shelfData.seoUrl
              }}
            />
            {window.innerWidth < 1139 && (
              <div className={styles.mobile}>
                <ProductPrice
                  styles={styles}
                  list={isList}
                  price={currentPrice}
                />
                <div className={styles.part}>
                  {' '}
                  Part # {shelfData.partNumber}
                </div>
                {currentPrice &&
                  currentPrice.warranty && (
                    <a className={styles.warraty} href="/">
                      {currentPrice.warranty} Warranty
                    </a>
                  )}
                <div id={`BVRRInlineRating-${shelfData.skuNumber}`} />
              </div>
            )}
          </div>
        </div>
        {window.innerWidth > 1139 && (
          <div className={`${bobby} ${styles.desktop}`}>
            <ProductLabel
              styles={styles}
              shelfData={shelfData}
              price={currentPrice}
            />
            <div id={`BVRRInlineRating-${shelfData.skuNumber}`} />
            <AppInfo styles={styles} list={isList} shelfData={shelfData} />
          </div>
        )}
        <div className={isList ? styles.lastGrid : ''}>
          <div className={styles.desktop}>
            <ProductPrice styles={styles} list={isList} price={currentPrice} />
          </div>
          <PartCart
            stylesClass={styles}
            priceDetails={currentPrice}
            shelfData={shelfData}
          />
          {!isList && (
            <AppInfo styles={styles} list={!isList} shelfData={shelfData} />
          )}
        </div>
      </div>
    );
  }
}

/* istanbul ignore next */
const connector: Connector<{}> = connect(({ shelf }: ReduxState) => ({
  isList: shelf.isList,
  price: shelf.price
}));

export default connector(ProductPart);
