/* @flow */
import React, { PureComponent } from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import type { Connector } from 'react-redux';
import Drawer from 'material-ui/Drawer';
import Dialog from 'material-ui/Dialog';
import NavigationClose from 'material-ui/svg-icons/navigation/close';
import styles from './styles.scss';
import NavInfo from '../../components/NavTopInfo/NavInfo';
import Logo from '../../components/TopNav/Logo';
import SearchBox from '../../components/TopNav/SearchBox';
import Vehicle from '../../components/TopNav/Vehicle';
import Cart from '../../components/TopNav/Cart';
import Menu from '../../components/TopNav/Menu';
import NavBar from '../NavBar/NavBar';
import * as myAccountsAction from '../../actions/myAccountsAction';
import * as VehicleStyles from '../../containers/AddVehicle/YMMEDesktop.scss';
import type {
  myAccountData as myAccountDataType,
  Dispatch,
  ReduxState
} from '../../types';
import AddVehicle from '../AddVehicle';
import YMMEDesktop from '../AddVehicle/YMMEDesktop';
import * as ymmeActions from '../../actions/ymmeActions';
import AddedConfirmation from '../../components/YMME/AddedConfirmation';

type Props = {
  myAccountData: myAccountDataType,
  fetchYMMEYearList: void => {},
  addedVehicle: Object,
  yearList: Object,
  ymmeData: Object,
  fetchMyAccountsData: () => void
};

type State = {
  showYMME: boolean,
  showYMMEDesktop: boolean,
  showConfirmation: boolean
};

const customContentStyle = {
  width: '100%',
  maxWidth: 'none',
  minHeight: '300px'
};

class Header extends PureComponent<Props, State> {
  state = {
    showYMME: false,
    showYMMEDesktop: false,
    showConfirmation: true
  };

  componentDidMount() {
    this.props.fetchMyAccountsData();
  }

  handleClose = () => {
    this.setState({ showYMMEDesktop: !this.state.showYMMEDesktop });
  };

  toggleYMME = () => {
    this.props.fetchYMMEYearList();
    this.setState({ showYMME: !this.state.showYMME });
  };

  toggleYMMEDesktop = () => {
    this.props.fetchYMMEYearList();
    this.setState({ showYMMEDesktop: !this.state.showYMMEDesktop });
  };
  clickHandler = () => {
    this.setState({ showConfirmation: false });
  };
  shopWithoutVehicleHandle = () => {
    window.location.reload();
  };

  vehicalConfirmation() {
    const { addedVehicle } = this.props;
    const { showConfirmation } = this.state;
    if (addedVehicle) {
      return showConfirmation ? (
        <AddedConfirmation
          message={addedVehicle}
          toggleYMME={this.toggleYMME}
          toggleYMMEDesktop={this.toggleYMMEDesktop}
          showConfirmation={this.state.showConfirmation}
          closeHandler={this.clickHandler}
          shopWithoutVehicle={this.shopWithoutVehicleHandle}
        />
      ) : null;
    }
    return false;
  }

  renderAddVehicle() {
    const { yearList } = this.props;
    if (yearList !== undefined) {
      return (
        <Drawer
          width="100%"
          openSecondary
          open={this.state.showYMME}
          className="YMMEModal"
        >
          <AddVehicle yearList={yearList} toggleYMME={this.toggleYMME} />
        </Drawer>
      );
    }
    return null;
  }

  renderAccount() {
    const { myAccountData, addedVehicle } = this.props;

    let vehicleText = 'ADD A VEHICLE';
    if (addedVehicle) {
      vehicleText = addedVehicle.vehicleDisplayName;
    }

    if (myAccountData.readyStatus === 'MYACCOUNTS_SUCCESS') {
      return (
        <div className={styles.App}>
          <div className={styles.appNavigation}>
            <NavInfo
              myAccountTitles={
                myAccountData.list.contents[0].header.myAccountMap
              }
              styles={styles}
            />
            <div className={styles.rowAuto}>
              <Link to="/home">
                <Logo styles={styles} />
              </Link>
              <SearchBox styles={styles} viewType="desktop" />
              <div className={styles.addInfo}>
                <Vehicle
                  vehicleText={vehicleText}
                  addedVehicle={addedVehicle}
                  styles={styles}
                  toggleYMME={this.toggleYMME}
                  toggleYMMEDesktop={this.toggleYMMEDesktop}
                />
                <Cart styles={styles} />
                <Menu
                  menuItems={
                    myAccountData.list.contents[0].header.navItemTOList
                  }
                  myAccountTitles={
                    myAccountData.list.contents[0].header.myAccountMap
                  }
                  styles={styles}
                />
              </div>
            </div>
            <div className={styles.searchMobile}>
              <SearchBox styles={styles} viewType="mobile" />
            </div>
            <NavBar styles={styles} />
          </div>
        </div>
      );
    }
    return false;
  }

  renderYMMEDesktop() {
    const { ymmeData } = this.props;
    if (ymmeData) {
      return (
        <Dialog
          modal
          contentStyle={customContentStyle}
          bodyClassName={VehicleStyles.dialogBodyClass}
          contentClassName="dialogContentCls"
          open={this.state.showYMMEDesktop}
          repositionOnUpdate
        >
          <NavigationClose
            onClick={this.handleClose}
            className={VehicleStyles.vehicleCloseBtn}
          />
          <YMMEDesktop data={ymmeData.data} handleClose={this.handleClose} />
        </Dialog>
      );
    }
    return null;
  }

  render() {
    const { showYMMEDesktop } = this.state;
    return (
      <div className={styles.App}>
        {this.renderAccount()}
        {this.renderAddVehicle()}
        {this.vehicalConfirmation()}
        {showYMMEDesktop && this.renderYMMEDesktop()}
      </div>
    );
  }
}

const connector: Connector<{}, Props> = connect(
  ({ myAccountData, ymmeData }: ReduxState) => ({
    myAccountData,
    ymmeData,
    yearList: ymmeData ? ymmeData.data.yearList : '',
    addedVehicle: ymmeData ? ymmeData.data.addedVehicle : ''
  }),
  (dispatch: Dispatch) => ({
    fetchMyAccountsData: () => dispatch(myAccountsAction.fetchMyAccountsData()),
    fetchYMMEYearList: () => dispatch(ymmeActions.fetchYMMEYearList())
  })
);

export default connector(Header);
