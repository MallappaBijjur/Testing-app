/* @flow */
import React, { PureComponent } from 'react';
import { Connector, connect } from 'react-redux';
import Header from '../Header';
import HeroComponentStack from './HeroComponentStack';
import SplitContentBlock from './SplitContentBlock';
import type {
  HeroContentData as HeroContentDataType,
  SplitContentData as SplitContentDataType,
  Dispatch,
  ReduxState
} from '../../types';
import * as heroContent from '../../actions/heroContent';
import * as splitContent from '../../actions/splitContent';

type Props = {
  heroContentData: HeroContentDataType,
  splitContentData: SplitContentDataType,
  fetchHeroContentData: () => void,
  fetchHeroContentData1: () => void
};

export class MainContentBlock extends PureComponent<Props> {
  componentDidMount() {
    this.props.fetchHeroContentData();
    this.props.fetchHeroContentData1();
  }

  renderHeroContent = () => {
    const { heroContentData } = this.props;
    if (heroContentData.readyStatus === 'HERO_SUCCESS') {
      return <HeroComponentStack data={heroContentData} />;
    }
    return <div>Loading..</div>;
  };

  renderSplitContent = () => {
    const { splitContentData } = this.props;
    if (splitContentData.readyStatus === 'SPLIT_SUCCESS') {
      return (
        <SplitContentBlock
          blockItemData={
            splitContentData.viewInfo.contents[0].mainContent[0].contentList[0]
          }
        />
      );
    }
    return <div>Loading..</div>;
  };

  render() {
    return (
      <div>
        <Header />
        <div>{this.renderHeroContent()}</div>
        <div>{this.renderSplitContent()}</div>
      </div>
    );
  }
}

const connector: Connector<{}, Props> = connect(
  ({ heroContentData, splitContentData }: ReduxState) => ({
    heroContentData,
    splitContentData
  }),
  (dispatch: Dispatch) => ({
    fetchHeroContentData: () => dispatch(heroContent.fetchHeroContentData()),
    fetchHeroContentData1: () => dispatch(splitContent.fetchHeroContentData1())
  })
);
export default connector(MainContentBlock);
