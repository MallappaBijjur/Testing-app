/* @flow */

import React, { PureComponent } from 'react';

type Props = {
  slideCount: number,
  slidesToScroll: number,
  currentSlide: number,
  goToSlide: any => void
};
class OverrideCarousel extends PureComponent<Props> {
  getIndexes = (count: number, inc: number) => {
    const arr = [];
    for (let i = 0; i < count; i += inc) {
      arr.push(i);
    }
    return arr;
  };

  getListStyles = () => ({
    margin: 0,
    top: '1.3em',
    padding: 0
  });

  getListItemStyles = () => ({
    listStyleType: 'none',
    display: 'inline-block'
  });

  getButtonStyles = (active: boolean) => ({
    border: active ? '1px' : 0,
    background: 'transparent',
    color: active ? '#000' : '#ababab',
    cursor: 'pointer',
    padding: '0.3em',
    outline: 0,
    fontSize: '3em',
    opacity: 1,
    top: '0.7em'
  });

  render() {
    const indexes = this.getIndexes(
      this.props.slideCount,
      this.props.slidesToScroll
    );
    return (
      <ul style={this.getListStyles()}>
        {indexes.map(index => (
          <li style={this.getListItemStyles()} key={index}>
            <button
              style={this.getButtonStyles(this.props.currentSlide === index)}
              key={`button_, ${index}!`}
              onClick={evt => {
                evt.preventDefault();
                this.props.goToSlide(index);
              }}
            >
              &bull;
            </button>
          </li>
        ))}
      </ul>
    );
  }
}

const overrideDecorators = [
  {
    component: OverrideCarousel,
    position: 'BottomCenter'
  }
];

export default overrideDecorators;
