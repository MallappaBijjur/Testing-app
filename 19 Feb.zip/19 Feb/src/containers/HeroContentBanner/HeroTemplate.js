/* @flow */
import React, { PureComponent } from 'react';
import homepageStyles from './styles.scss';
import { imageServer } from '../../config/serviceAPI';

type Props = {
  blockItem: Object
};

export default class HeroAdTempalte extends PureComponent<Props> {
  //  const buttonHide = !main.CTAName2 && !main.CTAName2 ? homepageStyles.display_none: '';
  renderHeroView = (main: any) => (
    <div className={homepageStyles.display_prop}>
      {main.LayoutCode === 'Full-Left-H1H2C3' && (
        <div className={`col ${homepageStyles.mobTopContent}`}>
          <img
            alt="Img_left"
            className={homepageStyles.carousel_itemImg}
            src={`${imageServer}${main.ForeGroundImage}`}
          />
        </div>
      )}
      {main.LayoutCode === 'Full-Center' && (
        <div className={`col ${homepageStyles.heroContentCenter}`}>
          <div className={homepageStyles.carousel_heading1}>
            <h1 className={homepageStyles.textCenter}>{main.Headline1}</h1>
            <p>{main.Headline2}</p>
          </div>
          <span className={homepageStyles.barStyle} />
          <div className="col">
            {main.CTAName1 && (
              <a
                className={`btn white ${homepageStyles.style2}`}
                href={main.CTALink1}
              >
                {main.CTAName1}
              </a>
            )}
            {main.CTAName2 && (
              <a
                className={`btn transparent ${homepageStyles.style1}`}
                href={main.CTALink2}
              >
                {main.CTAName2}
              </a>
            )}
          </div>
          <div className="col">
            {main.CTAName4 && (
              <a
                className={homepageStyles.carousel_details}
                href={main.CTALink4}
              >
                {main.CTAName4}
              </a>
            )}
          </div>
        </div>
      )}
      {main.LayoutCode === 'Full-Left-H1H2C3' && (
        <div>
          <div className={homepageStyles.right_barstyle_text}>
            <p>{main.Headline1}</p>
            <span className={homepageStyles.barStyle1} />
          </div>
          <div className={`col ${homepageStyles.heroContentLeft}`}>
            <div className={homepageStyles.carousel_headingLt}>
              <h1>{main.Headline1}</h1>
              <p>{main.Headline2}</p>
            </div>
            <div className={homepageStyles.button_content_mob}>
              <span className={homepageStyles.barStyle} />
              <div className="col">
                {main.CTAName1 && (
                  <a
                    className={`btn black ${homepageStyles.style2Left}`}
                    href={main.CTALink1}
                  >
                    {main.CTAName1}
                  </a>
                )}
                {main.CTAName2 && (
                  <a
                    className={`btn transparent ${homepageStyles.style1Left}`}
                    href={main.CTALink2}
                  >
                    {main.CTAName2}
                  </a>
                )}
              </div>
              <div className="col">
                {main.CTAName4 && (
                  <a
                    className={homepageStyles.carousel_detailsLeft}
                    href={main.CTALink4}
                  >
                    {main.CTAName4}
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
      {main.LayoutCode === 'Full-Right-H1C3' && (
        <div>
          <div className={homepageStyles.left_barstyle_text}>
            <p>{main.Headline1}</p>
            <span className={homepageStyles.barStyle1} />
          </div>
          <div className={`col s6 ${homepageStyles.caroright}`}>
            <div>
              <h1 className={homepageStyles.RightmarginLeft}>
                {main.Headline1}
              </h1>
              <div className={homepageStyles.carousel_headingRight}>
                {main.Headline2}
              </div>
            </div>
            <div className={homepageStyles.button_content_mob}>
              <span className={homepageStyles.barStyleRight} />
              <div className={`col ${homepageStyles.btnmargin}`}>
                {main.CTAName1 && (
                  <a
                    className={`btn white ${homepageStyles.style2}`}
                    href={main.CTALink1}
                  >
                    {main.CTAName1}
                  </a>
                )}
                {main.CTAName2 && (
                  <a
                    className={`btn black ${homepageStyles.style3}`}
                    href={main.CTALink2}
                  >
                    {main.CTAName2}
                  </a>
                )}
              </div>
              <div className={`col ${homepageStyles.btnmargin}`}>
                {main.CTAName4 && (
                  <a
                    className={homepageStyles.carousel_details_right}
                    href={main.CTALink4}
                  >
                    {main.CTAName4}
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
      {main.LayoutCode === 'Full-Right-H2C3' && (
        <div>
          <div className={homepageStyles.left_barstyle_text_hc}>
            <p>{main.Headline1}</p>
            <span className={homepageStyles.barStyle1} />
          </div>
          <div className={`col s6 ${homepageStyles.caroright_hc}`}>
            <div>
              <h1 className={homepageStyles.RightmarginLeft}>
                {main.Headline1}
              </h1>
              <div className={homepageStyles.carousel_headingRight}>
                {main.Headline2}
              </div>
            </div>
            <div className={homepageStyles.button_content_mob}>
              <span className={homepageStyles.barStyleRight} />
              <div className={`col ${homepageStyles.btnmargin}`}>
                {main.CTAName1 && (
                  <a
                    className={`btn white ${homepageStyles.style2}`}
                    href={main.CTALink1}
                  >
                    {main.CTAName1}
                  </a>
                )}
                {main.CTAName2 && (
                  <a
                    className={`btn black ${homepageStyles.style3}`}
                    href={main.CTALink2}
                  >
                    {main.CTAName2}
                  </a>
                )}
              </div>
              <div className={`col ${homepageStyles.btnmargin}`}>
                {main.CTAName4 && (
                  <a
                    className={homepageStyles.carousel_details_right}
                    href={main.CTALink4}
                  >
                    {main.CTAName4}
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
      {main.LayoutCode === 'Full-Right-H1C3' && (
        <div className={`col s5 ${homepageStyles.imgheight}`}>
          <img
            alt="Right_img"
            className={homepageStyles.carousel_itemImg}
            src={`${imageServer}${main.ForeGroundImage}`}
          />
        </div>
      )}

      {main.LayoutCode === 'Full-Right-H2C3' && (
        <div className={`col s5 ${homepageStyles.imgheight}`}>
          <img
            alt="Right_img"
            className={homepageStyles.carousel_itemImg_hc}
            src={`${imageServer}${main.ForeGroundImage}`}
          />
        </div>
      )}
    </div>
  );

  render() {
    const { blockItem } = this.props;
    const bgimg = blockItem && `${imageServer}${blockItem.BackGroundImage}`;
    const bannerStyle = {
      backgroundImage: `url(${bgimg})`,
      backgroundRepeat: 'no-repeat',
      backgroundSize: 'cover'
    };
    return (
      <div style={bannerStyle} className={homepageStyles.banner_content}>
        <div className="col carousel_item_dark">
          <div className={homepageStyles.content_part_desk}>
            {this.renderHeroView(blockItem)}
          </div>
        </div>
      </div>
    );
  }
}
