import React from 'react';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
import { MuiThemeProvider } from 'material-ui/styles';
import { mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import HeroAdTempalte from '../HeroTemplate';

describe('<HeroAdTempalte />', () => {
  let PROPS = {};
  let mockData = null;
  beforeEach(() => {
    mockData = {
      _links: {
        'oc:createAccountPage': {
          method: 'GET',
          href: 'http://dv-camaro1-xl07:8289/autozone/v1/page/homePage'
        },
        curies: [
          {
            templated: true,
            name: 'oc',
            href: '/rels/{rel}'
          }
        ]
      },
      LayoutCode: 'Full-Right',
      ForeGroundImage:
        'https://dv-camaro1-xl07.autozone.com/images/MEDIA_ProductCatalog/m3210022_FY14-P11-Get-Parts-Get-Help_FT_vme_v2.jpg',
      CTALink1:
        'https://www.autozone.com/brakes-and-traction-control/brake-pads',
      Headline2: 'Headline2',
      Headline1:
        'AUTOZONE BRAKE PADS - SAVE TIME BY BUYING ONLINE AND PICKING UP IN STORE',
      CTAName4: 'Terms & Conditions',
      CTAName1: 'View Info',
      CTAName2: 'Pick Info',
      BackGroundImage:
        'https://dv-camaro1-xl07.autozone.com/images/MEDIA_ProductCatalog/LightTextureExample.jpg',
      CTALink2:
        'https://www.autozone.com/landing/page.jsp?name=buy_online_pickup_in_store',
      CTALink4: 'https://www.autozone.com/inourstores/rebates.jsp'
    };
    PROPS = {
      blockItem: jest.fn(),
      data: mockData
    };
  });

  test('renders correctly', () => {
    const store = createStore(() => ({}));
    const wrapper = mount(
      <Provider store={store}>
        <MuiThemeProvider>
          <HeroAdTempalte {...PROPS} />
        </MuiThemeProvider>
      </Provider>
    );
    expect(toJson(wrapper)).toMatchSnapshot();
  });
});
