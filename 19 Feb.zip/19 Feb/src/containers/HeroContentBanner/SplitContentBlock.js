/* @flow */
import React, { PureComponent } from 'react';
import homepageStyles from './styles.scss';
import { imageServer } from '../../config/serviceAPI';

export default class SplitContentBlock extends PureComponent<{}> {
  rightArrowSVG = () => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="12"
      height="7"
      viewBox="0 0 12 7"
    >
      <path
        fill="#F38021"
        fillRule="evenodd"
        d="M7.525 5.849l1.034 1.033L12 3.442 8.559 0 7.525 1.034 9.201 2.71H0v1.462h9.201z"
      />
    </svg>
  );
  renderSplitView = (val: any) => {
    const valuesplit = val.blockItemData.Split1;
    const valuesplit1 = val.blockItemData.Split2;
    const valuesplit2 = val.blockItemData.Split3;
    const value1 = valuesplit && valuesplit.LayoutCode;
    const value2 = valuesplit1 && valuesplit1.LayoutCode;
    const value3 = valuesplit2 && valuesplit2.LayoutCode;

    return (
      <div className={homepageStyles.splitblockcontainer2}>
        {value1 === '1R2C' && (
          <div
            className={homepageStyles.splitblock1}
            style={{
              backgroundImage: `url(${imageServer}${valuesplit.ImagePath})`,
              backgroundRepeat: 'no-repeat',
              backgroundSize: 'cover'
            }}
          >
            <div className={homepageStyles.split1_content}>
              <p className={homepageStyles.split1_para}>
                {valuesplit.OverallHeadline}
              </p>
              <p className={homepageStyles.split1_ptag}>{valuesplit.CTAText}</p>
              <p className={homepageStyles.split1_pname}>
                <a href={valuesplit.CTAURL}>{valuesplit.CTAName}</a>{' '}
                {this.rightArrowSVG()}
              </p>
            </div>
          </div>
        )}

        {value2 === '1R3C' && (
          <div
            className={homepageStyles.splitblock1}
            style={{
              backgroundImage: `url(${imageServer}${valuesplit1.ImagePath})`,
              backgroundRepeat: 'no-repeat',
              backgroundSize: 'cover'
            }}
          >
            <div className={homepageStyles.split1_content}>
              <p className={homepageStyles.split1_para}>
                {valuesplit1.OverallHeadline}
              </p>
              <p className={homepageStyles.split1_ptag}>
                {valuesplit1.CTAText}
              </p>
              <p className={homepageStyles.split1_pname}>
                <a href={valuesplit1.CTAURL}>{valuesplit1.CTAName}</a>{' '}
                {this.rightArrowSVG()}
              </p>
            </div>
          </div>
        )}

        {value3 === 'code3' && (
          <div
            className={homepageStyles.splitblock1}
            style={{
              backgroundImage: `url(${imageServer}${valuesplit2.ImagePath})`,
              backgroundRepeat: 'no-repeat',
              backgroundSize: 'cover'
            }}
          >
            <div className={homepageStyles.split3_content}>
              <p className={homepageStyles.split1_para}>
                {valuesplit2.OverallHeadline}
              </p>
              <p className={homepageStyles.split1_ptag}>
                {valuesplit2.CTAText}
              </p>
              <p className={homepageStyles.split1_pname}>
                <a href={valuesplit2.CTAURL}>{valuesplit2.CTAName}</a>{' '}
                {this.rightArrowSVG()}
              </p>
            </div>
          </div>
        )}
      </div>
    );
  };

  render() {
    return <div>{this.renderSplitView(this.props)}</div>;
  }
}
