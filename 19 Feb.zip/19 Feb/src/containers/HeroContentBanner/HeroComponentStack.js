/* @flow */
import React, { PureComponent } from 'react';
import Carousal from 'nuka-carousel';
import carousalDecorators from './carousalDecorators';
import HeroAdTempalte from './HeroTemplate';
import homepageStyles from './styles.scss';

type Props = {
  data: Object
};

type State = {
  data: any
};

class HeroComponentStack extends PureComponent<Props, State> {
  constructor(props: any) {
    super(props);
    this.state = {
      data: []
    };
  }
  componentWillMount() {
    const { mainContent } = this.props.data.viewInfo.contents[0];
    this.setState({
      data: mainContent
    });
  }

  render() {
    return (
      <div className={homepageStyles.hero_banners}>
        {this.state.data.map(rowItem => {
          if (rowItem[`@type`] && rowItem[`@type`] === 'HeroContentBlock') {
            return (
              <div
                className={homepageStyles.carousel_content}
                key={rowItem[`@type`]}
              >
                <Carousal
                  decorators={carousalDecorators}
                  autoplay={
                    Object.keys(rowItem.ProductLinkList.list[0]).length > 1
                  }
                  wrapAround
                  autoplayInterval={7000}
                >
                  {Object.keys(rowItem.ProductLinkList.list[0]).map(colItem => (
                    <HeroAdTempalte
                      blockItem={rowItem.ProductLinkList.list[0][colItem]}
                      key={colItem}
                    />
                  ))}
                </Carousal>
              </div>
            );
          }
          return false;
        })}
      </div>
    );
  }
}
export default HeroComponentStack;
