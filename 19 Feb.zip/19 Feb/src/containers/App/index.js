/* @flow */

import React from 'react';
import Helmet from 'react-helmet';
import config from '../../config';
import styles from './styles.scss';
// Import your global styles here
import '../../theme/normalize.css';

type Props = {
  children: any
};

const App = (props: Props): any => (
  <div className={styles.App}>
    <Helmet {...config.app} />
    <div>{props.children}</div>
  </div>
);

export default App;
