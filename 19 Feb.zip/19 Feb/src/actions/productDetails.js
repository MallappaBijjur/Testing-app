/* @flow */
import type { Dispatch, GetState, ThunkAction } from '../types';
import azURL from '../config/serviceAPI';

const API_URL_PRODUCT = azURL('pdpPageDetails');
const URL_ADD_TO_CART = azURL('commerceItems');

export const fetchProductData = (
  axios: any,
  seoUrl: string,
  URL: string = API_URL_PRODUCT
): ThunkAction => async (dispatch: Dispatch) => {
  try {
    const response = await axios.get(`${URL}${seoUrl}`); // backend
    dispatch({ type: 'PRODUCT_SUCCESS', data: response.data });
  } catch (err) {
    dispatch({ type: 'PRODUCT_FAILURE', err: err.message });
  }
};

export const fetchProductAllData = (seoUrl: string): ThunkAction => (
  dispatch: Dispatch,
  getState: GetState,
  axios: any
) => dispatch(fetchProductData(axios, seoUrl));

const addToCartRequest = (
  axios: any,
  forPostData: any,
  URL: string = URL_ADD_TO_CART
): ThunkAction => async (dispatch: Dispatch) => {
  try {
    const values = {
      catalogRefId: forPostData.catalogRefId
        ? `${forPostData.catalogRefId}`
        : '',
      productId: forPostData.productId || '177-0',
      quantity: forPostData.quantity,
      product: {
        id: forPostData.productId || '177-0',
        type: forPostData.type ? `${forPostData.type}` : ''
      },
      sku: {
        id: forPostData.skuNumber ? `${forPostData.skuNumber}` : ''
      },
      otherOptions: {
        sendToStore: forPostData.sendToStore
          ? `${forPostData.sendToStore}`
          : '',
        mobileApp: forPostData.mobileApp ? `${forPostData.mobileApp}` : '',
        oemPartNumber: forPostData.oemPartNumber
          ? `${forPostData.oemPartNumber}`
          : '',
        catalogVehicleId: forPostData.catalogVehicleId
          ? `${forPostData.catalogVehicleId}`
          : '',
        categoryId: forPostData.categoryId ? `${forPostData.categoryId}` : '',
        itemIdentifier: forPostData.itemIdentifier
          ? `${forPostData.itemIdentifier}`
          : '',
        storeNumber: forPostData.storeNumber ? `${forPostData.storeNumber}` : ''
      }
    };
    const response = await axios.post(URL, values);
    console.log('ADD_TO_CART_SUCCESS');
    console.log('Add to cart data', response.data);
    dispatch({ type: 'ADD_TO_CART_SUCCESS', data: response.data });
  } catch (err) {
    dispatch({ type: 'ADD_TO_CART_FAILURE', err: err.message });
  }
};

export const addToCartCall = (forPostData: Object): ThunkAction => (
  dispatch: Dispatch,
  getState: GetState,
  axios: any
) => dispatch(addToCartRequest(axios, forPostData));
