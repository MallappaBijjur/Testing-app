/* @flow */

import type { Dispatch, GetState, ThunkAction, ReduxState } from '../types';

const API_URL = 'https://api.myjson.com/bins/6p2dp';
// const API_URL = 'https://api.myjson.com/bins/1garar';

// const ROOT_URL = 'autozone/v1/page';

// Export this for unit testing more easily
export const fetchPageData = (
  axios: any,
  URL: string = API_URL
): ThunkAction => async (dispatch: Dispatch) => {
  dispatch({ type: 'CREATE_REQUESTING' });

  try {
    const response = await axios.get(URL); // backend
    dispatch({ type: 'CREATE_SUCCESS', data: response.data });
  } catch (err) {
    dispatch({ type: 'CREATE_FAILURE', err: err.message });
  }
};

// Preventing dobule fetching data
/* istanbul ignore next */
const shouldFetchViewForm = (state: ReduxState): boolean => {
  // In development, we will allow action dispatching
  // or your reducer hot reloading won't updated on the view
  if (__DEV__) return true;

  if (state.home.readyStatus === 'CREATE_SUCCESS') return false; // Preventing double fetching data

  return true;
};

export const fetchCreateAccountData = /* istanbul ignore next */ (): ThunkAction => (
  dispatch: Dispatch,
  getState: GetState,
  axios: any
) => {
  /* istanbul ignore next */
  if (shouldFetchViewForm(getState())) {
    /* istanbul ignore next */
    return dispatch(fetchPageData(axios));
  }

  /* istanbul ignore next */
  return null;
};
