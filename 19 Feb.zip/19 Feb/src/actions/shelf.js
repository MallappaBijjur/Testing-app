/* @flow */
import type { Dispatch, GetState, ThunkAction } from '../types';
import azURL from '../config/serviceAPI';

const BASE_URL = azURL('getCatData');
const API_URL_PRICE = azURL('shelfPageDetails');

export const fetchPartsData = (
  axios: any,
  newPath: any,
  URL: string = BASE_URL,
  PRICE_URL: string = API_URL_PRICE
): ThunkAction => async (dispatch: Dispatch) => {
  dispatch({ type: 'PARTS_REQUESTING' });
  try {
    const response = await axios.get(`${URL}${newPath}`);
    if (response.status === 200) {
      try {
        const skuIds = [];
        if (response.data.azshelfPageRecordsVO.recordsList) {
          response.data.azshelfPageRecordsVO.recordsList.map(item =>
            skuIds.push(item.skuNumber)
          );
        }
        const priceResponse = await axios.get(
          `${PRICE_URL}/${skuIds.toString()}`
        );
        console.log(priceResponse.data);
        dispatch({
          type: 'PRICE_SUCCESS',
          data: priceResponse.data.atgResponse,
          skuIds
        });
      } catch (err) {
        dispatch({ type: 'PRICE_FAILURE', err: err.message });
      }
      dispatch({ type: 'PARTS_SUCCESS', data: response.data });
    }
  } catch (err) {
    dispatch({ type: 'PARTS_FAILURE', err: err.message });
  }
};

const URL_ADD_TO_CART = azURL('commerceItems');

const AddTocart = (
  axios: any,
  priceDetails: any,
  shelfData: any,
  isStorePickUp: any,
  URL: string = URL_ADD_TO_CART
): ThunkAction => async (dispatch: Dispatch) => {
  try {
    const values = {
      catalogRefId: shelfData.repositoryId,
      productId: shelfData.productRepositoryId,
      quantity: 1,
      product: {
        id: shelfData.productRepositoryId,
        type: shelfData.vehiclSpecific ? '00' : '01'
      },
      sku: {
        id: `${shelfData.skuNumber}`
      },
      otherOptions: {
        sendToStore: `${isStorePickUp}`,
        mobileApp: true,
        oemPartNumber: shelfData.oemPartNumber ? shelfData.oemPartNumber : '',
        catalogVehicleId: '2720802',
        categoryId: shelfData.productRepositoryId,
        itemIdentifier: shelfData.itemIdentifier,
        storeNumber: priceDetails.preferredStoreNumber
      }
    };
    const response = await axios.post(URL, values);
    console.log('ADD_TO_CART_SUCCESS', response.statusText);
    dispatch({ type: 'ADD_TO_CART_SUCCESS', data: response.data });
  } catch (err) {
    console.log('errr', err.message);
    dispatch({ type: 'ADD_TO_CART_FAILURE', err: err.message });
  }
};

export const setView = (view: any) => (dispatch: Dispatch) =>
  dispatch({ type: 'SET_VIEW', view });

export const getPartDetails = (newPath: string): ThunkAction => (
  dispatch: Dispatch,
  getState: GetState,
  axios: any
) => dispatch(fetchPartsData(axios, newPath));

export const addToCartCall = (
  priceDetails: any,
  shelfData: any,
  isStorePickUp: any
): ThunkAction => (dispatch: Dispatch, getState: GetState, axios: any) =>
  dispatch(AddTocart(axios, priceDetails, shelfData, isStorePickUp));
