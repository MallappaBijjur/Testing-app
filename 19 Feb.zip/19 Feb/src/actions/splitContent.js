/* @flow */
import type { Dispatch, GetState, ThunkAction, ReduxState } from '../types';
import azURL from '../config/serviceAPI';

const API_URL = azURL('splitContent');

// Export this for unit testing more easily
export const fetchPageData = (
  axios: any,
  URL: string = API_URL
): ThunkAction => async (dispatch: Dispatch) => {
  dispatch({ type: 'SPLIT_REQUESTING' });

  try {
    const response = await axios.get(URL); // backend
    dispatch({ type: 'SPLIT_SUCCESS', data: response.data });
  } catch (err) {
    dispatch({ type: 'SPLIT_FAILURE', err: err.message });
  }
};

const shouldFetchViewForm = (state: ReduxState): boolean => {
  if (__DEV__) return true;

  if (state.home.readyStatus === 'SPLIT_SUCCESS') return false;

  return true;
};

/* istanbul ignore next */
export const fetchHeroContentData1 = (): ThunkAction => (
  dispatch: Dispatch,
  getState: GetState,
  axios: any
) => {
  if (shouldFetchViewForm(getState())) {
    return dispatch(fetchPageData(axios));
  }

  /* istanbul ignore next */
  return null;
};
