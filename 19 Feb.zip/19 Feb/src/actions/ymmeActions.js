/* @flow */
import type { Dispatch, GetState, ThunkAction } from '../types';
import azURL from '../config/serviceAPI';

const API_URL = azURL('ymme');

// Export this for unit testing more easily
export const fetchYMMEAPI = (
  axios: any,
  year: any,
  data: any,
  type: any,
  URL: string = API_URL
): ThunkAction => async (dispatch: Dispatch) => {
  dispatch({ type: 'YMME_REQUESTING' });

  try {
    let YMME_URL = `${URL}`;
    let response;
    if (type === 'GET_MAKE') {
      YMME_URL = `${URL}/getMakesData/${data.year}`;
      response = await axios.get(YMME_URL);
      dispatch({ type: 'YMME_MAKE_SUCCESS', data: response.data.atgResponse });
    } else if (type === 'GET_MODEL') {
      YMME_URL = `${URL}/getModelData/${year}/${data.make}/${data.makeId}`;
      response = await axios.get(YMME_URL);
      dispatch({ type: 'YMME_MODEL_SUCCESS', data: response.data.atgResponse });
      if (response.data.atgResponse.length === 1) {
        YMME_URL = `${URL}/getEnginesData/${
          response.data.atgResponse[0].modelId
        }`;
        response = await axios.get(YMME_URL);
        dispatch({
          type: 'YMME_ENGINE_SUCCESS',
          data: response.data.atgResponse
        });
      }
    } else if (type === 'GET_ENGINE') {
      YMME_URL = `${URL}/getEnginesData/${data.modelId}`;
      response = await axios.get(YMME_URL);
      dispatch({
        type: 'YMME_ENGINE_SUCCESS',
        data: response.data.atgResponse
      });
    } else if (type === 'GET_YEAR') {
      YMME_URL = `${URL}/getYearsData`;
      response = await axios.get(YMME_URL);
      dispatch({ type: 'YMME_YEAR_SUCCESS', data: response.data.atgResponse });
    }
  } catch (err) {
    dispatch({ type: 'YMME_FAILURE', err: err.message });
  }
};

// Export this for unit testing more easily
export const fetchYMMEVehicle = (
  axios: any,
  data: any,
  type: any,
  URL: string = API_URL
): ThunkAction => async (dispatch: Dispatch) => {
  dispatch({ type: 'YMME_REQUESTING' });
  try {
    let YMME_URL = `${URL}`;
    if (type === 'ADD_VEHICLE') {
      YMME_URL = `${URL}/addVehicle?engineID=${data.engineId}`;
      const res = await axios.post(YMME_URL, '', {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      });
      dispatch({ type: 'YMME_ADD_VEHICLE_SUCCESS', data: res.data });
      dispatch({ type: 'YMME_VEHICLE_LIST_SUCCESS', data: res.data });
    } else if (type === 'REMOVE_VEHICLE') {
      YMME_URL = `${URL}/removeDefaultVehicle`;
      const res = await axios.get(YMME_URL);
      dispatch({ type: 'YMME_REMOVE_VEHICLE_SUCCESS', data: res.data });
    } else if (type === 'VEHICLE_LIST') {
      YMME_URL = `${URL}/vehicleList`;
      const res = await axios.get(YMME_URL);
      dispatch({ type: 'YMME_VEHICLE_LIST_SUCCESS', data: res.data });
    }
  } catch (err) {
    dispatch({ type: 'YMME_FAILURE', err: err.message });
  }
};

/* istanbul ignore next */
export const fetchYMMEYearList = (): ThunkAction => (
  dispatch: Dispatch,
  getState: GetState,
  axios: any
) => dispatch(fetchYMMEAPI(axios, '', '', 'GET_YEAR'));

/* istanbul ignore next */
export const fetchYMMEMakeList = (data: any): ThunkAction => (
  dispatch: Dispatch,
  getState: GetState,
  axios: any
) => dispatch(fetchYMMEAPI(axios, '', data, 'GET_MAKE'));

/* istanbul ignore next */
export const fetchYMMEModelList = (year: any, data: any): ThunkAction => (
  dispatch: Dispatch,
  getState: GetState,
  axios: any
) => {
  dispatch(fetchYMMEAPI(axios, year, data, 'GET_MODEL'));
};

/* istanbul ignore next */
export const fetchYMMEEngineList = (model: any, data: any): ThunkAction => (
  dispatch: Dispatch,
  getState: GetState,
  axios: any
) => {
  dispatch(fetchYMMEAPI(axios, model, data, 'GET_ENGINE'));
};

/* istanbul ignore next */
export const ymmeAddVehicle = (data: any): ThunkAction => (
  dispatch: Dispatch,
  getState: GetState,
  axios: any
) => {
  dispatch(fetchYMMEVehicle(axios, data, 'ADD_VEHICLE'));
};

/* istanbul ignore next */
export const ymmeRemoveVehicle = (): ThunkAction => (
  dispatch: Dispatch,
  getState: GetState,
  axios: any
) => {
  dispatch(fetchYMMEVehicle(axios, '', 'REMOVE_VEHICLE'));
};

/* istanbul ignore next */
export const ymmeVehicleList = (): ThunkAction => (
  dispatch: Dispatch,
  getState: GetState,
  axios: any
) => {
  dispatch(fetchYMMEVehicle(axios, '', 'VEHICLE_LIST'));
};
