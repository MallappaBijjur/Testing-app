/* @flow */
import type { Dispatch, GetState, ThunkAction } from '../types';
import azURL from '../config/serviceAPI';

const API_URL_HOME = azURL('homePage');

export const fetchHomeData = (
  axios: any,
  URL: string = API_URL_HOME
): ThunkAction => async (dispatch: Dispatch) => {
  try {
    const response = await axios.get(URL); // backend
    dispatch({ type: 'HOME_SUCCESS', data: response.data });
  } catch (err) {
    dispatch({ type: 'HOME_FAILURE', err: err.message });
  }
};

const API_URL_SUBCAT = azURL('topNavMenu');

export const fetchSubData = (
  axios: any,
  menu: any,
  URL: string = API_URL_SUBCAT
): ThunkAction => async (dispatch: Dispatch) => {
  try {
    const subPath =
      menu.rank === 1
        ? `?topNavServletPath=${menu.topNavServletPath}&catName=${menu.catName}`
        : `?topNavServletPath=${menu.topNavServletPath}&catName=${
            menu.catName
          }&parentUrlState=${menu.parentUrlState}`;
    const response = await axios.get(`${URL}${subPath}`); // backend
    dispatch({ type: 'SUBCAT_SUCCESS', data: response.data });
  } catch (err) {
    dispatch({ type: 'SUBCAT_FAILURE', err: err.message });
  }
};

export const fetchHomeDataCall = (): ThunkAction => (
  dispatch: Dispatch,
  getState: GetState,
  axios: any
) => dispatch(fetchHomeData(axios));

export const fetchSubDataCall = (menu: any): ThunkAction => (
  dispatch: Dispatch,
  getState: GetState,
  axios: any
) => dispatch(fetchSubData(axios, menu));

export const firstCatGet = (id: any, label: string): ThunkAction => (
  dispatch: Dispatch
) => {
  dispatch({ type: 'FETCH_SUBMENU', id, label });
};

export const fetchLevel2 = (id: any, label: string): ThunkAction => (
  dispatch: Dispatch
) => {
  dispatch({ type: 'FETCH_SUBMENU_2', id, label });
};

export const fetchMostPopular = (): ThunkAction => (dispatch: Dispatch) => {
  dispatch({ type: 'FETCH_MOST_POP' });
};

export const resetTopNavData = (): ThunkAction => (dispatch: Dispatch) => {
  dispatch({ type: 'RESET_NAV_DATA' });
};
