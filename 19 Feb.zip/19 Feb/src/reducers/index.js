/* @flow */

import { combineReducers } from 'redux';
import { routerReducer as router } from 'react-router-redux';
import { reducer as reduxFormReducer } from 'redux-form';
import home from './home';
import userInfo from './userInfo';
import navInfo from './navInfo';
import createAccountData from './createAccountData';
import myAccountData from './myAccountsReducer';
import subMenuData from './subMenuReducer';
import formInfo from './formData';
import forgotData from './forgotData';
import resetData from './resetData';
import ymmeData from './ymmeData';
import forgotFormData from './forgotFormData';
import resetFormData from './resetFormData';
import heroContentData from './heroContentData';
import splitContentData from './splitContentData';
import topNavData from './topNav';
import { category, subCategory } from './category';
import shelf from './shelf';
import productData from './productDetails';

const reducers = {
  home,
  userInfo,
  router,
  navInfo,
  myAccountData,
  subMenuData,
  createAccountData,
  formInfo,
  forgotData,
  resetData,
  forgotFormData,
  resetFormData,
  heroContentData,
  splitContentData,
  form: reduxFormReducer,
  topNavData,
  category,
  subCategory,
  ymmeData,
  shelf,
  productData
};

export type Reducers = typeof reducers;
export default combineReducers(reducers);
