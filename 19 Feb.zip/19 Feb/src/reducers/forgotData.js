/* @flow */
import _ from 'lodash/fp';
import type { ForgotData, Action } from '../types';

type State = ForgotData;

const initialState = {
  readyStatus: 'FORGOT_INVALID',
  err: null,
  viewInfo: {}
};

export default (state: State = initialState, action: Action): State => {
  switch (action.type) {
    case 'FORGOT_REQUESTING':
      return _.assign(state, {
        readyStatus: 'FORGOT_REQUESTING'
      });
    case 'FORGOT_FAILURE':
      return _.assign(state, {
        readyStatus: 'FORGOT_FAILURE',
        err: action.err
      });
    case 'FORGOT_SUCCESS':
      return _.assign(state, {
        readyStatus: 'FORGOT_SUCCESS',
        viewInfo: action.data
      });
    default:
      return state;
  }
};
