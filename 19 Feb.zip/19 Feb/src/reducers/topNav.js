/* @flow */

import _ from 'lodash/fp';

import type { TopNavData, Action } from '../types';

type State = TopNavData;

const initialState = {
  readyStatus: 'CREATE_INVALID',
  err: null,
  homeData: {},
  subCatData: {},
  level1: {},
  level2MostPop: {},
  headingL1: null,
  level2: {},
  headingL2: null
};

const getData = (state, id) => state.subCatData.childCategories[1][id];
const getData2 = (state, id) => state.subCatData.childCategories[2][id];
const getPopularItem = (state, id) =>
  state.subCatData.mostPopularCategories.mostPopularCategories[id];
const getMostPop = state => {
  console.log('most pop', state);
};

export default (state: State = initialState, action: Action): State => {
  switch (action.type) {
    case 'HOME_SUCCESS':
      return _.assign(state, {
        readyStatus: 'CREATE_SUCCESS',
        homeData: action.data
      });
    case 'HOME_FAILURE':
      return _.assign(state, {
        readyStatus: 'CREATE_FAILURE',
        err: action.err
      });
    case 'SUBCAT_SUCCESS':
      return _.assign(state, {
        readyStatus: 'SUBCAT_SUCCESS',
        subCatData: action.data
      });
    case 'SUBCAT_FAILURE':
      return _.assign(state, {
        readyStatus: 'SUBCAT_FAILURE',
        err: action.err
      });
    case 'FETCH_SUBMENU':
      return _.assign(state, {
        readyStatus: 'FETCH_SUBMENU_SUCCES',
        level1: getData(state, action.id),
        headingL1: action.label,
        level2MostPop: getPopularItem(state, action.id)
      });

    case 'FETCH_SUBMENU_2':
      return _.assign(state, {
        readyStatus: 'FETCH_SUBMENU_2_SUCCES',
        level2Data: getData2(state, action.id),
        headingL2: action.label
      });

    case 'FETCH_MOST_POP':
      return _.assign(state, {
        mostPop: getMostPop(state)
      });

    case 'RESET_NAV_DATA':
      return _.assign(state, {
        subCatData: {}
      });
    default:
      return state;
  }
};
