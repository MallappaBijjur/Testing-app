/* @flow */

import _ from 'lodash/fp';
import type { YMMEDataType, Action } from '../types';

type State = YMMEDataType;

const initialState = {
  readyStatus: 'YMME_INVALID',
  err: null,
  data: {}
};

export default (state: State = initialState, action: Action): State => {
  switch (action.type) {
    case 'YMME_REQUESTING':
      return _.assign(state, {
        readyStatus: 'YMME_REQUESTING'
      });
    case 'YMME_FAILURE':
      return _.assign(state, {
        readyStatus: 'YMME_FAILURE',
        err: action.err
      });
    case 'YMME_YEAR_SUCCESS': {
      return _.assign(state, {
        readyStatus: 'YMME_YEAR_SUCCESS',
        // data: action.data
        data: _.assign(state.data, { yearList: action.data })
      });
    }
    case 'YMME_MAKE_SUCCESS': {
      return _.assign(state, {
        readyStatus: 'YMME_MAKE_SUCCESS',
        // data: action.data
        data: _.assign(state.data, { makeList: action.data })
      });
    }
    case 'YMME_MODEL_SUCCESS': {
      return _.assign(state, {
        readyStatus: 'YMME_MODEL_SUCCESS',
        // data: action.data
        data: _.assign(state.data, { modelList: action.data })
      });
    }
    case 'YMME_ENGINE_SUCCESS': {
      return _.assign(state, {
        readyStatus: 'YMME_ENGINE_SUCCESS',
        // data: action.data
        data: _.assign(state.data, { engineList: action.data })
      });
    }
    case 'YMME_ADD_VEHICLE_SUCCESS': {
      return _.assign(state, {
        readyStatus: 'YMME_ADD_VEHICLE_SUCCESS',
        data: _.assign(state.data, { addedVehicle: action.data })
      });
    }
    case 'YMME_REMOVE_VEHICLE_SUCCESS': {
      return _.assign(state, {
        readyStatus: 'YMME_REMOVE_VEHICLE_SUCCESS',
        data: _.assign(state.data, { removedVehicle: action.data })
      });
    }
    case 'YMME_VEHICLE_LIST_SUCCESS': {
      return _.assign(state, {
        readyStatus: 'YMME_VEHICLE_LIST_SUCCESS',
        data: _.assign(state.data, { vehicleList: action.data })
      });
    }
    default:
      return state;
  }
};
