/* @flow */
import forgotFormData from '../forgotFormData';

describe('forgot form data', () => {
  test('should return the initial state', () => {
    expect(forgotFormData(undefined, {})).toEqual({
      email: ''
    });
  });

  test('should handle SUBMITFORGOT_REQUESTING', () => {
    expect(
      forgotFormData(undefined, {
        type: 'SUBMITFORGOT_REQUESTING',
        email: ''
      })
    ).toEqual({
      readyStatus: 'SUBMITFORGOT_REQUESTING',
      email: ''
    });
  });

  test('should handle SUBMITFORGOT_FAILURE', () => {
    expect(
      forgotFormData(undefined, {
        type: 'SUBMITFORGOT_FAILURE',
        err: 'Oops! Something went wrong.',
        email: ''
      })
    ).toEqual({
      readyStatus: 'SUBMITFORGOT_FAILURE',
      err: 'Oops! Something went wrong.',
      email: ''
    });
  });

  test('should handle SUBMITFORGOT_SUCCESS', () => {
    expect(
      forgotFormData(undefined, {
        type: 'SUBMITFORGOT_SUCCESS',
        email: '',
        data: [
          ('mf_forgotpasswordpage_forgot_invalid_email': 'Email is not valid')
        ]
      })
    ).toEqual({
      readyStatus: 'SUBMITFORGOT_SUCCESS',
      email: '',
      formValues: [
        ('mf_forgotpasswordpage_forgot_invalid_email': 'Email is not valid')
      ]
    });
  });
});
