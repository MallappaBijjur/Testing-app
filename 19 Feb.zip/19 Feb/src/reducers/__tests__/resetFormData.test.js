/* @flow */
import resetFormData from '../resetFormData';

describe('forgot form data', () => {
  test('should return the initial state', () => {
    expect(resetFormData(undefined, {})).toEqual({
      email: ''
    });
  });

  test('should handle SUBMITRESET_REQUESTING', () => {
    expect(
      resetFormData(undefined, {
        type: 'SUBMITRESET_REQUESTING',
        email: ''
      })
    ).toEqual({
      readyStatus: 'SUBMITRESET_REQUESTING',
      email: ''
    });
  });

  test('should handle SUBMITRESET_FAILURE', () => {
    expect(
      resetFormData(undefined, {
        type: 'SUBMITRESET_FAILURE',
        err: 'Oops! Something went wrong.',
        email: ''
      })
    ).toEqual({
      readyStatus: 'SUBMITRESET_FAILURE',
      err: 'Oops! Something went wrong.',
      email: ''
    });
  });

  test('should handle SUBMITRESET_SUCCESS', () => {
    expect(
      resetFormData(undefined, {
        type: 'SUBMITRESET_SUCCESS',
        email: '',
        data: [('mf_resetpassword_success': 'success')]
      })
    ).toEqual({
      readyStatus: 'SUBMITRESET_SUCCESS',
      email: '',
      formValues: [('mf_resetpassword_success': 'success')]
    });
  });
});
