/* @flow */
import _ from 'lodash/fp';
import type { ResetFormData, Action } from '../types';

type State = ResetFormData;

const initialState = {
  readyStatus: 'RESET_INVALID',
  err: null,
  viewInfo: {}
};

export default (state: State = initialState, action: Action): State => {
  switch (action.type) {
    case 'RESET_REQUESTING':
      return _.assign(state, {
        readyStatus: 'RESET_REQUESTING'
      });
    case 'RESET_FAILURE':
      return _.assign(state, {
        readyStatus: 'RESET_FAILURE',
        err: action.err
      });
    case 'RESET_SUCCESS':
      return _.assign(state, {
        readyStatus: 'RESET_SUCCESS',
        viewInfo: action.data
      });
    default:
      return state;
  }
};
