/* @flow */

import _ from 'lodash/fp';

import type { SplitContentData, Action } from '../types';

type State = SplitContentData;

const initialState = {
  readyStatus: 'SPLIT_INVALID',
  err: null,
  viewInfo: {}
};

export default (state: State = initialState, action: Action): State => {
  switch (action.type) {
    case 'SPLIT_REQUESTING':
      return _.assign(state, {
        readyStatus: 'SPLIT_REQUESTING'
      });
    case 'SPLIT_FAILURE':
      return _.assign(state, {
        readyStatus: 'SPLIT_FAILURE',
        err: action.err
      });
    case 'SPLIT_SUCCESS': {
      return _.assign(state, {
        readyStatus: 'SPLIT_SUCCESS',
        viewInfo: action.data
      });
    }
    default:
      return state;
  }
};
