/* @flow */

import _ from 'lodash/fp';

import type { ProductData, Action } from '../types';

type State = ProductData;

const initialState = {
  readyStatus: 'PRODUCT_INVALID',
  err: null,
  viewInfo: {}
};

export default (state: State = initialState, action: Action): State => {
  switch (action.type) {
    case 'PRODUCT_REQUESTING':
      return _.assign(state, {
        readyStatus: 'PRODUCT_REQUESTING'
      });
    case 'PRODUCT_FAILURE':
      return _.assign(state, {
        readyStatus: 'PRODUCT_FAILURE',
        err: action.err
      });
    case 'PRODUCT_SUCCESS':
      return _.assign(state, {
        readyStatus: 'PRODUCT_SUCCESS',
        viewInfo: action.data
      });
    case 'ADD_TO_CART_SUCCESS':
      return Object.assign({}, state, {
        cartSuccess: action.data
      });
    default:
      return state;
  }
};
