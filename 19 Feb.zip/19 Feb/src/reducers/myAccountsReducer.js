/* @flow */
import _ from 'lodash/fp';

import type { myAccountData, Action } from '../types';

type State = myAccountData;

const initialState = {
  readyStatus: 'MYACCOUNTS_INVALID',
  err: null,
  list: []
};

export default (state: State = initialState, action: Action): State => {
  // console.log('Home Reducer', action, state);
  switch (action.type) {
    case 'MYACCOUNTS_REQUESTING':
      return _.assign(state, {
        readyStatus: 'MYACCOUNTS_REQUESTING'
      });
    case 'MYACCOUNTS_FAILURE':
      return _.assign(state, {
        readyStatus: 'MYACCOUNTS_FAILURE',
        err: action.err
      });
    case 'MYACCOUNTS_SUCCESS':
      return _.assign(state, {
        readyStatus: 'MYACCOUNTS_SUCCESS',
        list: action.data
      });
    default:
      return state;
  }
};
