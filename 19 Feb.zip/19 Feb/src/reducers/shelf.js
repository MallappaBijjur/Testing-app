/* @flow */

import type { ShelfData, Action } from '../types';

type State = ShelfData;

const initialState = {
  readyStatus: 'PARTS_INVALID',
  isList: true,
  parts: {},
  price: [],
  skuIds: [],
  relatedParts: {},
  relatedProducts: {},
  err: null
};

// const getRelatedParts = () => ({
//   // Need to implement RelatedParts logic
// });

// const getRelatedProducts = () => ({
//   // Need to implement RelatedProducts logic
// });

// case 'PARTS_SUCCESS':
//       return Object.assign({}, state, {
//         parts: action.data,
//         readyStatus: 'PARTS_SUCCESS',
//         relatedParts: getRelatedParts(),
//         relatedProducts: getRelatedProducts()
//       });

const shelf =  (state: State = initialState, action: Action): State => {
  switch (action.type) {
    case 'SET_VIEW':
      return Object.assign({}, state, {
        isList: action.view,
        readyStatus: 'SET_VIEW_SUCCESS'
      });
    case 'PARTS_SUCCESS':
      return Object.assign({}, state, {
        parts: action.data,
        readyStatus: 'PARTS_SUCCESS'
      });
    case 'PARTS_FAILURE':
      return {
        ...state,
        ...{
          readyStatus: 'PARTS_FAILURE',
          err: action.err
        }
      };
    case 'PARTS_REQUESTING':
      return {
        ...state,
        ...{
          readyStatus: 'PARTS_REQUESTING'
        }
      };
    case 'PRICE_SUCCESS': {
      return {
        ...state,
        price: action.data,
        readyStatus: 'PRICE_SUCCESS',
        skuIds: action.skuIds
      };
    }
    case 'ADD_TO_CART_SUCCESS':
      return Object.assign({}, state, {
        cartSuccess: action.data,
        readyStatus: 'ADD_TO_CART_SUCCESS'
      });

    default:
      return state;
  }
};

export default shelf;