import React from 'react';
import type { Element } from 'react';
import { Link } from 'react-router-dom';
import routes from '../../routes'; // eslint-disable-line
// Import your global styles here
import '../../theme/normalize.css';
import styles from './styles.scss';
import Logo from '../../components/TopNav/Logo';
import SearchBox from '../../components/TopNav/SearchBox';
import Vehicle from '../../components/TopNav/Vehicle';
import Cart from '../../components/TopNav/Cart';
import Menu from '../../components/TopNav/Menu';
import NavInfo from '../../components/NavTopInfo/NavInfo';
import NavBar from '../../components/NavBar/NavBar';
import CreateAccountPage from '../../containers/CreateAccount';

const App = (): Element<'div'> => (
  // wrap <Route> and use this everywhere instead, then when
  // sub routes are added to any route it'll work
  <div className={styles.App}>
    <div className={styles.appNavigation}>
      <NavInfo styles={styles} />
      <div className={styles.rowAuto}>
        <Link to="/home">
          <Logo styles={styles} />
        </Link>
        <SearchBox styles={styles} viewType="desktop" />
        <div className={styles.addInfo}>
          <Vehicle styles={styles} />
          <Cart styles={styles} />
          <Menu styles={styles} />
        </div>
      </div>
      <div className={styles.searchMobile}>
        <SearchBox styles={styles} viewType="mobile" />
      </div>
      <NavBar styles={styles} />
      <br />
      <Link to="/CreateAccountPage">
        <button>Create Account Page</button>
      </Link>
      <CreateAccountPage />
    </div>
  </div>
);

export default App;
