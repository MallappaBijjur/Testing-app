/* @flow */
import React from 'react';
import type { Element } from 'react';
import { Row, Col } from 'react-bootstrap';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import lightBaseTheme from 'material-ui/styles/baseThemes/lightBaseTheme';
import TextField from 'material-ui/TextField';
import Checkbox from 'material-ui/Checkbox';
import RaisedButton from 'material-ui/RaisedButton';
import getMuiTheme from 'material-ui/styles/getMuiTheme';

// import Banner from './Banner';

type Props = { info: string, styles: Object };

const TestCard = ({ info, styles }: Props): Element<'div'> => (
  <div className={styles.registerationPage}>
    <Row className="show-grid">
      <Col xs={12} sm={12} md={12} lg={4}>
        <img alt="Logo Here" src="folder" className={styles.regLogo} />
        <h1>{info.name}</h1>
        <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
          <div className={styles.createForm}>
            <div>
              <TextField
                hintText="First Name"
                floatingLabelText="First Name"
                className={styles.inputTextBox}
              />
              <TextField
                hintText="Last Name"
                floatingLabelText="Last Name"
                className={styles.inputTextBox}
              />
              <TextField
                hintText="Zip Code"
                floatingLabelText="Zip Code"
                className={styles.inputTextBox}
              />
              <TextField
                hintText="Phone"
                floatingLabelText="Phone"
                className={styles.inputTextBox}
              />
              <TextField
                hintText="Email"
                floatingLabelText="Email"
                className={styles.inputTextBox}
              />
              <TextField
                hintText="Password"
                floatingLabelText="Password"
                className={styles.inputTextBox_Password}
              />
            </div>
            <div className={styles.regPasswordRules}>
              Make your password at least 8 characters with 1 number and 1
              special character. It is case-sensitive.
            </div>
            <div className={styles.regRewardSection}>
              <div className={styles.regRewardSectionTop}>
                Enter your AutoZone Rewards Member ID
              </div>
              <div className={styles.regRewardSectionMid}>
                Link AutoZone Rewards with the Member ID number on the back of
                your AutoZone Rewards card.
              </div>
              <TextField
                hintText="9101000389891796"
                floatingLabelText="Autozone Rewards Member ID"
                className={styles.inputTextBox_AZID}
              />
              <div className={styles.regAZMember_Error}>
                We couldn’t find that ID number. Check against the back of your
                card and try again?
              </div>
            </div>
            <div className={styles.regSubscription}>
              <Checkbox />
              <div>
                Yes, I would like to receive special offers, promotions, news,
                surveys, and correspondence from AutoZone, AutoZone.com, and
                AutoZone Rewards.
                <a href="/readYourPolicy">Read our Privacy Policy.</a>
              </div>
              <div className={styles.regReadTerms}>
                By clicking sign up, you agree to the Terms &amp; Conditions{' '}
              </div>
              <div className={styles.regButtonSection}>
                <RaisedButton
                  label="Sign Up"
                  className={styles.regPrimaryBtn}
                />
                <RaisedButton
                  label="Cancel"
                  className={styles.regSecondaryBtn}
                />
              </div>
              <div className={styles.regSignInLink}>
                Already have an account? <a href="/signin">Sign In</a>
              </div>
            </div>
          </div>
        </MuiThemeProvider>
      </Col>
      <Col xsHidden lg={8}>
        Banner Here
      </Col>
    </Row>
  </div>
);

export default TestCard;
