import React from 'react';
import Filter from './Filter';
import Shelf from './Shelf';

const Body = () => (
  <div>
    <div className="card-panel teal">BreadCrumb</div>
    <div className="row">
      <div className="col s4">
        {' '}
        <Filter />{' '}
      </div>
      <div className="col s8 grey">
        {' '}
        <Shelf />{' '}
      </div>
    </div>
  </div>
);

export default Body;
