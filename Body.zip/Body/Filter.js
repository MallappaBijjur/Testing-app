import React from 'react';
import styles from './styles.scss';

class Filter extends React.Component {
  render() {
    return(
      <div className="row">
        <div className={`${styles.filter} col s12 grey`}>
          <h1> FILTER RESULTS </h1>
        </div
      </div>
    );
  }
}
