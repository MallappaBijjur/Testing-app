import React from "react";
import { connect } from "react-redux"

const treeData = {
  tree: [
    {
      "node": {
        "id": "1",
        "description": "test1",
        "children": [
          {
            node: {
              "id": "1_1",
              "description": "test1_1",
              "children": [
                          {
            node: {
              "id": "1_1_1",
              "description": "test1_1_1",
              "children": [
                
              ]
            }
          },
          {
            node: {
              "id": "1_1_2",
              "description": "test1_1_2",
              "children": [
                
              ]
            }
          }
              ]
            }
          },
          {
            node: {
              "id": "1_2",
              "description": "test1_2",
              "children": [
                
              ]
            }
          }
          ]
      }
    },
    {
      "node": {
        "id": "2",
        "description": "test2",
        "children": [
          {
            node: {
              "id": "2_1",
              "description": "test2_1",
              "children": [
                          {
            node: {
              "id": "2_1_1",
              "description": "test2_1_1",
              "children": [
                
              ]
            }
          },
          {
            node: {
              "id": "2_1_2",
              "description": "test2_1_2",
              "children": [
                
              ]
            }
          }
              ]
            }
          },
          {
            node: {
              "id": "2_2",
              "description": "test2_2",
              "children": [
                
              ]
            }
          }
          ]
      }
    }
  ]
}

class TreeNode extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        }
    }

    render() {
      let childNodes;
      if(this.props && this.props.data ){
         childNodes = Object.values(this.props.data).map((node,index) => {
        return <JunTree branch={node} children={node.children} key={index} />
      });
      }
     
        return (
            <div className="container">
              <input type="text" ref={node => {this.input = node}} />
              <buttton type="button" onClick={() => {
                this.props.dispatch({
                  type:'RET',
                  text: this.input.value,
                  treeData:treeData
                })
              }}>
                Search
              </buttton>
                <ul>
                  {childNodes}
                </ul>
            </div>
        );
    }

}


class JunTree extends React.Component  {
  render() {
    let nodes;
      if(this.props.branch.node.children) {
        nodes = this.props.branch.node.children.map((node, index) => {
        return <JunTree branch={node} children={node.children} key={index} />
        });
      }
    
  
    return (
    <li>
    <span>{this.props.branch.node.description}</span>
    <ul>
      {nodes}
    </ul>
  </li>
  );

  
  }
  }
    
const mapStateToProps = (state) => {
  return {
    data:state
  };
}

export default connect(mapStateToProps) (TreeNode);
