import { createStore } from 'redux';
// import { createLogger } from 'redux-logger';
import TreeNode from './components/App';
import React from 'react';
import { Provider } from 'react-redux'
import { render } from "react-dom";

export const reducer = (state={}, action) => {
  switch(action.type) {
    case "RET" : 
      let tree = action.treeData.tree.filter( (text) => {
      return text.node.description.indexOf(action.text) !== -1;
    });
    state = Object.assign({},tree );
  }
  return state;
}

const store = createStore(reducer);

render(
  <Provider store={store} >
  <TreeNode data={store.getState().treeData}/>
  </Provider>
  , document.getElementById('app1'));

