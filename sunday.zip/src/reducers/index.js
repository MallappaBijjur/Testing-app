/* @flow */

import { combineReducers } from 'redux';
import { routerReducer as router } from 'react-router-redux';
import { reducer as reduxFormReducer } from 'redux-form';
import home from './home';
import userInfo from './userInfo';
import navInfo from './navInfo';
import createAccountData from './createAccountData';
import formInfo from './formData';

const reducers = {
  home,
  userInfo,
  router,
  navInfo,
  createAccountData,
  formInfo,
  form: reduxFormReducer
};

export type Reducers = typeof reducers;
export default combineReducers(reducers);
