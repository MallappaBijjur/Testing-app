/* @flow */

import type { Dispatch, GetState, ThunkAction, ReduxState } from '../types';
import navigationDatas from './menuNavigation';

const API_URL = 'https://jsonplaceholder.typicode.com/users';

// Export this for unit testing more easily
export const fetchUser = (
  title: string,
  axios: any,
  URL: string = API_URL
): ThunkAction => async (dispatch: Dispatch) => {
  dispatch({ type: 'USER_REQUESTING', title });

  try {
    await axios.get(`${URL}/1`); // to be changed to backend api call

    dispatch({
      type: 'USER_SUCCESS',
      title,
      data: navigationDatas.filter(z => z.id === `${title}`)[0]
    });
  } catch (err) {
    dispatch({ type: 'USER_FAILURE', title, err: err.message });
  }
};

// Using for preventing dobule fetching data
/* istanbul ignore next */
const shouldFetchUser = (state: ReduxState, title: string): boolean => {
  // In development, we will allow action dispatching
  // or your reducer hot reloading won't updated on the view
  if (__DEV__) return true;

  const userInfo = state.userInfo[title];

  // Preventing dobule fetching data in production
  if (userInfo && userInfo.readyStatus === 'USER_SUCCESS') return false;

  return true;
};

/* istanbul ignore next */
export const fetchUserIfNeeded = (title: string): ThunkAction => (
  dispatch: Dispatch,
  getState: GetState,
  axios: any
) => {
  /* istanbul ignore next */
  if (shouldFetchUser(getState(), title)) {
    /* istanbul ignore next */
    return dispatch(fetchUser(title, axios));
  }

  /* istanbul ignore next */
  return null;
};
