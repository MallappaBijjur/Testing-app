/* @flow */
import { push } from 'react-router-redux';
import type { Dispatch, GetState, ThunkAction, ReduxState } from '../types';

const API_URL = 'http://dv-camaro1-xl07:8289/autozone/v1/currentUser';

// Export this for unit testing more easily
export const fetchUsers = (
  axios: any,
  values: any,
  URL: string = API_URL
): ThunkAction => async (dispatch: Dispatch) => {
  dispatch({ type: 'SUBMIT_REQUESTING' });

  try {
    const res = await axios.post(URL, values); // backend
    console.log('yeah got it', res.data);
    dispatch({ type: 'SUBMIT_SUCCESS', data: res.data });
    dispatch(push('/Confirmation'));
  } catch (err) {
    dispatch({ type: 'SUBMIT_FAILURE', err: err.message });
  }
};

// Preventing dobule fetching data
/* istanbul ignore next */
const shouldFetch = (state: ReduxState): boolean => {
  // In development, we will allow action dispatching
  // or your reducer hot reloading won't updated on the view
  if (__DEV__) return true;

  if (state.home.readyStatus === 'SUBMIT_SUCCESS') return false; // Preventing double fetching data

  return true;
};

/* istanbul ignore next */
export const submitFormAction = (values): ThunkAction => (
  dispatch: Dispatch,
  getState: GetState,
  axios: any
) => {
  console.log('Actions values', values);
  /* istanbul ignore next */
  if (shouldFetch(getState())) {
    /* istanbul ignore next */
    return dispatch(fetchUsers(axios, values));
  }

  /* istanbul ignore next */
  return null;
};
