/*eslint-disable*/

import React, { PureComponent } from 'react';
import type { Element } from 'react';
import { Grid, Row, Col } from 'react-bootstrap';
import { connect } from 'react-redux';
import type { Connector } from 'react-redux';
import type {
  CreateAccountData as CreateAccountDataType,
  Dispatch,
  ReduxState
} from '../../types';
import CreateForm from '../../components/CreateForm';
import * as styles from './styles.scss';
import * as createAccount from '../../actions/createAccount';
import * as submitForm from '../../actions/submitForm';
import Banner from './Banner';

type Props = {
  createAccountData: CreateAccountDataType,
  fetchCreateAccountData: () => void,
  submitFormAction: () => void
};

// Export this for unit testing more easily
export class CreateAccount extends PureComponent<Props> {
  componentDidMount() {
    console.log('the fetch', this.props);
    this.props.fetchCreateAccountData();
  }

  handleSubmit = formInfo => {
    console.log('in submit');
    console.log('the formValues are', formInfo);

    const formValues = {
      login: `${formInfo.email}`,
      password: `${formInfo.password}`,
      email: `${formInfo.email}`,
      firstName: `${formInfo.firstName}`,
      lastName: `${formInfo.lastName}`,
      addresses: [
        {
          items: {
            type: 'homeAddress',
            postalCode: `${formInfo.postalCode}`,
            phoneNumber: `${formInfo.phoneNumber}`,
          }
        }
      ],
      otherOptions: {
        mobileApp: 'true',
        activeSubscriptionsAsCSV: 'receivePromoAndSpecialEvents'
      }
    };

    console.log('formValues', formValues);
    this.props.submitFormAction(formValues);
    console.log('CreateAccount Props', this.props);
  };

  // showResults = values => {
  //   console.log('Inside showResults()', values);
  //   console.log(`You submitted:\n\n${JSON.stringify(values, null, 2)}`);
  // };

  renderCreateForm = (): Element<'p' | typeof CreateForm> => {
    const { createAccountData } = this.props;
    // console.log('ACTION', createAccountData);
    if (
      !createAccountData.readyStatus ||
      createAccountData.readyStatus === 'CREATE_INVALID' ||
      createAccountData.readyStatus === 'CREATE_REQUESTING'
    ) {
      return <p>Loading...</p>;
    }

    if (createAccountData.readyStatus === 'CREATE_FAILURE') {
      return <p>Oops, Failed to load list!</p>;
    }

    return (
      <CreateForm
        data={createAccountData.viewInfo}
        onSubmit={this.handleSubmit}
      />
    );
  };

  render() {
    const { createAccountData } = this.props;
    console.log('createAccountData in Container', createAccountData);

    return (
      <Grid className={styles.registerationPage}>
        <Row className="show-grid">
          <Col xs={12} sm={12} md={12} lg={5}>
            <div className={styles.regLeftSection}>
              <img
                style={{
                  display: 'block',
                  position: 'relative',
                  left: '-18px'
                }}
                src={require('./assets/backBtn.png')}
                alt="Logo"
                role="presentation"
                width="90px"
                height="58px"
              />
              <div style={{ paddingTop: '20px' }}>
                <img
                  src={require('./assets/logo-mobile.png')}
                  alt="Logo"
                  role="presentation"
                  height="43px"
                  className="visible-xs"
                />
                <img
                  src={require('./assets/Autozonelogo.png')}
                  alt="Logo"
                  role="presentation"
                  height="43px"
                  className="hidden-xs"
                />
              </div>
              <h1 style={{ paddingBottom: '10px' }}>
                {createAccountData.viewInfo.mf_registration_page_header_lbl}
              </h1>
              <div>{this.renderCreateForm()}</div>
            </div>
          </Col>
          <Col xsHidden lg={7} className={styles.regRightGrid}>
            <Banner data={createAccountData.viewInfo} />
          </Col>
        </Row>
      </Grid>
    );
  }
}

const connector: Connector<{}, Props> = connect(
  ({ createAccountData }: ReduxState) => ({
    createAccountData
  }),
  (dispatch: Dispatch) => ({
    fetchCreateAccountData: () =>
      dispatch(createAccount.fetchCreateAccountData()),
    submitFormAction: values => dispatch(submitForm.submitFormAction(values))
  })
);

export default connector(CreateAccount);
