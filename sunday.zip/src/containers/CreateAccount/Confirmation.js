/*eslint-disable*/

import React, { PureComponent, type } from 'react';
import { Row, Col, Grid } from 'react-bootstrap';
import { connect } from 'react-redux';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import lightBaseTheme from 'material-ui/styles/baseThemes/lightBaseTheme';
import RaisedButton from 'material-ui/RaisedButton';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
import styles from './styles.scss';

type Props = {
  successValues: Object
};

class Confirmation extends PureComponent<Props> {
  render() {
    console.log('Confirmation Props', this.props);
    const { successValues } = this.props;
    return (
      <Grid className={styles.AccountConfirmationPage}>
        <Row className="show-grid">
          <Col xs={12} sm={12} md={12} lg={12}>
            <img
              src={require('./assets/Autozonelogo.png')}
              alt="Logo"
              role="presentation"
              height="50px"
            />
            <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
              <h2>{successValues.mf_regConfirmation_welcome}</h2>
              <div
                className={styles.fontNormal}
                style={{
                  'marginBottom': '25px'
                }}
              >
                {successValues.mf_regConfirmation_registered}
              </div>
              <div className={styles.subRewardSignIn}>
                MyZone and AutoZone Rewards Sign in
              </div>
              <div className={styles.subRegEmail}>
                <div>Email</div>
                <span className={styles.fontNormal}>
                  {successValues.login}
                </span>
              </div>
              <div className={styles.subRegReward}>
                <div>Rewards ID</div>
                <span className={styles.fontNormal}>{successValues.rewardsId}</span>
              </div>
              <Row>
                <Col xs={12} sm={6} md={6} lg={6}>
                  <RaisedButton
                    label={successValues.mf_regConfirmation_returnBtn}
                    className={styles.subRegistrationComplete}
                  />
                </Col>
                <Col xs={12} sm={6} md={6} lg={6}>
                  <RaisedButton
                    label={successValues.mf_regConfirmation_completeBtn}
                    className={styles.subCompleteProfile}
                  />
                </Col>
              </Row>
            </MuiThemeProvider>
          </Col>
        </Row>
      </Grid>
    );
  }
}

const confirmation = connect(state => {
  console.log('STATE', state);
  return {
    successValues: state.formInfo.successValues
  };
})(Confirmation);

export default confirmation;
