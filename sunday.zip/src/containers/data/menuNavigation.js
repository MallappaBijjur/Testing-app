const menuNavigation = {
  menuNavigationLeft: [
    {
      id: 'autoParts',
      displayName: 'AUTO PARTS'
    },
    {
      id: 'Accessories',
      displayName: 'ACCESSORIES'
    },
    {
      id: 'Tools',
      displayName: 'TOOLS'
    },
    {
      id: 'OilandFluids',
      displayName: 'OIL & FLIUDS'
    },
    {
      id: 'Performance',
      displayName: 'PERFORMANCE'
    },
    {
      id: 'Featured',
      displayName: 'FEATURED'
    }
  ],

  menuNavigationRight: [
    {
      id: 'Repairhelp',
      displayName: 'Repair Help',
      link: 'https://en.wikipedia.org/wiki/Teddy_Riner'
    },
    {
      id: 'Deals',
      displayName: 'Deals',
      link: 'https://en.wikipedia.org/wiki/Teddy_Riner'
    }
  ]
};

export default menuNavigation;
