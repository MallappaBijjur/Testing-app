import React, { PureComponent } from 'react';
import styles from './styles.scss';

type Props = {
  onMouseOverMenu: Object,
  content: Object,
  currentLevel: Number,
  seeMore: Boolean
};
class ListContainer extends PureComponent<Props> {
  onFocusrClick = () => {
    console.log('onBlur');
  };

  render() {
    const { content } = this.props;
    return (
      <div>
        {content && (
          <div className={`col s12 ${styles.top}`}>
            <ul>
              {content.map(item => (
                <li
                  key={item.NId}
                  onFocus={this.onFocus}
                  onMouseOver={() =>
                    this.props.onMouseOverMenu(
                      item.NId,
                      item.label,
                      this.props.currentLevel
                    )
                  }
                >
                  {item.label}
                </li>
              ))}
              <li> {this.props.seeMore ? <a href="#/">See More</a> : ''} </li>
            </ul>
          </div>
        )}
      </div>
    );
  }
}

export default ListContainer;
