import React, { PureComponent } from 'react';
import type { Connector } from 'react-redux';
import { connect } from 'react-redux';
import styles from './styles.scss';
import ListContainer from './ListContainer';
import type { Dispatch, ReduxState } from '../../types';
import * as createAccount from '../../actions/createAccount';

type Props = {
  firstCatGet: () => void,
  changeMenuState: () => void,
  subCatData: Object,
  label: String,
  currentLevel: Number
};

class MenuLevel1 extends PureComponent<Props> {
  onMouseOverMenu = (id, label) => {
    // if (level === 1) {
    //   this.props.firstCatGet(id, label);
    // } else if (level === 2) {
    //   this.props.fetchLevel2(id, label);
    // }
    this.props.firstCatGet(id, label);
    this.props.changeMenuState('l2', true);
    this.props.changeMenuState('l3', false);
    // this.setState(prevState => ({
    //   currentLevel:
    //     prevState.currentLevel >= 3
    //       ? prevState.currentLevel
    //       : prevState.currentLevel + 1,
    //   [`L${prevState.currentLevel + 1}`]: true
    // }));
  };

  render() {
    // const { data } = this.props;
    const { subCatData } = this.props;
    let level1Data = null;
    if (subCatData && subCatData.childCategories) {
      if (subCatData.childCategories[0])
        level1Data = subCatData.childCategories[0]['10000000'];
    }
    // const l1 = subCatData ? subCatData.childCategories: null;
    // const level1Data = subCatData?subCatData.childCategories?
    //   ? subCatData.childCategories[0] && subCatData[0]['10000000']
    //   : null;

    console.log('ggggggggggggggggggggggg', level1Data);
    // need to change it for other cat
    // if (this.props.currentLevel === 1) {
    //   return (
    //     <div className={`col s12 ${styles.borderPart}`}>
    //       <header className={styles.menuHeader}>{this.props.label}</header>
    //       <a
    //         href="#/"
    //         className={styles.titleSection}
    //         style={{ paddingTop: 10 }}
    //       >
    //         {`Most Popular ${this.props.label}`}{' '}
    //       </a>
    //       <ListContainer
    //         onMouseOverMenu={this.onMouseOverMenu()}
    //         content={level1Data}
    //         currentLevel={this.props.currentLevel}
    //       />
    //     </div>
    //   );
    // } else if (this.props.currentLevel === 2) {
    //   return (
    //     <div className={`col s6 ${styles.borderPart}`}>
    //       <header className={styles.menuHeader}>{this.props.label}</header>
    //       <a
    //         href="#/"
    //         className={styles.titleSection}
    //         style={{ paddingTop: 10 }}
    //       >
    //         {`Most Popular ${this.props.label}`}{' '}
    //       </a>
    //       <ListContainer
    //         onMouseOverMenu={this.onMouseOverMenu()}
    //         content={level1Data}
    //         currentLevel={this.props.currentLevel}
    //       />
    //     </div>
    //   );
    // }
    return (
      <div>
        <header className={styles.menuHeader}>{this.props.label}</header>
        <a href="#/" className={styles.titleSection} style={{ paddingTop: 10 }}>
          {`Most Popular ${this.props.label}`}{' '}
        </a>
        <ListContainer
          onMouseOverMenu={this.onMouseOverMenu}
          content={level1Data}
          currentLevel={this.props.currentLevel}
        />
      </div>
    );
  }
}

const connector: Connector<{}, Props> = connect(
  ({ createAccountData }: ReduxState) => ({
    subCatData: createAccountData.subCatData
  }),
  (dispatch: Dispatch) => ({
    fetchSubDataCall: () => dispatch(createAccount.fetchSubDataCall()),
    firstCatGet: (id, label) => dispatch(createAccount.firstCatGet(id, label)),
    fetchLevel2: (id, label) => dispatch(createAccount.fetchLevel2(id, label))
  })
);

export default connector(MenuLevel1);
