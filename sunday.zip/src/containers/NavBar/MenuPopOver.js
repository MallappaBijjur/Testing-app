import React, { PureComponent } from 'react';
import PopOverMenuComponentFeatured from './PopOverMenuComponent';
import MenuSlider from './MenuSlider';

type Props = {
  open: Object,
  anchorEl: Object,
  handleRequestClose: Object,
  onMouseOverMenu: Object,
  menuKey: String,
  currentLevel: Number,
  subCatData: Object
};

class MenuPopOver extends PureComponent<Props> {
  render() {
    const { subCatData } = this.props;
    const catContent = subCatData && subCatData.childCategories;

    return (
      <div>
        {this.props.menuKey === 'Featured' && (
          <PopOverMenuComponentFeatured
            open={this.props.open}
            anchorEl={this.props.anchorEl}
            handleRequestClose={this.props.handleRequestClose}
          />
        )}
        {this.props.menuKey !== 'Featured' && (
          <MenuSlider
            open={this.props.open}
            anchorEl={this.props.anchorEl}
            handleRequestClose={this.props.handleRequestClose}
            onMouseOverMenu={this.props.onMouseOverMenu}
            currentLevel={this.props.currentLevel}
            menuKey={this.props.menuKey}
            data={catContent}
          />
        )}
      </div>
    );
  }
}

export default MenuPopOver;
