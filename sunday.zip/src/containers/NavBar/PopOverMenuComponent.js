import React, { PureComponent } from 'react';
import Popover from 'material-ui/Popover';
import Menu from 'material-ui/Menu';
import MenuItem from 'material-ui/MenuItem';
import Divider from 'material-ui/Divider';
import styles from './styles.scss';

type Props = {
  open: Object,
  anchorEl: Object,
  handleRequestClose: Object
};

class PopOverMenuComponentFeatured extends PureComponent<Props> {
  render() {
    return (
      <Popover
        open={this.props.open}
        anchorEl={this.props.anchorEl}
        anchorOrigin={{ horizontal: 'left', vertical: 'bottom' }}
        targetOrigin={{ horizontal: 'left', vertical: 'top' }}
        onRequestClose={() => this.props.handleRequestClose()}
        className={styles.popOver}
      >
        <Menu>
          <MenuItem primaryText="FEATURES " />
          <Divider />
          <MenuItem primaryText="Duralast Brake Pads" />
          <MenuItem primaryText="Duralst Gold Battery" />
          <MenuItem primaryText="Pennzoil Platinum Motoer Oil SAE" />
          <MenuItem primaryText="Valvoline Premium Conventional Engine Oil" />
          <MenuItem primaryText="Duralast Gold Alternator" />
          <MenuItem primaryText="XtraVision Headlight" />
        </Menu>
      </Popover>
    );
  }
}

export default PopOverMenuComponentFeatured;
