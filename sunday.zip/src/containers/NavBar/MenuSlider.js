import React, { PureComponent } from 'react';
import Popover from 'material-ui/Popover';
import { connect, Connector } from 'react-redux';
import styles from './styles.scss';
import type { ReduxState } from '../../types';
import MenuLevel1 from './MenuLevel1';
import MenuLevel2 from './MenuLevel2';
import MenuLevel3 from './MenuLevel3';
// import TopNavAdd from '../../components/TopNav/TopNavAdd'; check it next story

type Props = {
  open: Object,
  anchorEl: Object,
  handleRequestClose: Object,
  onMouseOverMenu: Object,
  // level1: Object,
  // level2: Boolean,
  currentLevel: Number,
  // data: Object,
  level2Data: Object,
  // level2MostPop: Object,
  // headingL1: String,
  menuKey: String,
  headingL2: String
};

class MenuSlider extends PureComponent<Props> {
  constructor(props) {
    super(props);
    this.state = {
      l1: true,
      l2: false,
      l3: false
    };
  }

  componentDidMount() {
    console.log('onMouseOverClick');
  }
  changeMenuState = (level, stat) => {
    this.setState({ [level]: stat });
  };

  render() {
    const {
      // data,
      // level1,
      // level2MostPop,
      // headingL1,
      level2Data,
      headingL2
    } = this.props;
    // const content = (data && data[0]) || 1;
    let menuOneColWidth = 0;
    let menuTwoColWidth = 0;
    let menuThreeColWidth = 0;

    if (this.state.l1 && !this.state.l2 && !this.state.l3) {
      menuOneColWidth = 12;
    } else if (this.state.l1 && this.state.l2 && !this.state.l3) {
      menuOneColWidth = 6;
      menuTwoColWidth = 6;
    } else if (this.state.l1 && this.state.l2 && this.state.l3) {
      menuOneColWidth = 4;
      menuTwoColWidth = 4;
      menuThreeColWidth = 4;
    }

    console.log(menuOneColWidth);
    return (
      <Popover
        open={this.props.open}
        anchorEl={this.props.anchorEl}
        anchorOrigin={{ horizontal: 'left', vertical: 'bottom' }}
        targetOrigin={{ horizontal: 'left', vertical: 'top' }}
        onRequestClose={() => this.props.handleRequestClose()}
        className={styles.popOver}
      >
        <div className="row">
          {this.state.l1 && (
            <div className={`col s${menuOneColWidth} ${styles.borderPart}`}>
              <MenuLevel1
                currentLevel={this.props.currentLevel}
                onMouseOverMenu={this.props.onMouseOverMenu}
                label={this.props.menuKey}
                changeMenuState={this.changeMenuState}
              />
            </div>
          )}
          {this.state.l2 && (
            <div className={`col s${menuTwoColWidth} ${styles.borderPart}`}>
              <MenuLevel2
                currentLevel={this.props.currentLevel}
                onMouseOverMenu={this.props.onMouseOverMenu}
                changeMenuState={this.changeMenuState}
              />
            </div>
          )}
          {this.state.l3 && (
            <div className={`col s${menuThreeColWidth} ${styles.borderPart}`}>
              <MenuLevel3
                currentLevel={this.props.currentLevel}
                onMouseOverMenu={this.props.onMouseOverMenu}
                label={headingL2}
                content={level2Data}
              />
            </div>
          )}
        </div>
      </Popover>
    );
  }
}

const connector: Connector<{}, Props> = connect(
  ({ createAccountData }: ReduxState) => ({
    level1: createAccountData.level1,
    level2MostPop: createAccountData.level2MostPop,
    headingL1: createAccountData.headingL1,
    level2Data: createAccountData.level2Data,
    headingL2: createAccountData.headingL2
  })
);

export default connector(MenuSlider);

// {
//   <div className={`col s4 ${styles.borderPart}`}>
//     <TopNavAdd styles={styles} />
//   </div>
// }
