import React, { PureComponent } from 'react';
import type { Connector } from 'react-redux';
import { connect } from 'react-redux';
import ListContainer from './ListContainer';
import type { Dispatch, ReduxState } from '../../types';
import styles from './styles.scss';
import * as createAccount from '../../actions/createAccount';

type Props = {
  level1: Object,
  level2MostPop: Object,
  // currentLevel: Number,
  fetchLevel2: () => void,
  changeMenuState: () => void,
  headingL1: String
};

class MenuLevel2 extends PureComponent<Props> {
  onMouseOverMenu = (id, label) => {
    this.props.fetchLevel2(id, label);
    this.props.changeMenuState('l3', true);
  };

  getContent = content => {
    let newContent = content;
    if (content && content.length > 5) {
      newContent = content.slice(0, 5);
    }

    return newContent;
  };
  // seeMore={content.length > 5}
  render() {
    const { level1, level2MostPop, headingL1 } = this.props;
    // if (this.props.currentLevel === 2) {
    //   return (
    //     <div className={`col s6 ${styles.borderPart}`}>
    //       <h1 className={styles.menuHeader}>{headingL1} </h1>
    //       <ListContainer
    //         onMouseOverMenu={this.onMouseOverMenu}
    //         content={this.getContent(level1)}
    //       />
    //       <h1 className={styles.menuHeader}>
    //         {' '}
    //         <span className={styles.popular}>Popular</span> In This Category
    //       </h1>
    //       <ListContainer content={level2MostPop} />
    //     </div>
    //   );
    // }
    return (
      <div className={`${styles.borderPart}`}>
        <h1 className={styles.menuHeader}>{headingL1}</h1>
        <ListContainer
          onMouseOverMenu={this.onMouseOverMenu}
          content={this.getContent(level1)}
          seeMore={level1.length > 5}
        />
        <h1 className={styles.menuHeader}>
          {' '}
          <span className={styles.popular}>Popular</span> In This Category
        </h1>
        <ListContainer content={level2MostPop} />
      </div>
    );
  }
}

const connector: Connector<{}, Props> = connect(
  ({ createAccountData }: ReduxState) => ({
    level1: createAccountData.level1,
    level2MostPop: createAccountData.level2MostPop,
    headingL1: createAccountData.headingL1
  }),
  (dispatch: Dispatch) => ({
    fetchLevel2: (id, label) => dispatch(createAccount.fetchLevel2(id, label))
  })
);

export default connector(MenuLevel2);
