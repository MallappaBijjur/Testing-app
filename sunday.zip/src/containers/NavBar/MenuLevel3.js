import React, { PureComponent } from 'react';
import styles from './styles.scss';
import ListContainer from './ListContainer';

type Props = {
  onMouseOverMenu: Object,
  label: String,
  content: Number
};

class MenuLevel3 extends PureComponent<Props> {
  render() {
    return (
      <div>
        <h1 className={styles.menuHeader}>{this.props.label}</h1>
        <ListContainer
          onMouseOverMenu={this.props.onMouseOverMenu}
          content={this.props.content}
        />
      </div>
    );
  }
}

export default MenuLevel3;
