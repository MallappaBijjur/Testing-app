import React, { PureComponent } from 'react';
import FlatButton from 'material-ui/FlatButton';
import type { Connector } from 'react-redux';
import { connect } from 'react-redux';
import styles from './styles.scss';
import menuNavigation from '../data/menuNavigation';
import MenuPopOver from './MenuPopOver';
import type { Dispatch, ReduxState } from '../../types';
import * as createAccount from '../../actions/createAccount';

type Props = {
  styles: Object,
  // fetchHomeDataCall: () => void,
  fetchSubDataCall: () => void,
  // firstCatGet: () => void,
  homeData: Object,
  subCatData: Object
  // fetchLevel2: () => void
};

class NavBar extends PureComponent<Props> {
  constructor(props) {
    super(props);

    this.state = {
      open: false,
      currentLevel: 1,
      active: false
    };
  }

  componentDidMount() {
    // this.props.fetchHomeDataCall();  change it
  }

  setLevel2 = () => {
    this.setState(prevState => ({
      L3: !prevState.L3
    }));
  };

  handleClick(event, name, id) {
    console.log('ddddddddddddd', parseInt(event.currentTarget.id, 10) === id);

    event.preventDefault();
    this.props.fetchSubDataCall();
    this.setState({
      open: true,
      anchorEl: event.currentTarget,
      menuKey: name,
      active: parseInt(event.currentTarget.id, 10)
    });
  }

  handleRequestClose = () => {
    this.setState({
      open: false,
      currentLevel: 1,
      active: false
    });
  };

  render() {
    const { homeData, subCatData } = this.props;
    const headerContent =
      homeData && homeData.contents && homeData.contents[0].header;
    // const activeClass = this.state.active ? styles.active : '';
    console.log('active', headerContent);
    return (
      <div className={this.props.styles.navAutoZone}>
        <nav>
          <div className="nav-wrapper">
            <ul id="nav-mobile" className="left hide-on-med-and-down">
              {menuNavigation &&
                menuNavigation.menuNavigationLeft.map((menu, index) => (
                  <li key={menu.displayName}>
                    <FlatButton
                      id={index}
                      label={menu.displayName}
                      onClick={event =>
                        this.handleClick(event, menu.displayName, index)
                      }
                      className={
                        this.state.active === index
                          ? `${styles.flaButton} ${styles.activebg}`
                          : styles.flaButton
                      }
                    />
                  </li>
                ))}
            </ul>
          </div>
        </nav>
        <div>
          <MenuPopOver
            open={this.state.open}
            anchorEl={this.state.anchorEl}
            handleRequestClose={this.handleRequestClose}
            onMouseOverMenu={this.onMouseOverMenu}
            currentLevel={this.state.currentLevel}
            menuKey={this.state.menuKey}
            subCatData={subCatData}
            className={styles.popmain}
          />
        </div>
      </div>
    );
  }
}

const connector: Connector<{}, Props> = connect(
  ({ createAccountData }: ReduxState) => ({
    homeData: createAccountData.homeData,
    subCatData: createAccountData.subCatData
  }),
  (dispatch: Dispatch) => ({
    fetchHomeDataCall: () => dispatch(createAccount.fetchHomeDataCall()),
    fetchSubDataCall: () => dispatch(createAccount.fetchSubDataCall()),
    firstCatGet: (id, label) => dispatch(createAccount.firstCatGet(id, label)),
    fetchLevel2: (id, label) => dispatch(createAccount.fetchLevel2(id, label))
  })
);

export default connector(NavBar);
