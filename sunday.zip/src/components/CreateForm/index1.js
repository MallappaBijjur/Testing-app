/* @flow */
import React from 'react';
import type { Element } from 'react';
import TextField from 'material-ui/TextField';
import Checkbox from 'material-ui/Checkbox';
import RaisedButton from 'material-ui/RaisedButton';
import PasswordField from 'material-ui-password-field';
import { Field, reduxForm, formValueSelector } from 'redux-form';
import { connect } from 'react-redux';
import * as styles from '../../containers/CreateAccount/styles.scss';

type Props = {
  data: Object,
  formInfo: Object
};

const styles1 = {
  floatingLabelFocusStyle: {
    background: 'white',
    height: '25px',
    'margin-top': '12px',
    padding: '0 5px',
    'line-height': '1px !important'
  }
};

let createForm = ({ data, formInfo }: Props): Element<'form'> => {
  console.log('form data text', data);
  const submit = () => {
    console.log('in submit');
    console.log('the formValues are', formInfo);

    // const formData = document.getElementsByTagName('form')[0];
    // const { elements } = formData;
    // console.log(
    //   elements.namedItem('firstName') && elements.namedItem('firstName').value
    // );
  };
  type renderFieldProps = {
    nameVal: string,
    labelVal: string
  };
  const renderField = ({ labelVal, nameVal }: renderFieldProps) => (
    <TextField
      name={nameVal}
      floatingLabelText={labelVal}
      className={styles.inputTextBox}
    />
  );
  return (
    <form>
      <div>
        <div style={{ paddingBottom: '20px' }}>
          <Field
            nameVal="firstName"
            type="text"
            component={renderField}
            labelVal="Please enter the name"
          />
          <TextField
            hintText="First Name"
            floatingLabelText="First Name"
            className={styles.inputTextBox}
            floatingLabelFocusStyle={styles1.floatingLabelFocusStyle}
          />
          <TextField
            hintText="Last Name"
            floatingLabelText="Last Name"
            className={styles.inputTextBox}
            floatingLabelFocusStyle={styles1.floatingLabelFocusStyle}
          />
          <TextField
            hintText="Zip Code"
            floatingLabelText="Zip Code"
            className={styles.inputTextBox}
            floatingLabelFocusStyle={styles1.floatingLabelFocusStyle}
          />
          <TextField
            hintText="Phone"
            floatingLabelText="Phone"
            className={styles.inputTextBox}
            floatingLabelFocusStyle={styles1.floatingLabelFocusStyle}
          />
          <TextField
            hintText="Email"
            floatingLabelText="Email"
            className={styles.inputTextBox}
            floatingLabelFocusStyle={styles1.floatingLabelFocusStyle}
          />
          <PasswordField
            hintText={data.mf_registration_password_desc}
            floatingLabelText="Password"
            className={styles.inputTextBox_Password}
            visibilityIconStyle={{ 'margin-top': '-10px', opacity: '1' }}
            floatingLabelFocusStyle={styles1.floatingLabelFocusStyle}
          />
        </div>
        <div className={styles.regRewardSection}>
          <div className={styles.regRewardSectionTop}>
            {data.mf_registration_rewards_header_lbl}
            <img
              className={styles.rewardsArrow}
              src={require('../../containers/CreateAccount/assets/rewardsArrow.png')}
              alt="Logo"
              role="presentation"
            />
          </div>
          <div className={styles.regRewardSectionMid}>
            {data.mf_registration_rewards_msg}
          </div>
          <TextField
            className={styles.rewardsText}
            hintText="9101000389891796"
            floatingLabelText="Autozone Rewards Member ID"
            floatingLabelStyle={{
              top: '29px',
              left: '15px',
              fontWeight: 'normal',
              border: 'none'
            }}
            floatingLabelFocusStyle={{
              color: '#a9aaa8',
              left: '15px',
              paddingBottom: '5px'
            }}
            style={{
              width: '100%',
              height: '56px',
              border: '1px solid black'
            }}
          />
          <div className={styles.regAZMember_Error}>
            We couldn’t find that ID number. Check against the back of your card
            and try again?
          </div>
        </div>
        <div className={styles.regSubscription}>
          <div className={styles.offerCheckBox}>
            <Checkbox checked />
          </div>
          <div className={styles.receiveOffer}>
            {data.mf_registration_privacy_msg_1}
            <a
              href="/readYourPolicy"
              style={{
                display: 'block',
                'text-decoration': 'underline',
                color: '#333'
              }}
            >
              {data.mf_registration_privacy_msg_2}
            </a>
          </div>
          <div className={styles.regReadTerms}>
            {data.mf_registration_TermsandConditions_msg_1}
            <a href="/termsAndConditions">
              {data.mf_registration_TermsandConditions_msg_2}
            </a>
          </div>
          <div className={styles.regButtonSection}>
            <RaisedButton
              label={data.mf_registration_createAccount_btn}
              className={styles.regPrimaryBtn}
              onClick={submit}
            />
            <RaisedButton
              label={data.mf_registration_cancel_lbl}
              className={styles.regSecondaryBtn}
            />
          </div>
          <div className={styles.regSignInLink}>
            {data.mf_registration_signIn_msg_1}
            <a href="/signIn">{data.mf_registration_signIn_msg_2}</a>
          </div>
        </div>
      </div>
    </form>
  );
};

createForm = reduxForm({
  form: 'registerForm' // a unique name for this form
})(createForm);
const selector = formValueSelector('registerForm');

const CreateForm = connect(({ formInfo }) => {
  // console.log('the form data is', state);

  const formValue = selector(formInfo, 'firstName');
  // console.log(state);
  // const firstName =
  console.log('the  is ', formValue);
  return {
    formInfo
  };
})(createForm);
export default CreateForm;
