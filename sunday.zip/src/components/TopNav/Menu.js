/* @flow */

import React from 'react';
import type { Element } from 'react';
import navdrawer from './assets/navigation-drawer.png';

type Props = {
  styles: Object
};

const Menu = (props: Props): Element<'div'> => (
  <div className={props.styles.menuContainer}>
    <img className={props.styles.cartIcon} src={navdrawer} alt="menu icon" />
    <span className={props.styles.vehicleText}>MENU</span>
  </div>
);

export default Menu;
