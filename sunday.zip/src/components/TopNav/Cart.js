/* @flow */
import type { Element } from 'react';
import React from 'react';
import autoCart from './assets/cart.png';

type Props = {
  styles: Object
};

const Cart = (props: Props): Element<'div'> => (
  <div className={props.styles.cartContainer}>
    <img className={props.styles.cartIcon} src={autoCart} alt="cart icon" />
    <span className={props.styles.vehicleText}>CART</span>
  </div>
);

export default Cart;
