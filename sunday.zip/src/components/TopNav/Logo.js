/* @flow */

import React from 'react';
import type { Element } from 'react';
import autoZoneLogo from './assets/auto-zone-logo.png';
import autoZoneLogoMob from './assets/automobile.png';

type Props = {
  styles: Object
};

const Logo = (props: Props): Element<'div'> => (
  <div>
    <img
      className={props.styles.autoZoneLogo}
      src={autoZoneLogo}
      alt="autoZoneLogo"
    />
    <img
      className={props.styles.autoZoneLogoMob}
      src={autoZoneLogoMob}
      alt="autoZoneLogo"
    />
  </div>
);

export default Logo;
