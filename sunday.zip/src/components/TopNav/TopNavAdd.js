/* @flow */
import type { Element } from 'react';
import React from 'react';

type Props = {
  styles: Object
};

const TopNavAdd = (props: Props): Element<'div'> => (
  <div className={props.styles.addtop}>
    <div className={props.styles.only49}>ONLY $4.99*</div>
    <div className={props.styles.meguiar}>
      Meguiar’s Hot Shine Spray 15oz <br />or Hot Shine Aerosol 24oz{' '}
    </div>
    <div>
      <button className={props.styles.rect}> BUY NOW </button>
    </div>
    <div className={props.styles.typeface}>
      *Ends 6/26/2017. Prices may vary in AK & HI.
    </div>
  </div>
);

export default TopNavAdd;
