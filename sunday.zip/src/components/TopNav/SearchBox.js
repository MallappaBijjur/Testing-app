/* @flow */

import React from 'react';
import type { Element } from 'react';
import { Input } from 'semantic-ui-react';
// import searchIcon from './assets/az-search.png';

type Props = {
  styles: Object,
  viewType: string
};

const SearchBox = (props: Props): Element<'div'> => {
  const styleClass =
    props.viewType === 'mobile'
      ? props.styles.searchMobileIn
      : props.styles.searchDesktop;
  return (
    <div className={styleClass}>
      <Input
        icon="search"
        placeholder="Search"
        className={props.styles.search}
      />
    </div>
  );
};

export default SearchBox;
