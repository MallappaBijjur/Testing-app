/* @flow */

import type { Element } from 'react';
import React from 'react';
import { Link } from 'react-router-dom';
import NavInfo from '../NavTopInfo/NavInfo';
import Logo from '../TopNav/Logo';
import SearchBox from '../TopNav/SearchBox';
import Vehicle from '../TopNav/Vehicle';
import Cart from '../TopNav/Cart';
import Menu from '../TopNav/Menu';
import NavBar from '../../containers/NavBar/NavBar';

type Props = {
  styles: Object
};

const Header = (props: Props): Element<'div'> => (
  <div className={props.styles.App}>
    <div className={props.styles.appNavigation}>
      <NavInfo styles={props.styles} />
      <div className={props.styles.rowAuto}>
        <Link to="/home">
          <Logo styles={props.styles} />
        </Link>
        <SearchBox styles={props.styles} viewType="desktop" />
        <div className={props.styles.addInfo}>
          <Vehicle styles={props.styles} />
          <Cart styles={props.styles} />
          <Menu styles={props.styles} />
        </div>
      </div>
      <div className={props.styles.searchMobile}>
        <SearchBox styles={props.styles} viewType="mobile" />
      </div>
      <NavBar styles={props.styles} />
    </div>
  </div>
);

export default Header;
