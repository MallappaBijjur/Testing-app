/* @flow */
import React from 'react';
import type { Element } from 'react';
import { Grid, Row, Col } from 'react-bootstrap';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import lightBaseTheme from 'material-ui/styles/baseThemes/lightBaseTheme';
import TextField from 'material-ui/TextField';
import Checkbox from 'material-ui/Checkbox';
import RaisedButton from 'material-ui/RaisedButton';
import getMuiTheme from 'material-ui/styles/getMuiTheme';
// import Banner from './Banner';
import * as styles from './register.scss';
import logo from './logo.png';

const info1 = {
  mf_registration_password_mobile_lbl: 'Password',
  mf_registration_zip_mobile_lbl: 'Zip',
  mf_registration_firstName_desktop_lbl: 'First Name',
  mf_registration_email_desktop_lbl: 'Email',
  mf_registration_lastName_mobile_lbl: 'Last Name',
  mf_registration_phone_desktop_lbl: 'Phone Number',
  mf_registration_privacy_msg_1:
    'I would like to receive special offers, promotions, news, surveys, and corespondence from AutoZone, AutoZone.com, and AutoZone Rewards. Read our ',
  mf_registration_createAccount_btn: 'Create Account',
  mf_registration_rewards_textbox_lbl: 'AutoZone Rewards Member ID',
  mf_registration_privacy_msg_2: 'Privacy Policy.',
  mf_registration_lastName_desktop_lbl: 'Last Name',
  links: [
    {
      method: 'GET',
      rel: '/rels/getForgotPasswordPageContents',
      href: 'http://dv-camaro1-xl07:8289/autozone/v1/page/forgotPasswordPage'
    },
    {
      method: 'GET',
      rel: '/rels/getResetPasswordPageContents',
      href: 'http://dv-camaro1-xl07:8289/autozone/v1/page/resetPasswordPage'
    }
  ],
  mf_registration_myZoneAcc_msg:
    'Create a MyZone Account to get these benefites and more',
  mf_registration_password_desc:
    'Passwords are case sensitive and must be at least 8 characters, with atleast 1 number and 1 special character.',
  mf_registration_signIn_msg_1: 'Already have an account? ',
  mf_registration_signIn_msg_2: 'Sign In.',
  mf_registration_page_header_lbl: 'Create Online Account',
  mf_registration_TermsandConditions_msg_2: 'Terms & Conditions.',
  mf_registration_TermsandConditions_msg_1:
    'By clicking Create Account, you agree to the ',
  mf_registration_rewards_msg:
    'Enter your AutoZone Rewards Member ID to link your rewards to your new account. Your ID number can be found on the bak side of your Autoone Rewards card.',
  mf_registration_firstName_mobile_lbl: 'First Name',
  mf_registration_password_show_lbl: 'SHOW',
  mf_registration_myZoneAcc_benefit_msg_1:
    'Earn a $20 Reward when you ake fie purchases of $20 or more',
  mf_registration_myZoneAcc_benefit_msg_2:
    'Save your imformations and preferenes for fast checkout',
  success: 'true',
  mf_registration_password_desktop_lbl: 'Password',
  mf_registration_myZoneAcc_benefit_msg_3:
    'Manage your vehicle, see your order history and warranty information',
  mf_registration_zip_desktop_lbl: 'Zip Code',
  mf_registration_email_mobile_lbl: 'Email',
  mf_registration_phone_mobile_lbl: 'Phone',
  mf_registration_rewards_header_lbl: 'Enter your AutoZone Rewards Member ID',
  mf_registration_cancel_lbl: 'Cancel'
};

type Props = { info: Object };

const TestCard = ({ info }: Props): Element<'div'> => (
  <Grid className={styles.registerationPage}>
    <Row className="show-grid">
      <Col xs={12} sm={12} md={12} lg={4}>
        <img alt="Logo Here" src={logo} className={styles.regLogo} />
        <h1>{info.name}</h1>
        <div>{info.mf_registration_error_firstname}</div>
        <MuiThemeProvider muiTheme={getMuiTheme(lightBaseTheme)}>
          <div className={styles.createForm}>
            <div>
              <TextField
                hintText={info1.mf_registration_error_firstname}
                floatingLabelText={info1.mf_registration_error_firstname}
                className={styles.inputTextBox}
              />
              <TextField
                hintText={info1.mf_registration_error_lastname}
                floatingLabelText={info1.mf_registration_error_lastname}
                className={styles.inputTextBox}
              />
              <TextField
                hintText="Zip Code"
                floatingLabelText="Zip Code"
                className={styles.inputTextBox}
              />
              <TextField
                hintText={info1.mf_registration_email}
                floatingLabelText={info1.mf_registration_email}
                className={styles.inputTextBox}
              />
              <TextField
                hintText={info1.mf_registration_email}
                floatingLabelText={info1.mf_registration_email}
                className={styles.inputTextBox}
              />
              <TextField
                hintText={info1.mf_registration_password}
                floatingLabelText={info1.mf_registration_password}
                className={styles.inputTextBox_Password}
              />
            </div>
            <div className={styles.regPasswordRules}>
              {info1.mf_registration_password_desc}
            </div>
            <div className={styles.regRewardSection}>
              <div className={styles.regRewardSectionTop}>
                {info1.mf_registration_rewards}
              </div>
              <div className={styles.regRewardSectionMid}>
                Link AutoZone Rewards with the Member ID number on the back of
                your AutoZone Rewards card.
              </div>
              <TextField
                hintText="9101000389891796"
                floatingLabelText="Autozone Rewards Member ID"
                className={styles.inputTextBox_AZID}
              />
              <div className={styles.regAZMember_Error}>
                We couldn’t find that ID number. Check against the back of your
                card and try again?
              </div>
            </div>
            <div className={styles.regSubscription}>
              <Checkbox />
              <div>Yes, {info1.mf_registration_privacy}</div>
              <div className={styles.regReadTerms}>
                {info1.mf_registration_TermsandConditions}
              </div>
              <div className={styles.regButtonSection}>
                <RaisedButton
                  label="Sign Up"
                  className={styles.regPrimaryBtn}
                />
                <RaisedButton
                  label={info1.mf_registration_cancel}
                  className={styles.regSecondaryBtn}
                />
              </div>
              <div className={styles.regSignInLink}>
                {info1.mf_registration_SignIn}
              </div>
            </div>
          </div>
        </MuiThemeProvider>
      </Col>
      <Col xsHidden lg={8}>
        Banner Here 1234
      </Col>
    </Row>
  </Grid>
);

export default TestCard;
