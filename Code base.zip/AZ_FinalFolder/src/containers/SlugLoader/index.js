import React, { PureComponent } from 'react';
import { LinkContainer } from 'react-router-bootstrap';
import Navbar from 'react-bootstrap/lib/Navbar';
import Nav from 'react-bootstrap/lib/Nav';
import NavItem from 'react-bootstrap/lib/NavItem';
import PropTypes from 'prop-types';
import styles from './styles.scss';

export default class SlugLoader extends PureComponent {
  render() {
    return (
      <Navbar collapseOnSelect className={styles.customNavBar}>
        <Navbar.Collapse>
          <Nav>
            {this.props.menuNavigation.menuNavigationLeft.map(menuNav => (
              <LinkContainer key={menuNav.id} to={`/Home/${menuNav.id}`}>
                <NavItem eventKey={menuNav.id} href="#">
                  {menuNav.name}
                </NavItem>
              </LinkContainer>
            ))}
          </Nav>
        </Navbar.Collapse>
        <Navbar.Collapse>
          <Nav>
            {this.props.menuNavigation.menuNavigationRight.map(menuNav => (
              <LinkContainer key={menuNav.id} to={`/Home/${menuNav.id}`}>
                <NavItem eventKey={menuNav.id} href="#">
                  {menuNav.name}
                </NavItem>
              </LinkContainer>
            ))}
          </Nav>
        </Navbar.Collapse>
      </Navbar>
    );
  }
}

SlugLoader.propTypes = {
  menuNavigation: PropTypes.shape.isRequired
};
