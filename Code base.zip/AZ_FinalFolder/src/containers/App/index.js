import React from 'react';
import type { Element } from 'react';
import { Link } from 'react-router-dom';
import routes from '../../routes'; // eslint-disable-line
// Import your global styles here
import '../../theme/normalize.css';
import styles from './styles.scss';
import menuNavigation from '../data/menuNavigation';
import { Logo } from '../../components/TopNav/Logo';
import { SearchBox } from '../../components/TopNav/SearchBox';
import { Vehicle } from '../../components/TopNav/Vehicle';
import { Cart } from '../../components/TopNav/Cart';
import { Menu } from '../../components/TopNav/Menu';
import { NavInfo } from '../../components/NavTopInfo/NavInfo';

const App = (): Element<'div'> => (
  // wrap <Route> and use this everywhere instead, then when
  // sub routes are added to any route it'll work
  <div className={styles.App}>
    <div className={styles.appNavigation}>
      <NavInfo styles={styles} />
      <div className={styles.rowAuto}>
        <Link to="/home">
          <Logo styles={styles} />
        </Link>
        <SearchBox styles={styles} viewType="desktop" />
        <div className={styles.addInfo}>
          <Vehicle styles={styles} />
          <Cart styles={styles} />
          <Menu styles={styles} />
        </div>
      </div>
      <div className={styles.searchMobile}>
        <SearchBox styles={styles} viewType="mobile" />
      </div>
      <div className={styles.navAutoZone}>
        <nav>
          <div className="nav-wrapper">
            <ul id="nav-mobile" className="left hide-on-med-and-down">
              {menuNavigation.menuNavigationLeft.map(menu => (
                <li key={menu.id}>
                  <a href={menu.link}>{menu.name}</a>
                </li>
              ))}
            </ul>
            <ul id="nav-mobile" className="hide-on-med-and-down right">
              {menuNavigation.menuNavigationRight.map(menu => (
                <li key={menu.id}>
                  <a href={menu.link}>{menu.name}</a>
                </li>
              ))}
            </ul>
          </div>
        </nav>
      </div>
    </div>
  </div>
);

export default App;
