import React from 'react';
import navdrawer from './assets/navigation-drawer.png';

export const Menu = (props) => {
	return(
	 <div className={props.styles.menuContainer}>
      <img className={props.styles.cartIcon} src={navdrawer} alt="menu icon" />
      <span className={props.styles.vehicleText}>MENU</span>
     </div>
	);
}
