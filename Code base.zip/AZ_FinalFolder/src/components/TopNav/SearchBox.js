import React from 'react';
import searchIcon from './assets/az-search.png';
import { Input } from 'semantic-ui-react';

export const SearchBox = (props) => {
	const styleClass = props.viewType == 'mobile' ? props.styles.searchMobileIn : props.styles.searchDesktop;
	return(
	 <div className={styleClass}>
	   <Input icon="search" placeholder="Search" className={props.styles.search} />
	   <button className={props.styles.searchBtn}>
	     <img
	       className={props.styles.searchIcon}
	       src={searchIcon}
	       alt="search icon"
	     />
	   </button>
	 </div>
	);
}
