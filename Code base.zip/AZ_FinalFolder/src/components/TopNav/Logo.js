import React from 'react';
import autoZoneLogo from './assets/auto-zone-logo.png';
import autoZoneLogoMob from './assets/automobile.png';

export const Logo = (props) => {
	return (
		<div>
			<img
			 className={props.styles.autoZoneLogo}
			 src={autoZoneLogo}
			 alt="autoZoneLogo"
			/>
			<img
			  className={props.styles.autoZoneLogoMob}
			  src={autoZoneLogoMob}
			  alt="autoZoneLogo"
			/>
		</div>

	)
}
