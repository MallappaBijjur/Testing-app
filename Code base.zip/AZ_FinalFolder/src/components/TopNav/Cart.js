import React from 'react';
import autoCart from './assets/cart.png';

export const Cart = (props) => {
	return(
	 <div className={props.styles.cartContainer}>
      <img className={props.styles.cartIcon} src={autoCart} alt="cart icon" />
      <span className={props.styles.vehicleText}>CART</span>
	 </div>
	);
}
