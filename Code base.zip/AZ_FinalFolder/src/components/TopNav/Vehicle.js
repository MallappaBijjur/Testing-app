import React from 'react';
import autoCar from './assets/az-car.png';


export const Vehicle = (props) => {
	return(
  	 <div className={props.styles.vahicaleContainer}>
      <img className={props.styles.cartIcon} src={autoCar} alt="car icon" />
      <span className={props.styles.addVehicleText}>ADD A VEHICLE</span>
      <span className={props.styles.vehicleTextMob}>VEHICLE</span>
	 </div>
	);
}
