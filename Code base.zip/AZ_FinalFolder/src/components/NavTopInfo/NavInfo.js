import React from 'react';
import azLocationIcon from './assets/az-location.png';
import downArrowIcon from './assets/down.png';
import azChatIcon from './assets/az-chat.png';

export const NavInfo = (props) => {
	return(
      <div className={props.styles.navinfo}>
        <div className={props.styles.topContainer}>
          <div>
            <span className={props.styles.storeContainer}>
              <img src={azLocationIcon} alt="drop icon" /> Store:
            </span>
            <span className={props.styles.storeText}>1050 Elvis Presley Blvd</span>
          </div>
          <span className={props.styles.openTil}>
            Open til &#39; 9 PM <img src={downArrowIcon} alt="pin icon" />
          </span>
        </div>
        <div className={props.styles.myAccountContent}>
          <span className={props.styles.myAccount}>
            <img src={azChatIcon} alt="account icon" /> My Account
          </span>
          <span className={props.styles.contactUs}>
            <img src={azChatIcon} alt="phone icon" /> Contact Us
          </span>
        </div>
      </div>
	);
}